#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <Windows.h>

using namespace std;

int R, C, ** matrix;
bool ** mirrorMatrix;

struct data
{
	int count;
	int row, col;
	data(int count, int row, int col):
		count(count), row(row), col(col)
	{}
};

void init()
{
    cin >> R >> C;
	matrix = new int * [R];
	mirrorMatrix = new bool * [R];
    for (int row = 0; row < R; ++row)
    {
        matrix[row] = new int [C];
		mirrorMatrix[row] = new bool [C];
        for (int col = 0; col < C; ++col)
		{
            cin >> matrix[row][col];
			mirrorMatrix[row][col] = 0;
		}
    }
}

void destroy()
{
	for (int row = 0; row < R; ++row)
	{
		delete mirrorMatrix[row];
		delete matrix[row];
	}
	delete [] mirrorMatrix;
	delete [] matrix;
}

pair<int, int> findDominantColor()
{
	int max_colors_array[4] = {};
	bool * col_colors_array[4];
	for (int i = 0; i < 4; ++i)
	{
		col_colors_array[i] = new bool [C];
		for (int j = 0; j < C; ++j)
			col_colors_array[i][j] = 0;
	}
	for (int row = 0; row < R; ++row)
	{
        for (int col = 0; col < C; ++col)
		{
			if (matrix[row][col] != -1)
			{
				++max_colors_array[matrix[row][col] - 1];
				col_colors_array[matrix[row][col] - 1][col] = 1;
			}
		}
	}
	int best = 0, bestC = 1, bestMax = 0;
	for (int i = 0; i < 4; ++i)
	{
		int c = 0;
		for (int j = 0; j < C; ++j)
			if (col_colors_array[i][j] == 1 && (j == 0 || col_colors_array[i][j - 1] == 0))
				c += 1;
		if (max_colors_array[i] > 0)
		{
			if ((double)bestMax / bestC < (double)max_colors_array[i] / c)
			{
				best = i;
				bestC = c;
				bestMax = max_colors_array[i];
			}
		}
	}
	return pair<int, int>(best + 1, bestC);
}

int group(int row, int col, int color)
{
    if (row < 0 || row >= R || col < 0 || col >= C ||
        mirrorMatrix[row][col] == 1 || matrix[row][col] != color)
        return 0;
    else
    {
		mirrorMatrix[row][col] = 1;
		return 1 + group(row + 1, col, color) +
			group(row - 1, col, color) +
			group(row, col + 1, color) +
			group(row, col - 1, color);
    }
}

void removeGroup(int row, int col, int color)
{
    if (row >= 0 && row < R && col >= 0 && col < C && 
		color == matrix[row][col] && mirrorMatrix[row][col] == 0)
    {
        matrix[row][col] = -1;
		int s = row;
		for (int r = row - 1; r >= 0; --r)
		{
			matrix[s][col] = matrix[r][col];
			matrix[r][col] = -1;
			--s;
		}
		removeGroup(row, col, color);
		mirrorMatrix[row][col] = 1;
        removeGroup(row + 1, col, color);
        removeGroup(row, col + 1, color);
        removeGroup(row, col - 1, color);
        mirrorMatrix[row][col] = 0;
    }
}

void solve()
{
	vector< pair<int, int> > result;
	pair<int, int> dominantColor = findDominantColor();
	while (true)
	{
		vector<data> groups;
		int r, c;
		int maxs = 0;
		bool breakingCondition = true;
		for (int row = 0; row < R; ++row)
		{
			for (int col = 0; col < C; ++col)
			{
				if (mirrorMatrix[row][col] == 0 && matrix[row][col] != -1)
				{
					breakingCondition = false;
					if (matrix[row][col] == dominantColor.first)
					{
						groups.push_back(
							data(group(row, col, matrix[row][col]), row, col)
						);	
					}
					else
					{
						int sss = group(row, col, matrix[row][col]);
						if (sss > maxs)
						{
							maxs = sss;
							r = row;
							c = col;
						}
					}
				}
				mirrorMatrix[row][col] = 0;
			}
		}
		if (breakingCondition)
			break;
		if (groups.size() <= dominantColor.second &&
			groups.size() > 0)
		{
			for (int i = 0; i < groups.size(); ++i)
			{
				r = groups[i].row;
				c = groups[i].col;
				removeGroup(r, c, matrix[r][c]);
				result.push_back(pair<int, int>(r, c));
			}
			continue;
		}
		removeGroup(r, c, matrix[r][c]);
		result.push_back(pair<int, int>(r, c));
	}
	cout << result.size() << endl;
	for (int i = 0; i < result.size(); ++i)
		cout << result[i].first << " " << result[i].second << endl;
}

int main()
{
	init();
	solve();
	destroy();
	return 0;
}