﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using BaloonsGUI.Highscore;

namespace BaloonsGUI
{
	/// <summary>
	/// Interaction logic for GameResult.xaml
	/// </summary>
	public partial class GameResult : Window
	{
		private GameScore Score;

		public GameResult()
		{
			InitializeComponent();
		}

		public void SetData(double Score, int Points, int Moves, int rows, int cols)
		{
			this.Score = new GameScore { Score = Math.Round(Score, 2), Points = Points, Moves = Moves, Cols = cols, Rows = rows };

			labelScore.Content = "Your score is: " + Math.Round(Score, 2);
			labelPoints.Content = "Total points: " + Points;
			labelMoves.Content = "Total moves: " + Moves;
			labelBaloons.Content = "Total baloons: " + rows * cols;
			labelGameSize.Content = "Game size: " + cols + "x" + rows;
		}

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, RoutedEventArgs e)
		{
			if (this.Score == null)
				return;

			this.Score.Name = name.Text;

			using (FileStream fs = new FileStream("scores.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite))
			{
				var bf = new BinaryFormatter();
				List<GameScore> results;

				if (fs.Length > 0)
					results = (List<GameScore>)bf.Deserialize(fs);
				else
					results = new List<GameScore>();

				results.Add(this.Score);

				fs.Position = 0;
				bf.Serialize(fs, results);
				
				// Clear any left data in the file
				fs.SetLength(fs.Position);
				fs.Flush();
			}

			this.Close();
		}
	}
}
