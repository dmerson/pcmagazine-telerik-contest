﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BaloonsGUI
{
	public enum Balloon
	{
		None = 0,
		Red = 1,
		Green = 2,
		Blue = 3,
		Purple = 4
	}

	public class BalloonField
	{
		private Balloon[,] field;

		public Balloon[,] Field
		{
			get
			{
				return field;
			}
		}

		public int Cols
		{
			get
			{
				return field.GetLength(0);
			}
		}

		public int Rows
		{
			get
			{
				return field.GetLength(1);
			}
		}

		public BalloonField(int cols, int rows)
		{
			Generate(cols, rows);
		}

		public BalloonField(Stream str)
		{
			using (var reader = new StreamReader(str))
			{
				string[] dimensions = reader.ReadLine().Split(' ');
				field = new Balloon[int.Parse(dimensions[1]), int.Parse(dimensions[0])];

				for (int row = 0; row < field.GetLength(1); row++)
				{
					string[] rowS = reader.ReadLine().Split(' ');

					for (int col = 0; col < field.GetLength(0); col++)
					{
						field[col, row] = (Balloon)int.Parse(rowS[col]);
					}
				}
			}
		}

		private void Generate(int cols, int rows)
		{
			var rand = new Random();
			/*field = new Balloon[,] {
				{(Balloon)1,(Balloon)1,(Balloon)2,(Balloon)3,(Balloon)2},
				{(Balloon)2,(Balloon)3,(Balloon)4,(Balloon)1,(Balloon)3},
				{(Balloon)2,(Balloon)1,(Balloon)1,(Balloon)3,(Balloon)3},
				{(Balloon)4,(Balloon)3,(Balloon)4,(Balloon)3,(Balloon)2},
				{(Balloon)4,(Balloon)4,(Balloon)2,(Balloon)2,(Balloon)3}
			};*/
			field = new Balloon[cols, rows];
			for (int col = 0; col < cols; col++)
			{
				for (int row = 0; row < rows; row++)
				{
					field[col, row] = (Balloon)rand.Next(1, 5);
				}
			}
		}
	}
}
