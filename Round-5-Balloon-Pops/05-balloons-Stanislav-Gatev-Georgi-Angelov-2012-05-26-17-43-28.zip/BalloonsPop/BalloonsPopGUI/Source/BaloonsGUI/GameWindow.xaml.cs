﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace BaloonsGUI
{
	struct Move
	{
		public int Row { get; set; }
		public int Col { get; set; }
	}

    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
	{
		public GameWindow(BalloonField f)
		{
			InitializeComponent();
			game.Game = f;

			save();
		}

		public GameWindow(BalloonField f, string algoPath)
		{
			InitializeComponent();
			game.Game = f;
			GetSteps(algoPath);
			game.DisableClicks = true;

			save();
		}

		private void save()
		{
			StreamWriter writer = new StreamWriter(new FileStream("lastGame.txt", FileMode.Create, FileAccess.Write));//proc.StandardInput;
			writer.Write(game.Game.Rows);
			writer.Write(' ');
			writer.Write(game.Game.Cols);
			writer.WriteLine();

			for (int i = 0; i < game.Game.Rows; i++)
			{
				for (int j = 0; j < game.Game.Cols; j++)
				{
					writer.Write((int)game.Game.Field[j, i] + " ");
				}

				writer.WriteLine();
			}

			writer.Flush();
		}

		private List<Move> Steps { get; set; }

		private bool crashed = false;

		private void GetSteps(string algo)
		{
			Process proc = new Process();
			proc.StartInfo.FileName = algo;
			proc.StartInfo.UseShellExecute = false;
			proc.StartInfo.RedirectStandardInput = true;
			proc.StartInfo.RedirectStandardOutput = true;
			proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			proc.Start();

			// Write to the app
			StreamWriter writer = proc.StandardInput;//new StreamWriter(new FileStream("test.txt", FileMode.Create, FileAccess.Write));//proc.StandardInput;
			writer.Write(game.Game.Rows);
			writer.Write(' ');
			writer.Write(game.Game.Cols);
			writer.WriteLine();

			for (int i = 0; i < game.Game.Rows; i++)
			{
				for (int j = 0; j < game.Game.Cols; j++)
				{
					writer.Write((int)game.Game.Field[j, i] + " ");
				}

				writer.WriteLine();
			}

			writer.Flush();
			
			// Get the output
			new Thread(delegate()
			{
				try
				{
					Steps = new List<Move>();

					string n = proc.StandardOutput.ReadLine();
					int num = int.Parse(n);

					for (int i = 0; i < num; i++)
					{
						string[] m = proc.StandardOutput.ReadLine().Split(' ');
						Steps.Add(new Move { Row = int.Parse(m[0]), Col = int.Parse(m[1]) });
					}

					StartMoves();
				}
				catch (ArgumentNullException)
				{
					crashed = true;
					MessageBox.Show("The algorithm crashed or wrote wrong output");
				}
			}).Start();

			// Wait for it to exit
			proc.WaitForExit(3000);

			if (!proc.HasExited)
			{
				proc.Kill();
				
				if (!crashed)
					MessageBox.Show("The algorithm didn't solve the game in time");
				
				this.Close();
				return;
			}
		}

		private void StartMoves()
		{
			new Thread(delegate()
			{
				foreach (Move move in Steps)
				{
					game.Dispatcher.Invoke(new Action(delegate()
					{
						if (!game.Pop(move.Col, move.Row))
						{
							MessageBox.Show("The algorithm made a wrong move. There's no balloon there!");
						}
					}));

					Thread.Sleep(1500);
				}

				if (!game.GameEnded)
				{
					this.Dispatcher.Invoke(new Action(delegate()
					{
						MessageBox.Show("The algorithm didn't solve the game!");
					}));
				}
			}).Start();
		}

		private void game_GameEnd(double Score, int Points, int Moves, int rows, int cols)
		{
			var res = new GameResult();
			res.SetData(Score, Points, Moves, rows, cols);

			this.Close();
			res.ShowDialog();
		}
    }
}
