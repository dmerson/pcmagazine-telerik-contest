﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BaloonsGUI.Highscore;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BaloonsGUI
{
	/// <summary>
	/// Interaction logic for ScoreBoard.xaml
	/// </summary>
	public partial class ScoreBoard : Window
	{
		public ScoreBoard()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			using (FileStream fs = new FileStream("scores.dat", FileMode.OpenOrCreate, FileAccess.Read))
			{
				var bf = new BinaryFormatter();

				if (fs.Length > 0)
				{
					var list = (List<GameScore>)bf.Deserialize(fs);
					list.Sort();
					ScoreGrid.ItemsSource = list;
				}
				else
					ScoreGrid.ItemsSource = new List<GameScore>();
			}
		}
	}
}
