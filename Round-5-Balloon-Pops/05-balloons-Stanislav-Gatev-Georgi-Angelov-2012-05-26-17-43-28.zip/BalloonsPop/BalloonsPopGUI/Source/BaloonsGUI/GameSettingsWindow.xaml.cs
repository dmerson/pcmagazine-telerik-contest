﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BaloonsGUI
{
    /// <summary>
    /// Interaction logic for GameSettingsWindow.xaml
    /// </summary>
    public partial class GameSettingsWindow : Window
    {
		public BalloonField field { get; private set; }

        public GameSettingsWindow()
        {
            InitializeComponent();
        }

        private void buttonGenerate_Click(object sender, RoutedEventArgs e)
        {
            int cols = int.Parse(this.textBoxWidth.Text);
            int rows = int.Parse(this.textBoxHeight.Text);

			field = new BalloonField(cols, rows);

            this.Close();
        }

		private void buttonLoad_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog file = new OpenFileDialog();

			if ((bool)file.ShowDialog())
			{
				field = new BalloonField(file.OpenFile());

				this.Close();
			}
		}
    }
}
