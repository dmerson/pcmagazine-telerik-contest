﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace BaloonsGUI
{
	/// <summary>
	/// Interaction logic for BalloonGame.xaml
	/// </summary>
	public partial class BalloonGame : UserControl
	{
		public delegate void GameEndDelegate(double Score, int Points, int Moves, int rows, int cols);
		public event GameEndDelegate GameEnd;


        private const double ANIMATION_DURATION = 0.33;
		private BalloonField game;
		public BalloonField Game
		{
			get
			{
				return game;
			}

			set
			{
				game = value;
				InitBalloons();
			}
		}
		private Image[,] balloons;

		private double balloonDimensions = 50;
		public double BalloonDimensions {
			get
			{
				return balloonDimensions;
			}
			set
			{
				balloonDimensions = value;
				BalloonSizeChanged();
			}
		}
		public double BalloonPadding { get; set; }

		private bool disableClicks = false;
		public bool DisableClicks
		{
			get
			{
				return disableClicks;
			}
			set
			{
				disableClicks = value;
			}
		}

		public static DependencyProperty ScoreProperty = DependencyProperty.Register(
			"Score", typeof(int), typeof(BaloonsGUI.BalloonGame));

		public int Score
		{
			get
			{
				return (int)GetValue(ScoreProperty);
			}
			private set
			{
				SetValue(ScoreProperty, value);

				if (Moves > 0)
					SetValue(TotalScoreProperty, (double)(int)GetValue(ScoreProperty) / (int)GetValue(MovesProperty));
			}
		}

		public static DependencyProperty MovesProperty = DependencyProperty.Register(
			"Moves", typeof(int), typeof(BaloonsGUI.BalloonGame));

		public int Moves
		{
			get
			{
				return (int)GetValue(MovesProperty);
			}
			private set
			{
				SetValue(MovesProperty, value);

				if (Moves > 0)
					SetValue(TotalScoreProperty, (double)(int)GetValue(ScoreProperty) / (int)GetValue(MovesProperty));
			}
		}

		public static DependencyProperty TotalScoreProperty = DependencyProperty.Register(
			"TotalScore", typeof(double), typeof(BaloonsGUI.BalloonGame));

		public double TotalScore
		{
			get
			{
				return (double)GetValue(TotalScoreProperty);
			}
		}

		public int BaloonsPopped { get; private set; }

		public bool GameEnded
		{
			get
			{
				return BaloonsPopped == Game.Rows * Game.Cols;
			}
		}

		public BalloonGame()
		{
			InitializeComponent();
			Score = 0;
		}

		private void InitBalloons()
		{
			Score = 0;
			balloonContainer.Children.Clear();
			balloonContainer.Width = game.Cols * (BalloonDimensions + BalloonPadding);
			balloonContainer.Height = game.Rows * (BalloonDimensions + BalloonPadding);
			
			balloons = new Image[game.Cols, game.Rows];

			
			for (int i = 0; i < game.Cols; i++)
			{
				for (int j = 0; j < game.Rows; j++)
				{
					var img = new Image();
					img.Source = (ImageSource)FindResource("Baloon_" + (int)game.Field[i, j]);

					var margin = GetBalloonMargin(i, j);
					img.RenderTransform = new TranslateTransform(margin.Left, margin.Top);

					img.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
					img.VerticalAlignment = System.Windows.VerticalAlignment.Top;
					img.Width = BalloonDimensions;
					img.Height = BalloonDimensions;

					img.MouseUp += new MouseButtonEventHandler(img_MouseUp);

					balloonContainer.Children.Add(img);
					balloons[i, j] = img;
				}
			}
		}

		void img_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (DisableClicks)
				return;

			for (int i = 0; i < game.Cols; i++)
			{
				for (int j = 0; j < game.Rows; j++)
				{
					if (sender == balloons[i, j])
					{
						Pop(i, j);
						return;
					}
				}
			}
		}

		private Thickness GetBalloonMargin(int col, int row)
		{
			return new Thickness(col * (BalloonDimensions + BalloonPadding), row * (BalloonDimensions + BalloonPadding), 0, 0);
		}

		public bool Pop(int col, int row)
		{
			if (game.Field[col, row] != Balloon.None)
			{
				int num = Pop(col, row, game.Field[col, row]);

				Score += num * num;
				Moves++;
				BaloonsPopped += num;
			}
			else
			{
				return false;
			}

			if (GameEnded && GameEnd != null)
				GameEnd(TotalScore, Score, Moves, game.Rows, game.Cols);

			Gravity();

			return true;
		}

		private int Pop(int col, int row, Balloon type)
		{
			if (col < 0 || row < 0 || col >= game.Cols || row >= game.Rows)
				return 0;

			if (game.Field[col, row] != type)
				return 0;

			game.Field[col, row] = Balloon.None;
			RemoveBalloonImage(col, row);

			return 1 + Pop(col - 1, row, type) +
			Pop(col, row - 1, type) +
			Pop(col + 1, row, type) +
			Pop(col, row + 1, type);
		}

		private void Gravity()
		{
			for (int i = 0; i < game.Cols; i++)
			{
				bool hasBalloons = false;

				for (int j = 0; j < game.Rows; j++)
				{
					Balloon current = game.Field[i, j];

					if (current != Balloon.None)
					{
						hasBalloons = true;
					}
					else if (hasBalloons)
					{
						// Move every balloon one step down
						for (int k = j - 1; k >= 0; k--)
						{
							game.Field[i, k + 1] = game.Field[i, k];
							MoveBalloonImage(i, k, k + 1);
						}
						game.Field[i, 0] = Balloon.None;
					}
				}
			}
		}

		private void MoveBalloonImage(int col, int rowFrom, int rowTo)
		{
			Image img = balloons[col, rowFrom];

			if (img == null)
				return;

			if (balloons[col, rowTo] != null)
				throw new Exception("Invalid balloon move");

			balloons[col, rowFrom] = null;
			balloons[col, rowTo] = img;
			var margin = GetBalloonMargin(col, rowTo);
			MoveTo(img, margin.Left, margin.Top); 
		}

		public static void MoveTo(Image target, double newX, double newY)
		{
			var transform = (TranslateTransform)target.RenderTransform;
			
			DoubleAnimation anim1 = new DoubleAnimation(transform.Y, newY, TimeSpan.FromSeconds(ANIMATION_DURATION));
            DoubleAnimation anim2 = new DoubleAnimation(transform.X, newX, TimeSpan.FromSeconds(ANIMATION_DURATION));
			target.RenderTransform.BeginAnimation(TranslateTransform.XProperty, anim2);
			target.RenderTransform.BeginAnimation(TranslateTransform.YProperty, anim1);
		}

		private void RemoveBalloonImage(int col, int row)
		{
			balloonContainer.Children.Remove(balloons[col, row]);
			balloons[col, row] = null;
		}

		private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (game == null)
				return;

			// Rescale the balloons
			double newSize = Math.Max(15, Math.Min(55, Math.Min(this.ActualWidth / game.Cols, this.ActualHeight / game.Rows)));
			
			BalloonPadding = newSize * 0.1;
			BalloonDimensions = newSize * 0.9;
		}

		private void BalloonSizeChanged()
		{
			if (balloons == null)
				return;

			balloonContainer.Width = game.Cols * (BalloonDimensions + BalloonPadding);
			balloonContainer.Height = game.Rows * (BalloonDimensions + BalloonPadding);

			for (int i = 0; i < balloons.GetLength(0); i++)
			{
				for (int j = 0; j < balloons.GetLength(1); j++)
				{
					if (balloons[i, j] == null)
						continue;

					var margin = GetBalloonMargin(i, j);
					balloons[i, j].RenderTransform = new TranslateTransform(margin.Left, margin.Top);
					balloons[i, j].Width = BalloonDimensions;
					balloons[i, j].Height = BalloonDimensions;
				}
			}
		}
	}
}
