﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ELS;

namespace BibleCodeGUI
{
	/// <summary>
	/// Interaction logic for ELSGrid.xaml
	/// </summary>
	public partial class ELSGrid : UserControl
	{
		public ELSGrid()
		{
			InitializeComponent();
		}

		private const int letterWidth = 30, letterHeight = 40;

		private List<Label> labels = new List<Label>();
		private int offset;
		private List<Word> words;
		private Dictionary<int, Color> colors;
		public void SetELSGrid(ELSSearch els)
		{
			grid.Children.RemoveRange(0, grid.Children.Count);
			labels.RemoveRange(0, labels.Count);
			colors = GenerateColors(els.FoundWords);
			//labels = new Label[els.FoundRows, els.FoundCols];

			grid.Width = letterWidth * els.FoundCols;
			grid.Height = letterHeight * els.FoundRows;
			grid.Columns = els.FoundCols;
			grid.Rows = els.FoundRows;

			offset = els.FoundOffset;
			words = els.FoundWords;
			for (int i = els.FoundOffset; i < els.FoundOffset + els.FoundRows * els.FoundCols; i++)
			{
				Label letter = new Label();
				letter.Content = els.text[i];
				letter.Margin = new Thickness(0);
				letter.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
				letter.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
				letter.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
				letter.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Center;
				letter.FontSize = 20;

				if (colors.ContainsKey(i))
				{
					letter.Background = new SolidColorBrush(colors[i]);
					letter.MouseEnter += MouseOver;
					letter.MouseLeave += MouseOut;
				}

				labels.Add(letter);
				grid.Children.Add(letter);
			}
		}

		private void MouseOver(object sender, RoutedEventArgs e)
		{
			Label lbl = (Label)sender;
			int index = labels.IndexOf(lbl) + offset;

			foreach (Word w in words)
			{
				if (w.Letters.Contains(index))
				{
					for (int i = 0; i < w.NumLetters - 1; i++)
					{
						Line ln = new Line();
						ln.Stroke = lbl.Background;
						ln.StrokeThickness = 10;

						Point start = labels[w.Letters[i] - offset].TranslatePoint(new Point(letterWidth / 2, letterHeight / 2), canvas);
						ln.X1 = start.X;
						ln.Y1 = start.Y;

						Point end = labels[w.Letters[i + 1] - offset].TranslatePoint(new Point(letterWidth / 2, letterHeight / 2), canvas);
						ln.X2 = end.X;
						ln.Y2 = end.Y;

						canvas.Children.Add(ln);
					}

					foreach (KeyValuePair<int, Color> color in colors)
					{
						if (!w.Letters.Contains(color.Key))
						{
							Color clr = color.Value;
							clr.A = 100;
							labels[color.Key - offset].Background = new SolidColorBrush(clr);
						}
					}

					break;
				}
			}
		}
		private void MouseOut(object sender, RoutedEventArgs e)
		{
			canvas.Children.RemoveRange(0, canvas.Children.Count);

			foreach (KeyValuePair<int, Color> color in colors)
			{
				labels[color.Key - offset].Background = new SolidColorBrush(color.Value);
			}
		}

		private Dictionary<int, Color> GenerateColors(List<Word> words)
		{
			Dictionary<int, Color> dict = new Dictionary<int, Color>();
			double ratio = 0.618033988749;
			double H = new Random().NextDouble();
			Color currentColor;
			foreach (Word word in words)
			{
				H = (H + ratio) % 1;
				currentColor = HSVToRGB(H, .60, .95);

				foreach (int pos in word.Letters)
				{
					if ( !dict.ContainsKey(pos) )
						dict.Add(pos, currentColor);
				}
			}

			return dict;
		}

		public static Color HSVToRGB(double H, double S, double V)
		{
			int h_i = (int)(H * 6);
			double f = H * 6 - h_i;
			byte v = (byte)(255 * V);
			byte p = (byte)(255 * (V * (1 - S)));
			byte q = (byte)(255 * (V * (1 - f * S)));
			byte t = (byte)(255 * (V * (1 - (1 - f) * S)));

			if (h_i == 0)
				return Color.FromRgb(v, t, p);
			else if (h_i == 1)
				return Color.FromRgb(q, v, p);
			else if (h_i == 2)
				return Color.FromRgb(p, v, t);
			else if (h_i == 3)
				return Color.FromRgb(p, q, v);
			else if (h_i == 4)
				return Color.FromRgb(t, p, v);
			else if (h_i == 5)
				return Color.FromRgb(v, p, q);
			else
				throw new ArgumentOutOfRangeException();
		}
	}
}
