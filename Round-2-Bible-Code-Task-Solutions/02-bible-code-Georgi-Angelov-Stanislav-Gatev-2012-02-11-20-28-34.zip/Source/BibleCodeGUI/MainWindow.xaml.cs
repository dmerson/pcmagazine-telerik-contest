﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using ELS;
using System.Threading;

namespace BibleCodeGUI
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private ELSSearch els;
		private Thread elsThread;
		private bool isLoadingText = false;

		/*private object FindItemControl(ItemsControl itemsControl, string controlName, int index)
		{
			ContentPresenter container = itemsControl.ItemContainerGenerator.ContainerFromIndex(index) as ContentPresenter;
			container.ApplyTemplate();
			return container.ContentTemplate.FindName(controlName, container);
		}

		private void ItemsControl_LayoutUpdated(object sender, EventArgs e)
		{
			//Drawer.Children.Clear();

			//Label f = FindItemControl(itemcontrol, "lbl", 1) as Label;
			//Label l = FindItemControl(itemcontrol, "lbl", 5) as Label;

			//Point p1 = f.TransformToVisual(mygrid).Transform(new Point(f.ActualWidth / 2, f.ActualHeight / 2));
			//Point p2 = l.TransformToVisual(mygrid).Transform(new Point(l.ActualWidth / 2, l.ActualHeight / 2));

			//line.X1 = p1.X;
			//line.X2 = p2.X;
			//line.Y1 = p1.Y;
			//line.Y2 = p2.Y;

			//Drawer.Children.Add(line);
		}*/

		private void button3_Click(object sender, RoutedEventArgs e)
		{
			if (Clipboard.ContainsText())
			{
				text.Text = Clipboard.GetText(TextDataFormat.UnicodeText);
			}
		}

		public void OnDragOver(object sender, DragEventArgs e)
		{
			e.Effects = DragDropEffects.All;

			e.Handled = true;
		}

		private void text_Drop(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

				// Import each file in the TextBox
				text.Text = "";
				
				AutoResetEvent sync = new AutoResetEvent(true);
				foreach (string file in files)
				{
					if (!File.Exists(file))
					{
						MessageBox.Show("Invalid file, sorry!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
						break;
					}

					try
					{
						sync.WaitOne();
						sync.Reset();
						LoadFileText(file, sync);
					}
					catch (IOException)
					{
						MessageBox.Show("Cannot read the file, sorry!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
					}
				}
			}
			else if (e.Data.GetDataPresent(DataFormats.Text))
			{
				text.Text = (string)e.Data.GetData(DataFormats.UnicodeText);
			}
		}

		private void button2_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog fileDialog = new OpenFileDialog();
			fileDialog.Filter = "Text documents (.txt)|*.txt";

			var result = fileDialog.ShowDialog();

			if (result == true)
			{
				text.Text = "";
				LoadFileText(fileDialog.FileName);
			}
		}

		private void LoadFileText(string filename, AutoResetEvent sync = null)
		{
			var reader = new StreamReader(new FileStream(filename, FileMode.Open), Encoding.GetEncoding("windows-1251"));
			if (reader.EndOfStream)
				return;
			
			loadingProgress.Visibility = System.Windows.Visibility.Visible;
			mainLabel.Content = "Loading text from file...";
			textFromFile.IsEnabled = false;
			next.IsEnabled = false;
			textFromClipboard.IsEnabled = false;
			text.IsEnabled = false;
			this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.Indeterminate;
			isLoadingText = true;

			Thread worker = new Thread(delegate()
			{
				StringBuilder txt = new StringBuilder((int)reader.BaseStream.Length);
				string l;

				while (!reader.EndOfStream)
				{
					string lines = "";
					for (int i = 0; i < 30; i++)
					{
						if ((l = reader.ReadLine()) != null)
						{
							lines += l + "\n";
						}
					}
					txt.Append(lines);
					bool eof = reader.EndOfStream;

					this.text.Dispatcher.BeginInvoke(new Action(delegate()
					{
						text.AppendText(lines);

						if (eof)
						{
							loadingProgress.Visibility = System.Windows.Visibility.Hidden;
							mainLabel.Content = "Text load complete";
							textFromFile.IsEnabled = true;
							next.IsEnabled = true;
							textFromClipboard.IsEnabled = true;
							text.IsEnabled = true;
							isLoadingText = false;

							this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
						}
					}), System.Windows.Threading.DispatcherPriority.Background);
				}

				reader.Close();
				
				if (sync != null)
				{
					sync.Set();
				}
			});
			worker.IsBackground = true;
			worker.Start();
		}

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			SwitchState(State.inputWords);
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{

		}

		protected override void OnSourceInitialized(EventArgs e)
		{
			base.OnSourceInitialized(e);
			GlassHelper.ExtendGlassFrame(this, new Thickness(0, 35, 0, 35));
		}

		private enum State
		{
			inputText,
			inputWords,
			processing,
			result
		}
		private void SwitchState(State state)
		{
			if (state == State.inputText)
			{
				mainLabel.Visibility = System.Windows.Visibility.Visible;
				inputWords.Visibility = System.Windows.Visibility.Collapsed;
				inputText.Visibility = System.Windows.Visibility.Visible;
				processing.Visibility = System.Windows.Visibility.Collapsed;
				result.Visibility = System.Windows.Visibility.Collapsed;

				mainLabel.Content = "Add the text to search in";
				GlassHelper.ExtendGlassFrame(this, new Thickness(0, 35, 0, 35));
				this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
			}
			else if (state == State.inputWords)
			{
				mainLabel.Content = "Additional options";

				mainLabel.Visibility = System.Windows.Visibility.Visible;
				inputWords.Visibility = System.Windows.Visibility.Visible;
				inputText.Visibility = System.Windows.Visibility.Collapsed;
				processing.Visibility = System.Windows.Visibility.Collapsed;
				result.Visibility = System.Windows.Visibility.Collapsed;

				GlassHelper.ExtendGlassFrame(this, new Thickness(0, 35, 0, 35));
				this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
			}
			else if (state == State.processing)
			{
				GlassHelper.ExtendGlassFrame(this, new Thickness(-1));
				mainLabel.Visibility = System.Windows.Visibility.Hidden;
				inputWords.Visibility = System.Windows.Visibility.Collapsed;
				inputText.Visibility = System.Windows.Visibility.Collapsed;
				processing.Visibility = System.Windows.Visibility.Visible;
				result.Visibility = System.Windows.Visibility.Collapsed;
				this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.Indeterminate;


				timeElapsed.Content = "";
			}
			else if (state == State.result)
			{
				mainLabel.Content = "Result";

				mainLabel.Visibility = System.Windows.Visibility.Visible;
				inputWords.Visibility = System.Windows.Visibility.Collapsed;
				inputText.Visibility = System.Windows.Visibility.Collapsed;
				processing.Visibility = System.Windows.Visibility.Collapsed;
				result.Visibility = System.Windows.Visibility.Visible;

				grid.Dispatcher.BeginInvoke(new Action(delegate()
				{
					GlassHelper.ExtendGlassFrame(this, new Thickness(0, 35, 0, 35));
				}), System.Windows.Threading.DispatcherPriority.Loaded);
				this.TaskbarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
			}
		}

		private void text_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (!isLoadingText)
			{
				if (text.Text.Trim().Length > 0)
				{
					next.IsEnabled = true;
				}
				else
				{
					next.IsEnabled = false;
				}
			}
		}

		private void back_Click(object sender, RoutedEventArgs e)
		{
			SwitchState(State.inputText);
		}

		private void minSizeRows_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (maxSizeRows == null)
				return;

			int n;
			if (!int.TryParse(minSizeRows.Text, out n) || n < 1 || n > 50)
			{
				minSizeRows.Text = "1";
			}

			if (n > int.Parse(maxSizeRows.Text))
			{
				maxSizeRows.Text = n.ToString();
			}
		}

		private void minSizeCols_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (maxSizeCols == null)
				return;

			int n;
			if (!int.TryParse(minSizeCols.Text, out n) || n < 1 || n > 50)
			{
				minSizeCols.Text = "1";
			}

			if (n > int.Parse(maxSizeCols.Text))
			{
				maxSizeCols.Text = n.ToString();
			}
		}

		private void maxSizeRows_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (minSizeRows == null)
				return;

			int n;
			if (!int.TryParse(maxSizeRows.Text, out n) || n < 1 || n > 50)
			{
				maxSizeRows.Text = "50";
			}

			if (n < int.Parse(minSizeRows.Text))
			{
				minSizeRows.Text = n.ToString();
			}
		}

		private void maxSizeCols_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (minSizeCols == null)
				return;

			int n;
			if (!int.TryParse(maxSizeCols.Text, out n) || n < 1 || n > 50)
			{
				maxSizeCols.Text = "50";
			}

			if (n < int.Parse(minSizeCols.Text))
			{
				minSizeCols.Text = n.ToString();
			}
		}

		private void minSpacing_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (maxSpacing == null)
				return;

			int n;
			if (!int.TryParse(minSpacing.Text, out n) || n < 1 || n > 2500)
			{
				minSpacing.Text = "1";
			}

			if (n > int.Parse(maxSpacing.Text))
			{
				maxSpacing.Text = n.ToString();
			}
		}

		private void maxSpacing_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (minSpacing == null)
				return;

			int n;
			if (!int.TryParse(maxSpacing.Text, out n) || n < 1 || n > 2500)
			{
				maxSpacing.Text = "2500";
			}

			if (n < int.Parse(minSpacing.Text))
			{
				minSpacing.Text = n.ToString();
			}
		}

		private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (search == null || wordsBox.Text == defaultText)
				return;

			if (wordsBox.Text.Trim().Length > 0)
			{
				search.IsEnabled = true;
			}
			else
			{
				search.IsEnabled = false;
			}
		}

		System.Timers.Timer time = null;
		DateTime startTime;
		private void search_Click(object sender, RoutedEventArgs e)
		{
			SwitchState(State.processing);

			time = new System.Timers.Timer(1000);
			time.AutoReset = true;
			time.Elapsed += timerTick;
			time.Start();

			startTime = DateTime.Now;

			// Start the algorithm
			els = new ELSSearch();
			els.MinSizeCols = int.Parse(minSizeCols.Text);
			els.MaxSizeCols = int.Parse(maxSizeCols.Text);
			els.MinSizeRows = int.Parse(minSizeRows.Text);
			els.MaxSizeRows = int.Parse(maxSizeRows.Text);
			els.MinSpacing = int.Parse(minSpacing.Text);
			els.MaxSpacing = int.Parse(maxSpacing.Text);
			els.AddWords(wordsBox.Text);
			els.AddToText(text.Text);
			elsThread = new Thread(waitAlgorithm);
			elsThread.IsBackground = true;
			elsThread.Start();
		}
		private void waitAlgorithm()
		{
			els.Search();

			if (!els.Interrupted)
			{
				this.Dispatcher.BeginInvoke(new Action(SearchDone));
			}
		}
		private void SearchDone()
		{
			grid.SetELSGrid(els);
			SwitchState(State.result);
			mainLabel.Content = "Found " + els.FoundWords.Count + " words";

			//MessageBox.Show("Found " + els.FoundWords.Count + " words");
		}

		private void timerTick(object source, System.Timers.ElapsedEventArgs e)
		{
			TimeSpan diff = DateTime.Now - startTime;

			string time = "";
			if ((int)diff.TotalHours > 0)
			{
				time = ((int)diff.TotalHours == 1 ? "1 hour, " : (int)diff.TotalHours + " hours, ") + (diff.Minutes == 1 ? "1 minute" : diff.Minutes + " minutes and ") + (diff.Seconds == 1 ? "1 second" : diff.Seconds + " seconds");
			}
			else if (diff.Minutes > 0)
			{
				time = (diff.Minutes == 1 ? "1 minute" : diff.Minutes + " minutes and ") + (diff.Seconds == 1 ? "1 second" : diff.Seconds + " seconds");
			}
			else
			{
				time = (diff.Seconds == 1 ? "1 second" : diff.Seconds + " seconds");
			}

			timeElapsed.Dispatcher.BeginInvoke(new Action(delegate()
			{
				timeElapsed.Content = "Elapsed time: " + time;
			}));
		}

		private void cancelSearch_Click(object sender, RoutedEventArgs e)
		{
			SwitchState(State.inputWords);

			if (time != null)
			{
				time.Stop();
			}

			if (elsThread != null && elsThread.IsAlive)
			{
				els.Interrupt();
			}
		}

		private const string defaultText = "Separated by space or comma";
		private void wordsBox_GotFocus(object sender, RoutedEventArgs e)
		{
			if (wordsBox.Text == defaultText)
			{
				wordsBox.Text = "";
				wordsBox.Foreground = Brushes.Black;
			}
		}

		private void wordsBox_LostFocus(object sender, RoutedEventArgs e)
		{
			if (wordsBox.Text == "")
			{
				wordsBox.Text = defaultText;
				wordsBox.Foreground = Brushes.Gray;
			}
		}

		private void maxSizeCols_GotFocus(object sender, RoutedEventArgs e)
		{
			((TextBox)sender).SelectAll();
		}
	}
}