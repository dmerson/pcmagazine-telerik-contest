﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ELS
{
    public class Word : IComparable<Word>
	{
		private string word;

		private int numLetters, spacing;
		public int NumLetters
		{
			get { return numLetters; }
		}
		public int Spacing
		{
			get { return spacing; }
		}

		private List<int> letters;
		public List<int> Letters
		{
			get { return letters; }
		}

		public Word(string word, List<int> letters)
		{
			this.word = word;
			this.letters = letters;
			this.numLetters = letters.Count;

			if ( NumLetters > 1 )
			{
				this.spacing = letters[1] - letters[0];
			}
			else
			{
				this.spacing = 0;
			}
		}

        public int FirstLetter
        {
            get
            {
                return letters[0];
            }
        }

		public int LastLetter
		{
			get
			{
				return letters[letters.Count - 1];
			}
		}

		public int AbsoluteFirstLetter
		{
			get
			{
				if (spacing > 0)
				{
				return letters[0];
				}
				else
				{
					return letters[letters.Count - 1];
				}
			}
		}

		public int AbsoluteLastLetter
		{
			get
			{
				if (spacing < 0)
				{
					return letters[0];
				}
				else
				{
				return letters[letters.Count - 1];
				}
			}
		}

		public override string ToString()
		{
			return word;
		}

        public int CompareTo(Word other)
        {
            if (Math.Abs(this.Spacing) < Math.Abs(other.Spacing))
                return -1;
            else if (this.Spacing == other.Spacing)
                return 0;
            else
                return 1;
        }
    }
}
