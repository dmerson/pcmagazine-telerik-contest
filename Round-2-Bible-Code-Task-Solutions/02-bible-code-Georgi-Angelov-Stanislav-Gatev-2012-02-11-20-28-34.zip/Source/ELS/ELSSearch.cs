﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELS
{
	public class ELSSearch
	{
		public StringBuilder text;
		private List<string> words = new List<string>();
		private Dictionary<char, List<int>> chars = new Dictionary<char, List<int>>();
		private Dictionary<char, int> charsL = new Dictionary<char, int>();
		private Dictionary<char, int> charsM = new Dictionary<char, int>();
		private List<List<Word>> allWords = new List<List<Word>>();
		private int searchLength = 5000, leftPos = 0, rightPos = 0;
		private double max = 0;

		private bool interrupted = false;
		public bool Interrupted
		{
			get { return interrupted; }
		}

		private List<Word> foundWords = new List<Word>();
		public List<Word> FoundWords
		{
			get { return foundWords; }
		}

		private int foundOffset = 0, foundCols = 0, foundRows = 0;
		public int FoundRows
		{
			get { return foundRows; }
		}
		public int FoundCols
		{
			get { return foundCols; }
		}
		public int FoundOffset
		{
			get { return foundOffset; }
		}

		private int minSizeRows = 1, minSizeCols = 1,
					maxSizeRows = 50, maxSizeCols = 50,
					minSpacing = 1, maxSpacing = 2500;

		public int MaxSpacing
		{
			get { return maxSpacing; }
			set { maxSpacing = value; }
		}
		public int MinSpacing
		{
			get { return minSpacing; }
			set { minSpacing = value; }
		}
		public int MaxSizeCols
		{
			get { return maxSizeCols; }
			set { maxSizeCols = value; }
		}
		public int MaxSizeRows
		{
			get { return maxSizeRows; }
			set { maxSizeRows = value; }
		}
		public int MinSizeCols
		{
			get { return minSizeCols; }
			set { minSizeCols = value; }
		}
		public int MinSizeRows
		{
			get { return minSizeRows; }
			set { minSizeRows = value; }
		}

		public ELSSearch()
		{
			text = new StringBuilder(10000000);
		}

		public void Interrupt()
		{
			interrupted = true;
		}
		public void Search()
		{
			interrupted = false;

			for (int i = leftPos; i <= rightPos; i++)
			{
				if (chars.ContainsKey(text[i]))
				{
					chars[text[i]].Add(i);
				}
			}

			for (int i = 0; i < words.Count; i++)
			{
				allWords.Add(new List<Word>());
			}
			Parallel.For(0, words.Count, delegate(int i)
			{
				if (words[i].Length > 2)
				{
					FindWords(i);
				}
			});

			if (Interrupted)
				return;

			GetMatrix();
		}

		private void GetMatrix()
		{
			bool foundAll = false;

			//for (int cols = 50; cols > 0; cols--)
			Parallel.For(MinSizeCols - 1, MaxSizeCols - 1, delegate(int ppp)
			{
				int cols = MaxSizeCols - ppp;

				for (int offset = leftPos; offset < Math.Max(cols, rightPos - cols * MaxSizeRows); offset++)
				{
					if (foundAll || Interrupted)
						return;

					List<Word> currentWords = new List<Word>();
					int rows = Math.Min((rightPos - offset) / cols, MaxSizeRows);

					if (rows < MinSizeRows)
						break;

					// Check 1 and 2-letter words
					foreach (string word in words)
					{
						if (word.Length <= 2)
						{
							int firstIndex = findLetterIndex(word[0], offset, rows * cols);
							int secondIndex = -2;

							if (firstIndex != -1)
							{
								List<int> letters = new List<int>();
								letters.Add(firstIndex);

								if (word.Length == 2)
								{
									secondIndex = findLetterIndex(word[1], Math.Max(offset, firstIndex - MaxSpacing), Math.Min(rows * cols, firstIndex + MaxSpacing), firstIndex);

									if (secondIndex == -1)
										continue;

									letters.Add(secondIndex);
								}

								currentWords.Add(new Word(word, letters));
							}

							continue;
						}
					}

					foreach (List<Word> wordList in allWords)
					{
						foreach (Word word in wordList)
						{
							if (word.AbsoluteFirstLetter < offset || word.AbsoluteLastLetter > offset + rows * cols - 1)
								continue;

							int startLetterIndex = word.FirstLetter - offset;
							int lastLetterCol = (word.NumLetters - 1) * ((startLetterIndex + word.Spacing) % cols - startLetterIndex % cols) + startLetterIndex % cols;
							if (lastLetterCol >= 0 && lastLetterCol < cols)
							{
								currentWords.Add(word);
								break;
							}
						}
					}
					lock (foundWords)
					{
						if (currentWords.Count > foundWords.Count)
						{
							foundWords = currentWords;
							foundCols = cols;
							foundOffset = offset;
							foundRows = rows;
						}
						if (foundWords.Count == allWords.Count)
						{
							foundAll = true;
							break;
						}
					}
				}

				if (foundAll)
					return;
			});
		}

		private int findLetterIndex(char letter, int offset, int length, int lastLetterIndex = -1)
		{
			foreach (int p in chars[letter])
			{
				if (p > offset && p < offset + length && (lastLetterIndex == -1 || Math.Abs(lastLetterIndex - p) >= MinSpacing))
				{
					return p;
				}
			}

			return -1;
		}

		public void FindWords(int index)
		{
			foreach (int firstLetterPosition in chars[words[index][0]])
			{
				int maxSpacing = Math.Min((text.Length - firstLetterPosition) / words[index].Length, MaxSpacing);
				int minSpacing = Math.Max((0 - firstLetterPosition) / words[index].Length, -MaxSpacing);

				foreach (int secondLetterPosition in chars[words[index][1]])
				{
					if (Interrupted)
						return;

					int spacing = secondLetterPosition - firstLetterPosition;
					if (spacing <= maxSpacing && spacing >= minSpacing && Math.Abs(spacing) >= MinSpacing)
					{
						List<int> letterPositions = new List<int>();
						letterPositions.Add(firstLetterPosition);
						letterPositions.Add(secondLetterPosition);
						int ind = 2;
						while (firstLetterPosition + ind * spacing < text.Length &&
							ind < words[index].Length &&
							text[firstLetterPosition + ind * spacing] == words[index][ind])
						{
							letterPositions.Add(firstLetterPosition + ind * spacing);
							ind++;
						}
						if (ind == words[index].Length)
						{
							allWords[index].Add(new Word(words[index], letterPositions));
						}
					}
				}
			}
		}

		private int index = 0;
		public void AddToText(char symbol)
		{
			symbol = char.ToUpper(symbol);
			text.Append(symbol);

			if (charsL.ContainsKey(symbol))
			{
				charsL[symbol]++;
			}
			if (index - searchLength >= 0)
			{
				if (charsL.ContainsKey(text[index - searchLength]))
				{
					charsL[text[index - searchLength]]--;
					double newMax = charsL[text[index - searchLength]] / charsM[text[index - searchLength]];
					if (newMax > max)
					{
						max = newMax;
						rightPos = index;
						leftPos = index - searchLength;
					}
				}
			}
			else
			{
				rightPos = index;
			}
			index++;
		}

		public void AddToText(string txt)
		{
			foreach (char c in txt)
			{
				if (char.IsLetterOrDigit(c))
				{
					AddToText(c);
				}
			}
		}

		public void AddWord(string word)
		{
			word = word.ToUpper();
			words.Add(word);

			int l = 2; // До колко букви да индексира
			if (word.Length == 1)
				l = 1;

			for (int j = 0; j < l; j++)
			{
				if (!chars.ContainsKey(word[j]))
				{
					chars.Add(word[j], new List<int>());
					if (!charsL.ContainsKey(word[j]))
					{
						charsL.Add(word[j], 0);
					}
				}
				if (charsM.ContainsKey(word[j]))
				{
					charsM[word[j]]++;
				}
				else
				{
					charsM[word[j]] = 1;
				}
			}
			for (int j = 2; j < word.Length; j++)
			{
				if (!charsL.ContainsKey(word[j]))
				{
					charsL.Add(word[j], 0);
				}
				if (charsM.ContainsKey(word[j]))
				{
					charsM[word[j]]++;
				}
				else
				{
					charsM[word[j]] = 1;
				}
			}
		}

		public int AddWords(string text)
		{
			int num = 0;
			string word = "";

			foreach (char c in text)
			{
				if (char.IsLetterOrDigit(c))
				{
					word += c;
				}
				else
				{
					if (word.Length > 0)
					{
						AddWord(word);
						num++;
						word = "";
					}
				}
			}

			if (word.Length > 0)
			{
				AddWord(word);
				num++;
			}

			return num;
		}
	}
}
