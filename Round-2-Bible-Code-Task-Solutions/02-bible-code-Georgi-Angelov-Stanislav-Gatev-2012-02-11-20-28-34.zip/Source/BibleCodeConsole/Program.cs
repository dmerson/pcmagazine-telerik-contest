﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using ELS;

namespace BibleCodeConsole
{
    class Program
    {
		public static ELSSearch els;
       
		private static void ReadWords(int linesToRead)
		{
			string word;
			for (int i = 0; i < linesToRead; i++)
			{
				word = Console.ReadLine();
				els.AddWord(word);
			}
		}

		private static void ReadLines(int linesToRead)
        {
			int linesRead = 0;
            while (linesRead < linesToRead)
            {
                char symbol = (char)Console.Read();
                if (char.IsLetterOrDigit(symbol))
                {
					els.AddToText(symbol);
                }
                else if (symbol == '\n')
                {
                    linesRead++;
                }
            }
        }

		static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.GetEncoding("windows-1251");
            Console.OutputEncoding = Encoding.GetEncoding("windows-1251");

			els = new ELSSearch();
			
            int linesToRead = int.Parse(Console.ReadLine());

			ReadWords(linesToRead);

			linesToRead = int.Parse(Console.ReadLine());

            ReadLines(linesToRead);

			els.Search();

            Console.WriteLine(els.FoundOffset + 1 + " " + els.FoundRows + " " + els.FoundCols);
			PrintMatrix();
            Console.WriteLine(els.FoundWords.Count);
            foreach (Word w in els.FoundWords)
            {
                int startCol = w.FirstLetter / els.FoundCols + 1;
                int startRow = (w.FirstLetter - els.FoundOffset) % els.FoundCols + 1;
                int rowStep = (w.Letters[1] - els.FoundOffset) / els.FoundCols -
                    (w.Letters[0] - els.FoundOffset) / els.FoundCols;
                int colStep = (w.Letters[1] - els.FoundOffset) % els.FoundCols -
                    (w.Letters[0] - els.FoundOffset) % els.FoundCols;
                
                Console.WriteLine(w + " " + startCol + " " + startRow +
                    " " + rowStep + " " + colStep);
            }
        }		

		private static void PrintMatrix()
		{
			int counter = 1;
            int MatrixLast = els.FoundOffset + els.FoundCols * els.FoundRows;
            for (int i = els.FoundOffset; i < MatrixLast; i++)
			{
			    Console.Write(els.text[i]);
                if (counter % els.FoundCols == 0)
                {
                    Console.WriteLine();
                }
                counter++;
			}
		}
    }
}

