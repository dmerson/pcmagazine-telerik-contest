﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Contest2Simulator
{
	class Program
	{
		static string[] words = { "Наков", "пак", "ще", "пие", "бира" };
		static string[] sentences = { 
"Математици доказаха, че тайните кодове от Библията могат да се получават случайно като се изпробват твърде многото варианти за думи и букви.",
"Ако рядка буква не се среща, сменяме думата със синоним.",
"Пробвайте сами и ще се убедите!"
									};

		static StreamReader reader;
		static Process p;

		static void Main(string[] args)
		{
			p = new Process();
			p.StartInfo.FileName = Environment.CurrentDirectory + @"\..\..\..\..\bin\Debug\Contest2";
			p.StartInfo.UseShellExecute = false;
			p.StartInfo.RedirectStandardError = false;
			p.StartInfo.RedirectStandardInput = true;
			p.StartInfo.RedirectStandardOutput = true;

			p.Start();
			reader = p.StandardOutput;
			StreamWriter writer = p.StandardInput;

			Thread thread = new Thread(RedirectToConsole);
			thread.Start();

			writer.WriteLine(words.Length);
			foreach (string word in words)
			{
				writer.WriteLine(word);
			}

			writer.WriteLine(sentences.Length * 20000);
            for (int i = 0; i < 20000; i++)
            {
			foreach (string sentence in sentences)
			{
				writer.WriteLine(sentence);
			}
                
            }

			p.WaitForExit();
		}

		static void RedirectToConsole()
		{
			try
			{
				while (!p.HasExited)
				{
					Console.WriteLine(reader.ReadLine());
				}
			}
			catch(Exception) { }
		}
	}
}
