﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

public class AlgorithmExecutor
{
    public string AlgorithmFilename { get; private set; }
    public string AlgorithmFullPath { get; private set; }
    public string AlgorithmPath { get; private set; }
    public string AlgorithmOwner { get; private set; }
    protected System.Diagnostics.Process algorithm;
    System.Diagnostics.ProcessStartInfo algorithmStartInfo;

    public AlgorithmExecutor(string algorithmFolder)
    {
        this.AlgorithmPath = algorithmFolder;

        string algorithmExe = System.IO.Directory.GetFiles(this.AlgorithmPath).First(name => name.Contains(".exe") || name.Contains(".bat") || name.Contains(".class"));
        this.AlgorithmOwner = this.AlgorithmPath.Substring(this.AlgorithmPath.LastIndexOf('\\') + 1);

        this.AlgorithmFullPath = algorithmExe;
        this.AlgorithmFilename = algorithmExe.Substring(algorithmExe.LastIndexOf('\\') + 1, algorithmExe.LastIndexOf('.') - algorithmExe.LastIndexOf('\\'));

		this.algorithmStartInfo = new System.Diagnostics.ProcessStartInfo(algorithmExe);
        algorithmStartInfo.ErrorDialog = false;
        algorithmStartInfo.WorkingDirectory = algorithmFolder;
        algorithmStartInfo.RedirectStandardInput = true;
        algorithmStartInfo.RedirectStandardOutput = true;
        algorithmStartInfo.RedirectStandardError = true;
        algorithmStartInfo.CreateNoWindow = true;
        algorithmStartInfo.UseShellExecute = false;

        //just to test if it runs at all
        //this.StartAlgorithm();
        //this.KillAlgorithm();
    }

    public void StartAlgorithm()
    {
        this.algorithm = System.Diagnostics.Process.Start(algorithmStartInfo);
    }

    public void KillAlgorithm()
    {
        try
        {
            this.algorithm.Kill();
        }
        catch
        {
        }
    }

    public void StartWaitAndKill(int waitMilliseconds)
    {
        this.StartAlgorithm();
        Thread.Sleep(waitMilliseconds*2);
        this.KillAlgorithm();
    }
}