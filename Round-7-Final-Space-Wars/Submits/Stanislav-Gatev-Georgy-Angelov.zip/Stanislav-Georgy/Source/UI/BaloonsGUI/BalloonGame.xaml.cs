﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace BaloonsGUI
{
	/// <summary>
	/// Interaction logic for BalloonGame.xaml
	/// </summary>
	public partial class BalloonGame : UserControl
	{
		public delegate void GameEndDelegate(double Score, int Points, int Moves, int rows, int cols);
		public event GameEndDelegate GameEnd;
  

		public double balloonDimensions = 20;

		public BalloonGame()
		{
			InitializeComponent();
		}

		public Image[,] balloons;

		public void InitBalloons(char[,] matrix)
		{
			this.Dispatcher.BeginInvoke(new Action(delegate() {
			balloonContainer.Children.Clear();
			balloonContainer.Width = 50 * balloonDimensions;
			balloonContainer.Height = 40 * balloonDimensions;
			
			balloons = new Image[40, 50];

			
			for (int i = 0; i < 40; i++)
			{
				for (int j = 0; j < 50; j++)
				{
					var img = new Image();
					balloons[i, j] = img;

					if (matrix[i, j] == 'r' || matrix[i, j] == 'l' || matrix[i, j] == 'u' || matrix[i, j] == 'd')
					{
						if (matrix[i, j] == 'r')
							img.RenderTransform = new RotateTransform(270);
						else if (matrix[i, j] == 'u')
							img.RenderTransform = new RotateTransform(180);
						else if (matrix[i, j] == 'l')
							img.RenderTransform = new RotateTransform(90);
						img.RenderTransformOrigin = new Point(0.5, 0.5);

						img.Source = (ImageSource)FindResource("boen");
					}
					else if (matrix[i, j] == '1' || matrix[i, j] == '2')
						img.Source = (ImageSource)FindResource("tovaren");
					else if (matrix[i, j] == '#')
						img.Source = (ImageSource)FindResource("asteroid");
					else if (matrix[i, j] == 'o')
						img.Source = (ImageSource)FindResource("rocket");
					else
						continue;

					//img.RenderTransform = new TranslateTransform(margin.Left, margin.Top);

					img.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
					img.VerticalAlignment = System.Windows.VerticalAlignment.Top;
					img.Margin = new Thickness(j * balloonDimensions, i * balloonDimensions, 0, 0);
					img.Width = balloonDimensions;
					img.Height = balloonDimensions;

					balloonContainer.Children.Add(img);
				}
			}
			}), DispatcherPriority.Render);
		}

		public void Clear()
		{
			this.Dispatcher.BeginInvoke(new Action(delegate()
			{
				balloonContainer.Children.Clear();
			}));
		}

		private void RemoveBalloonImage(int col, int row)
		{
			balloonContainer.Children.Remove(balloons[col, row]);
			balloons[col, row] = null;
		}
	}
}
