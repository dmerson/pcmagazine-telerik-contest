﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaloonsGUI;

namespace SpaceWarsEngine
{
    public class WorldData
    {
        public int MatrixRows {get; private set;}
        public int MatrixCols {get; private set;}
        char[,] matrix;
        StringBuilder log;
        Dictionary<string, PlayerStat> playerStats;

		public static BalloonGame window;

        public WorldData(int matrixRows, int matrixCols, ICollection<string> playerNames)
        {
            this.MatrixRows = matrixRows;
            this.MatrixCols = matrixCols;
            this.matrix = new char[matrixRows, matrixCols];
            this.log = new StringBuilder();
            this.playerStats = new Dictionary<string, PlayerStat>();

            foreach (var name in playerNames)
            {
                this.playerStats[name] = new PlayerStat(name, 0, 0);
            }
        }

        public PlayerStat GetPlayerStatCopy(string playerName)
        {
            PlayerStat statToCopy = this.playerStats[playerName];
            return new PlayerStat(statToCopy.PlayerName, statToCopy.Kills, statToCopy.Deaths);
        }

        /// <summary>
        /// Updates the player stats, incresing the kills of the killer and increasing the deaths of the victim
        /// </summary>
        /// <param name="report">KillReport containing the killer's name and the victim's name</param>
        public void ReportKill(KillReport report)
        {
            this.playerStats[report.KillerName].Kills++;
            if (this.playerStats.ContainsKey(report.VictimName))
            {
                this.playerStats[report.VictimName].Deaths++;
            }
        }

        public void ReportDeath(string diedPlayerName)
        {
            this.playerStats[diedPlayerName].Deaths++;
        }

        public void ReportFriendlyFire(string firingPlayerName)
        {
            this.playerStats[firingPlayerName].Kills--;
        }

        public string GetLogString()
        {
            return this.log.ToString();
        }

        public void AddToLog(string message)
        {
            this.log.Append(message);
            this.log.Append('\n');
        }

        public void Render(LinkedList<MatrixObject> objects)
        {
            if (this.matrix != null)
            {
                foreach (var matrixObject in objects)
                {
                    if (matrixObject.IsAlive() && matrixObject.IsInWorld())
                    {
                        this.matrix[matrixObject.Row, matrixObject.Col] = matrixObject.GetVisual();
                    }
                }

				window.InitBalloons(this.matrix);
            }
        }

        public void Clear()
        {
            for (int row = 0; row < this.MatrixRows; row++)
            {
                for (int col = 0; col < MatrixCols; col++)
                {
                    this.matrix[row, col] = ' ';
                }
            }
        }

        public string GetPrintText()
        {
            StringBuilder textToPrint = new StringBuilder();
            for (int row = 0; row < this.MatrixRows; row++)
            {
                for (int col = 0; col < MatrixCols; col++)
                {
                    textToPrint.Append(matrix[row, col]);
                }
                textToPrint.Append("\r\n");
            }
            return textToPrint.ToString();
        }

        public void Print()
        {
            StringBuilder textToPrint = new StringBuilder();
            for (int row = 0; row < this.MatrixRows; row++)
            {
                for (int col = 0; col < MatrixCols; col++)
                {
                    textToPrint.Append(matrix[row, col]);
                }
                textToPrint.Append("\r\n");
            }
            Console.Write(textToPrint);
        }
    }
}
