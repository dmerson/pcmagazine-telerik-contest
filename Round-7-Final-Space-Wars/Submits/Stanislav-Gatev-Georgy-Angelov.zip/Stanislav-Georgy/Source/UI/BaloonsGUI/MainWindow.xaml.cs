﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BaloonsGUI
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

        private void buttonHuman_Click(object sender, RoutedEventArgs e)
        {
        }

        private void buttonExit_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

		private void buttonComputer_Click(object sender, RoutedEventArgs e)
		{
			/*OpenFileDialog dlg = new OpenFileDialog();
			OpenFileDialog dlg2 = new OpenFileDialog();

			if ((bool)dlg.ShowDialog())
			{
				if ((bool)dlg2.ShowDialog())
				{
					GameWindow gameWindow = new GameWindow(dlg.FileName, dlg2.FileName);*/
					GameWindow gameWindow = new GameWindow();
					gameWindow.Show();
			/*	}
			}*/
		}
	}
}
