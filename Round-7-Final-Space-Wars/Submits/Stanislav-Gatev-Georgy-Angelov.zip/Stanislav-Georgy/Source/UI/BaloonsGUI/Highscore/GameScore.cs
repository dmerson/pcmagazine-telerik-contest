﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaloonsGUI.Highscore
{
	[Serializable]
	public class GameScore
		: IComparable
	{
		public string Name   { get; set; }

		public double Score  { get; set; }
		public int    Points { get; set; }
		public int    Moves  { get; set; }
		public int    Rows   { get; set; }
		public int    Cols   { get; set; }

		public string Size
		{
			get
			{
				return Cols + "x" + Rows;
			}
		}

		public int CompareTo(object obj)
		{
			return ((GameScore)obj).Score.CompareTo(Score);
		}
	}
}
