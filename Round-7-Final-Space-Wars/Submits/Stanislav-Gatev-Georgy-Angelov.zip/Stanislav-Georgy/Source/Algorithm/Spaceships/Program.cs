﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
	class Program
	{
		static void Main(string[] args)
		{
			GameLogic game = new GameLogic();
			game.ReadMatrix();

			game.LoadLastState();
			game.FindEntities();
			game.GetRockets();

			game.GetGraph();


			List<int> route;
			if (game.enemyShips.Count > 0)
				route = game.FindRoute();
			else
				route = game.RouteToGlory();

			if (!game.Defences(route))
				game.DestroyShips(route);


			game.SaveState();
			game.Output();
		}

	}
}
