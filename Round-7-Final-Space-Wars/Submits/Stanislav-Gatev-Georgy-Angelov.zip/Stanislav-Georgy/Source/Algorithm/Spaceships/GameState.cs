﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
	[Serializable]
	public class GameState
	{
		// row, col, direction
		public Tuple<int, int, Direction> enemy;
		public Tuple<int, int, Direction> ship;
		public List<Tuple<int, int, Direction>> rockets;
	}

	public enum Direction
	{
		Left,
		Right,
		Up,
		Down
	}
}
