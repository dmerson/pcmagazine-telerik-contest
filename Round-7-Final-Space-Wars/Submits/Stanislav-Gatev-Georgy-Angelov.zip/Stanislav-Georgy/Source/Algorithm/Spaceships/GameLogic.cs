﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
	public class GameLogic
	{
		public char[,] matrix;
		public int move;
		public char myShipsName;
		public char enemyShipsName;
		public int shipPositionRow;
		public int shipPositionCol;

		public List<List<int>> graph;
		public List<int> enemyShips;
		public GameState lastState;
		public GameState state;

		public Direction direction;
		public Direction lastDirection;
		public bool IsEngineStart = false;
		public bool IsShoot = false;

		public void ReadMatrix()
		{
			matrix = new char[40,50];

			var file = new StreamReader(new FileStream("input.txt", FileMode.Open));
			//1
			move = int.Parse(file.ReadLine());

			if (move == 0)
				File.Delete("state.bin");

			//2
			var pos = file.ReadLine().Split(' ');
			shipPositionRow = int.Parse(pos[0]);
			shipPositionCol = int.Parse(pos[1]);

			//3
			myShipsName = file.ReadLine()[0];

			if (myShipsName == '1')
				enemyShipsName = '2';
			else
				enemyShipsName = '1';
			
			//4
			for (int i = 0; i < 40; i++)
			{
				var row = file.ReadLine();
				for (int j = 0; j < 50; j++)
				{
					matrix[i, j] = row[j];
				}
			}

			file.Close();
		}

		public void GetGraph()
		{
			graph = new List<List<int>>(2000);
			for (int i = 0; i < 2000; i++)
			{
				graph.Add(new List<int>());
			}

			foreach (var rocket in state.rockets)
			{
				if (rocket.Item3 == Direction.Up)
				{
					for (int n = 0; n < 4; n++)
						if (rocket.Item1 - n >= 0)
							matrix[rocket.Item1 - n, rocket.Item2] = 'x';
				}
				else if (rocket.Item3 == Direction.Down)
				{
					for (int n = 0; n < 4; n++)
						if (rocket.Item1 + n < 40)
							matrix[rocket.Item1 + n, rocket.Item2] = 'x';
				}
				else if (rocket.Item3 == Direction.Left)
				{
					for (int n = 0; n < 4; n++)
						if (rocket.Item2 - n >= 0)
						matrix[rocket.Item1, rocket.Item2 - n] = 'x';
				}
				else if (rocket.Item3 == Direction.Right)
				{
					for (int n = 0; n < 4; n++)
						if (rocket.Item2 + n < 50)
						matrix[rocket.Item1, rocket.Item2 + n] = 'x';
				}
			}

			for (int i = 0; i < 40; i++)
			{
				for (int j = 0; j < 50; j++)
				{
					int lbl = i * 50 + j;
					List<int> neighbours = graph[lbl];

					if (j - 1 >= 0 && (matrix[i, j - 1] == ' '))
					{
						neighbours.Add(i * 50 + j - 1);
					}
					if (j + 1 < 50 && (matrix[i, j + 1] == ' '))
					{
						neighbours.Add(i * 50 + j + 1);
					}
					if (i - 1 >= 0 && (matrix[i -1, j] == ' '))
					{
						neighbours.Add((i-1) * 50 + j);
					}
					if (i + 1 < 40 && (matrix[i + 1, j] == ' '))
					{
						neighbours.Add((i+1) * 50 + j);
					}

					//for (int horizontal = j - 1; horizontal <= j + 1; horizontal++)
					//{
					//	for (int vertical = i - 1; vertical <= i + 1; vertical++)
					//	{
					//		if (horizontal < 0 || vertical < 0 || horizontal >= 50 ||
					//			vertical >= 40 || (horizontal == j && vertical == i) )
					//			continue;

					//		if (matrix[vertical, horizontal] == ' ')
					//		{
					//			neighbours.Add(vertical * 50 + horizontal);
					//		}
					//	}
					//}
				}
			}
		}

		public void FindEntities()
		{
			state = new GameState();
			state.rockets = new List<Tuple<int, int, Direction>>();
			enemyShips = new List<int>();
			for (int i = 0; i < 40; i++)
			{
				for (int j = 0; j < 50; j++)
				{
					if (shipPositionRow == i && shipPositionCol == j)
					{
						if (matrix[i, j] == 'u')
							direction = Direction.Up;
						else if (matrix[i, j] == 'd')
							direction = Direction.Down;
						else if (matrix[i, j] == 'l')
							direction = Direction.Left;
						else if (matrix[i, j] == 'r')
							direction = Direction.Right;

						lastDirection = direction;
						state.ship = new Tuple<int, int, Direction>(i, j, direction);

						continue;
					}

					if (matrix[i, j] == 'u')
						state.enemy = new Tuple<int, int, Direction>(i, j, Direction.Up);
					else if (matrix[i, j] == 'd')
						state.enemy = new Tuple<int, int, Direction>(i, j, Direction.Down);
					else if (matrix[i, j] == 'l')
						state.enemy = new Tuple<int, int, Direction>(i, j, Direction.Left);
					else if (matrix[i, j] == 'r')
						state.enemy = new Tuple<int, int, Direction>(i, j, Direction.Right);
					else if (matrix[i, j] == enemyShipsName)
						enemyShips.Add(i * 50 + j);
				}
			}
		}

		public void LoadLastState()
		{
			try
			{
				IFormatter formatter = new BinaryFormatter();
				using (Stream stream = new FileStream("state.bin", FileMode.Open, FileAccess.Read, FileShare.None))
				{
					lastState = (GameState)formatter.Deserialize(stream);
				}
			}
			catch (FileNotFoundException)
			{
				FindEntities();
				lastState = state;
			}
		}

		public void SaveState()
		{

			IFormatter formatter = new BinaryFormatter();
			Stream stream = new FileStream("state.bin", FileMode.Create, FileAccess.Write, FileShare.None);
			formatter.Serialize(stream, state);
			stream.Close();
		}

		//public void BFS(int start, int end)
		//{
		//	Queue<int> q = new Queue<int>();

		//	int c = start;

		//	while (c != end)
		//	{
		//		foreach (var n in graph[c])
		//		{
		//			q.Enqueue(n);
		//		}
		//		c = q.Dequeue();
		//	}
		//}

		public List<int> Dijkstra(int start, List<int> ends)
		{
			int[] prev = new int[2000];
			int[] dist = new int[2000];
			List<int> Q = new List<int>(2000);
			for (int i = 0; i < 2000; i++)
			{
				dist[i] = int.MaxValue;
				prev[i] = -1;
				Q.Add(i);
			}

			dist[start] = 0;

			for (int i = 0; i < graph[start].Count; i++)
			{
				dist[graph[start][i]] = 1;
			}
			Q.Remove(start);

			while (Q.Count > 0)
			{
				int u = Q[0];

				foreach (int i in Q)
				{
					if (dist[i] < dist[u])
						u = i;
				}

				if (dist[u] == int.MaxValue)
					break;

				Q.Remove(u);

				foreach (var n in graph[u])
				{
					int alt = dist[u] + 1;
					if (alt < dist[n])
					{
						dist[n] = alt;
						prev[n] = u;
					}
				}
			}

			int end = ends[0];
			foreach (var e in ends)
			{
				if (dist[e] < dist[end])
					end = e;
			}

			List<int> path = new List<int>();
			path.Add(end);
			int last = end;
			while (prev[last] != -1)
			{
				path.Add(prev[last]);
				last = prev[last];
			}
			path.Reverse();

			return path;
		}


		public List<int> FindRoute()
		{
			List<int> ends = new List<int>();

			var s = enemyShips[0];
			//foreach (var s in enemyShips)
			//{
			int j = s % 50;
			int i = s / 50;
			for (int x = j - 1; x >= 0; x--)
			{
				ends.Add(i * 50 + x);
			}
			for (int x = i - 1; x >= 0; x--)
			{
				ends.Add(x * 50 + j);
			}
			for (int x = j + 1; x < 50; x++)
			{
				ends.Add(i * 50 + x);
			}
			for (int x = i + 1; x < 40; x++)
			{
				ends.Add(x * 50 + j);
			}
			//}

			return Dijkstra(shipPositionRow * 50 + shipPositionCol, ends);
		}

		public List<int> RouteToGlory()
		{
			List<int> ends = new List<int>();

			int j = state.enemy.Item2;
			int i = state.enemy.Item1;
			for (int x = j - 1; x >= 0; x--)
			{
				ends.Add(i * 50 + x);
			}
			for (int x = i - 1; x >= 0; x--)
			{
				ends.Add(x * 50 + j);
			}
			for (int x = j + 1; x < 50; x++)
			{
				ends.Add(i * 50 + x);
			}
			for (int x = i + 1; x < 40; x++)
			{
				ends.Add(x * 50 + j);
			}
			//}

			return Dijkstra(shipPositionRow * 50 + shipPositionCol, ends);
		}

		public void DestroyShips(List<int> endpoint)
		{
			int enemy;
			if (enemyShips.Count > 0)
				enemy = enemyShips[0];
			else
				enemy = state.enemy.Item1 * 50 + state.enemy.Item2;
			if (endpoint.Count == 1)
			{
				Direction opposite = Direction.Left;
				if (direction == Direction.Up)
					opposite = Direction.Down;
				if (direction == Direction.Down)
					opposite = Direction.Up;
				if (direction == Direction.Left)
					opposite = Direction.Right;
				if (IsMoving(lastState.ship.Item1, lastState.ship.Item2, shipPositionRow, shipPositionCol))
				{
					Direction d = GetNewDirection(enemy / 50, enemy % 50);
					if (IsEvilBehindTheCorner() || d == direction)
					{
						IsEngineStart = true;
						/*using (var writer2 = new StreamWriter(new FileStream("a" + move + ".txt", FileMode.Create)))
						{
							writer2.WriteLine("entered");
							writer2.WriteLine(shipPositionRow + " " + shipPositionCol);
							writer2.WriteLine(IsEvilBehindTheCorner());
						}*/
					}
					else
					{
						if (IsEvilBehindTheCorner())
							IsEngineStart = true;
						else
							IsShoot = true;
					}

					if (IsEvilInFrontTheCorner())
					{
						direction = lastDirection;
						IsEngineStart = false;
						IsShoot = true;
					}
				}
				else
				{
					direction = GetNewDirection(enemy / 50, enemy % 50);

					if (lastDirection == direction)
					{
						if (IsEvilBehindTheCorner())
							IsEngineStart = true;
						else
							IsShoot = true;
					}

					if (IsEvilInFrontTheCorner())
					{
						direction = lastDirection;
						IsEngineStart = false;
						IsShoot = true;
					}
				}
				
				return;
			}

			int toi = endpoint[0] / 50;
			int toj = endpoint[0] % 50;
			Direction dir = GetNewDirection(toi, toj);

			if (lastDirection == dir)
			{
				IsEngineStart = true;
			}
			else
			{
				// Razli4ni posoki

				if (IsMoving(lastState.ship.Item1, lastState.ship.Item2, shipPositionRow, shipPositionCol))
				{
					if (IsMovingDirection(lastState.ship.Item1, lastState.ship.Item2, shipPositionRow, shipPositionCol, direction))
						IsShoot = true;
					else
						IsEngineStart = true;
				}
				else
				{
					direction = dir;
				}
			}
		}

		public bool IsEvilBehindTheCorner()
		{
			if (state.ship.Item3 == Direction.Up)
			{
				int a = state.ship.Item1 + 1;
				if ((a < 0 || a >= 40) || matrix[a, state.ship.Item2] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Left)
			{
				int a = state.ship.Item2 + 1;
				if ((a < 0 || a >= 50) || matrix[state.ship.Item1, a] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Down)
			{
				int a = state.ship.Item1 - 1;
				if ((a < 0 || a >= 40) || matrix[a, state.ship.Item2] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Right)
			{
				int a = state.ship.Item2 - 1;
				if ((a < 0 || a >= 50) || matrix[state.ship.Item1, a] != ' ')
					return true;
			}
			return false;
		}
		public bool IsEvilInFrontTheCorner()
		{
			if (state.ship.Item3 == Direction.Up)
			{
				int a = state.ship.Item1 - 1;
				if ((a < 0 || a >= 40) || matrix[a, state.ship.Item2] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Left)
			{
				int a = state.ship.Item2 - 1;
				if ((a < 0 || a >= 50) || matrix[state.ship.Item1, a] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Down)
			{
				int a = state.ship.Item1 + 1;
				if ((a < 0 || a >= 40) || matrix[a, state.ship.Item2] != ' ')
					return true;
			}
			else if (state.ship.Item3 == Direction.Right)
			{
				int a = state.ship.Item2 + 1;
				if ((a < 0 || a >= 50) || matrix[state.ship.Item1, a] != ' ')
					return true;
			}
			return false;
		}

		public bool IsMoving(int i1, int j1, int i2, int j2)
		{
			return !(i1 == i2 && j1 == j2);
		}

		public bool IsMovingDirection(int i1, int j1, int i2, int j2, Direction direction)
		{
			if (direction == Direction.Down)
			{
				return i1 < i2;
			}
			else if (direction == Direction.Up)
			{
				return i1 > i2;
			}
			else if (direction == Direction.Left)
			{
				return j1 > j2;
			}
			else if (direction == Direction.Right)
			{
				return j1 < j2;
			}
			else
				return false;
		}

		public void Output()
		{
			using (StreamWriter writer = new StreamWriter(new FileStream("output.txt", FileMode.Create)))
			{
				if (lastDirection != direction)
				{
					char dir = 'L';
					if (lastDirection == Direction.Down)
					{
						if (direction == Direction.Left)
							dir = 'R';
						else if (direction == Direction.Right)
							dir = 'L';
					}
					else if (lastDirection == Direction.Left)
					{
						if (direction == Direction.Up)
							dir = 'R';
						else if (direction == Direction.Down)
							dir = 'L';
					}
					else if (lastDirection == Direction.Up)
					{
						if (direction == Direction.Left)
							dir = 'L';
						else if (direction == Direction.Right)
							dir = 'R';
					}
					else if (lastDirection == Direction.Right)
					{
						if (direction == Direction.Up)
							dir = 'L';
						else if (direction == Direction.Down)
							dir = 'R';
					}

					writer.WriteLine(dir);
				}
				else if (IsEngineStart)
				{
					writer.WriteLine('E');
				}
				else if (IsShoot)
				{
					writer.WriteLine('S');
				}
				else
				{
					writer.WriteLine('N');
				}

			}
		}

		public Direction GetNewDirection(int toi, int toj)
		{
			Direction d;
			if (toi < shipPositionRow)
			{
				if (direction == Direction.Down)
					d = Direction.Right;
				else
					d = Direction.Up;
			}
			else if (toi > shipPositionRow)
			{
				if (direction == Direction.Up)
					d = Direction.Right;
				else
					d = Direction.Down;
			}
			else if (toj > shipPositionCol)
			{
				if (direction == Direction.Left)
					d = Direction.Up;
				else
					d = Direction.Right;
			}
			else if (toj < shipPositionCol)
			{
				if (direction == Direction.Right)
					d = Direction.Up;
				else
					d = Direction.Left;
			}
			else
				d = direction;

			return d;
		}

		public void GetRockets()
		{
			state.rockets = new List<Tuple<int, int, Direction>>();

			foreach (var rocket in lastState.rockets)
			{
				int i = rocket.Item1, j = rocket.Item2;

				if (rocket.Item3 == Direction.Up)
					i -= 2;
				else if (rocket.Item3 == Direction.Down)
					i += 2;
				else if (rocket.Item3 == Direction.Left)
					j -= 2;
				else if (rocket.Item3 == Direction.Right)
					j += 2;

				if (i >= 0 && i < 40 && j >= 0 && j < 50 && matrix[i, j] == 'o')
					state.rockets.Add(new Tuple<int, int, Direction>(i, j, rocket.Item3));
			}

			if (state.enemy != null)
			{
				var enemyDirection = state.enemy.Item3;

				if (enemyDirection == Direction.Up)
				{
					for (int i = state.enemy.Item1 - 1; i > state.enemy.Item1 - 3; i--)
					{
						if (i >=0 && i < 40 && matrix[i, state.enemy.Item2] == 'o')
							state.rockets.Add(new Tuple<int, int, Direction>(i, state.enemy.Item2, enemyDirection));
					}
				}
				else if (enemyDirection == Direction.Left)
				{
					for (int j = state.enemy.Item2 - 1; j > state.enemy.Item2 - 3; j--)
					{
						if (j >=0 && j < 50 && matrix[state.enemy.Item1, j] == 'o')
							state.rockets.Add(new Tuple<int, int, Direction>(state.enemy.Item1, j, enemyDirection));
					}
				}
				else if (enemyDirection == Direction.Down)
				{
					for (int i = state.enemy.Item1 + 1; i < state.enemy.Item1 + 3; i++)
					{
						if (i >= 0 && i < 40 && matrix[i, state.enemy.Item2] == 'o')
							state.rockets.Add(new Tuple<int, int, Direction>(i, state.enemy.Item2, enemyDirection));
					}
				}
				else if (enemyDirection == Direction.Right)
				{
					for (int j = state.enemy.Item2 + 1; j < state.enemy.Item2 + 3; j++)
					{
						if (j >= 0 && j < 50 && matrix[state.enemy.Item1, j] == 'o')
							state.rockets.Add(new Tuple<int, int, Direction>(state.enemy.Item1, j, enemyDirection));
					}
				}
			}
		}

		public bool Defences(List<int> route)
		{
			int maxP = route.Count;
			if (maxP > 6)
				maxP = 6;
			for (int i = 0; i < maxP; i++)
			{
				foreach (var rocket in state.rockets)
				{
					int newPosRow = rocket.Item1;
					int newPosCol = rocket.Item2;
					int newPosRowLast = rocket.Item1;
					int newPosColLast = rocket.Item2;
					if (rocket.Item3 == Direction.Up)
					{
						newPosRow -= 2 * (i + 1);
						newPosRowLast = newPosRow + 2;
					}
					else if (rocket.Item3 == Direction.Down)
					{
						newPosRow += 2 * (i + 1);
						newPosRowLast = newPosRow - 2;
					}
					else if (rocket.Item3 == Direction.Left)
					{
						newPosCol -= 2 * (i + 1);
						newPosColLast = newPosCol + 2;
					}
					else if (rocket.Item3 == Direction.Right)
					{
						newPosCol += 2 * (i + 1);
						newPosColLast = newPosCol - 2;
					}

					int shipRow = route[i] / 50;
					int shipCol = route[i] % 50;
					if (
						newPosRow * 50 + newPosCol == route[i]
						||
						(newPosRow <= shipRow && shipRow < newPosRowLast && newPosCol == shipCol)
						||
						(newPosRow >= shipRow && shipRow > newPosRowLast && newPosCol == shipCol)
						||
						(newPosCol <= shipCol && shipCol < newPosColLast && newPosRow == shipRow)
						||
						(newPosCol >= shipCol && shipCol > newPosColLast && newPosRow == shipRow)
						)
					{
						IsShoot = true;
						return true;
					}
				}
			}

			return false;
		}
	}
}
