﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Metro.Navigation;
using System.Media;
using UIApplication.Properties;

namespace UIApplication
{
    public partial class MainForm : DevExpress.XtraEditors.XtraForm
    {
        private readonly int numberOfCPUCores;
        private int usingCpuCores = 1;

        private static bool isDark = true;

        private SoundPlayer my_JukeBox;
        private static bool isSoundOn = true;

        public MainForm()
        {
            InitializeComponent();
            numberOfCPUCores = Environment.ProcessorCount;
        }



        private void tileItemMainLarge_ItemClick(object sender, TileItemEventArgs e)
        {
            if (isSoundOn)
            {
                my_JukeBox = new SoundPlayer(UIApplication.Properties.Resources.CLICK9B);
                my_JukeBox.Play();

            }
            Settings.Default.CPUCores = usingCpuCores;
            Settings.Default.Save();
            this.GoTo<PCvsPCForm>(this.usingCpuCores);
        }

        private void tileItemThemeChanger_ItemClick(object sender, TileItemEventArgs e)
        {
            if (isSoundOn)
            {
                my_JukeBox = new SoundPlayer(UIApplication.Properties.Resources.CLICK9B);
                my_JukeBox.Play();

            }

            if (isDark)
            {
                DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Metropolis");
                DevExpress.Skins.SkinManager.EnableFormSkins();
                isDark = false;
                this.tileItemThemeChanger.Text = "Dark";
                tileItemThemeChanger.Image = global::UIApplication.Properties.Resources.power___hibernate_3Grey245;
            }
            else
            {
                DevExpress.LookAndFeel.UserLookAndFeel.Default.SetSkinStyle("Metropolis Dark 4 Touch");
                DevExpress.Skins.SkinManager.EnableFormSkins();
                isDark = true;
                this.tileItemThemeChanger.Text = "Light";
                tileItemThemeChanger.Image = global::UIApplication.Properties.Resources.brightness_3Grey245;
            }
        }


        private void tileItemSoundChanger_ItemClick(object sender, TileItemEventArgs e)
        {
            if (isSoundOn)
            {
                my_JukeBox = new SoundPlayer(UIApplication.Properties.Resources.CLICK9B);
                my_JukeBox.Play();

            }

            if (isSoundOn)
            {
                tileItemSoundChanger.Image = global::UIApplication.Properties.Resources.volume_not_running_3Grey245;
                tileItemSoundChanger.Text = "Off";
                isSoundOn = false;
            }
            else 
            {
                tileItemSoundChanger.Image = global::UIApplication.Properties.Resources.volume_1_3Grey245;
                tileItemSoundChanger.Text = "On";
                isSoundOn = true;
            }
        }

        private void tileItemCPUCoreChanger_ItemClick(object sender, TileItemEventArgs e)
        {
            if (isSoundOn)
            {
                my_JukeBox = new SoundPlayer(UIApplication.Properties.Resources.CLICK9B);
                my_JukeBox.Play();

            }

            if ((usingCpuCores + 1 > numberOfCPUCores))
            {
                usingCpuCores = 1;
                tileItemCPUCoreChanger.Text = string.Format(" Cores : {0}x", usingCpuCores);
            }
            else
            {
                usingCpuCores++;
                tileItemCPUCoreChanger.Text = string.Format(" Cores : {0}x",usingCpuCores);
            }
        }

        private void tileItemShutDown_ItemClick(object sender, TileItemEventArgs e)
        {
            if (isSoundOn)
            {
                my_JukeBox = new SoundPlayer(UIApplication.Properties.Resources.CLICK9B);
                my_JukeBox.Play();

            }
            Application.Exit();
        }

        private void tileItemMainSmall_ItemClick(object sender, TileItemEventArgs e)
        {

        }

        private void tileItemMainSmall2_ItemClick(object sender, TileItemEventArgs e)
        {

        }
    }
}