﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using UIApplication.Properties;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Security.Permissions;

namespace UIApplication
{
    public partial class PCvsPCForm : DevExpress.XtraEditors.XtraForm
    {
        private static bool isRunning = false;
        private static bool isFirstStart = true;
        public PCvsPCForm()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            isRunning = true;
            //if (isFirstStart) 
            //{
                isFirstStart = false;
                Start();
            //}
        }

        private void Start()
        {
            ProcessStartInfo processInfo = new ProcessStartInfo();
            processInfo.CreateNoWindow = true;
            processInfo.UseShellExecute = false;
            processInfo.RedirectStandardInput = true;
            processInfo.RedirectStandardOutput = true;
            processInfo.RedirectStandardError = true;
            processInfo.FileName = @"..\..\SpaceWarsEngineVS2010.exe";

            Process computerLogic = new Process();
            computerLogic.StartInfo = processInfo;
            computerLogic.Start();

            //while (isRunning) 
            //{
            //    //Thread.Sleep(500);
            //    string text = string.Empty;
            //    while (true)
            //    {
            //        try
            //        {
            //            using (StreamReader stream = new StreamReader(@"..\..\SpaceMap.txt"))
            //            {
            //                if (stream != null)
            //                {
            //                    //System.Diagnostics.Trace.WriteLine(string.Format("Output file {0} ready.", e.Name));
            //                    this.memoEdit.Text  = stream.ReadToEnd();
            //                    break;
            //                }
            //            }
            //        }
            //        catch (FileNotFoundException ex)
            //        {
            //        }
            //        catch (IOException ex)
            //        {
            //        }
            //        catch (UnauthorizedAccessException ex)
            //        {
            //        }
            //        catch (Exception) { }
            //        Thread.Sleep(20);
            //    }
            //    //break;
                
            //}
            Run();
            
        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public  void Run()
        {

            FileSystemWatcher watcher = new FileSystemWatcher(@"..\..\","SpaceMap.txt");

            watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
               | NotifyFilters.FileName | NotifyFilters.DirectoryName;

            watcher.Changed += new FileSystemEventHandler(OnChanged);

            watcher.EnableRaisingEvents = true;

            
            while (isRunning) ;
        }
        private  void OnChanged(object source, FileSystemEventArgs e)
        {

            while (true)
            {
                try
                {
                    using (StreamReader stream = new StreamReader(@"..\..\SpaceMap.txt"))
                    {
                        if (stream != null)
                        {
                            //System.Diagnostics.Trace.WriteLine(string.Format("Output file {0} ready.", e.Name));
                            this.memoEdit.Text = stream.ReadToEnd();
                            break;
                        }
                    }
                }
                catch (FileNotFoundException ex)
                {
                    System.Diagnostics.Trace.WriteLine(string.Format("Output file {0} not yet ready ({1})", e.Name, ex.Message));
                }
                catch (IOException ex)
                {
                    System.Diagnostics.Trace.WriteLine(string.Format("Output file {0} not yet ready ({1})", e.Name, ex.Message));
                }
                catch (UnauthorizedAccessException ex)
                {
                    System.Diagnostics.Trace.WriteLine(string.Format("Output file {0} not yet ready ({1})", e.Name, ex.Message));
                }
                Thread.Sleep(500);
            }


        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
           // isRunning = false;
        }


    }
}