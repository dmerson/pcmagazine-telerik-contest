﻿namespace UIApplication
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraEditors.TileItemElement tileItemElement3 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement1 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement2 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement4 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement5 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement6 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement7 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement8 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement9 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement10 = new DevExpress.XtraEditors.TileItemElement();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tileControl = new DevExpress.XtraEditors.TileControl();
            this.tileGroupMain = new DevExpress.XtraEditors.TileGroup();
            this.tileItemMainSmall2 = new DevExpress.XtraEditors.TileItem();
            this.tileGroupSettings = new DevExpress.XtraEditors.TileGroup();
            this.tileItemMainLarge = new DevExpress.XtraEditors.TileItem();
            this.tileItemMainSmall = new DevExpress.XtraEditors.TileItem();
            this.tileItemThemeChanger = new DevExpress.XtraEditors.TileItem();
            this.tileItemSoundChanger = new DevExpress.XtraEditors.TileItem();
            this.tileItemCPUCoreChanger = new DevExpress.XtraEditors.TileItem();
            this.tileItemShutDown = new DevExpress.XtraEditors.TileItem();
            this.SuspendLayout();
            // 
            // tileControl
            // 
            this.tileControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tileControl.Groups.Add(this.tileGroupMain);
            this.tileControl.Groups.Add(this.tileGroupSettings);
            this.tileControl.Location = new System.Drawing.Point(0, 0);
            this.tileControl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tileControl.MaxId = 7;
            this.tileControl.Name = "tileControl";
            this.tileControl.Padding = new System.Windows.Forms.Padding(15, 15, 15, 15);
            this.tileControl.Size = new System.Drawing.Size(629, 348);
            this.tileControl.TabIndex = 0;
            this.tileControl.Text = "Main";
            // 
            // tileGroupMain
            // 
            this.tileGroupMain.Items.Add(this.tileItemMainLarge);
            this.tileGroupMain.Items.Add(this.tileItemMainSmall);
            this.tileGroupMain.Items.Add(this.tileItemMainSmall2);
            this.tileGroupMain.Name = "tileGroupMain";
            this.tileGroupMain.Text = null;
            // 
            // tileItemMainSmall2
            // 
            tileItemElement3.Image = global::UIApplication.Properties.Resources.user_accounts_3;
            tileItemElement3.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement3.Text = "Player vs Player";
            this.tileItemMainSmall2.Elements.Add(tileItemElement3);
            this.tileItemMainSmall2.Id = 2;
            this.tileItemMainSmall2.Name = "tileItemMainSmall2";
            this.tileItemMainSmall2.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemMainSmall2_ItemClick);
            // 
            // tileGroupSettings
            // 
            this.tileGroupSettings.Items.Add(this.tileItemThemeChanger);
            this.tileGroupSettings.Items.Add(this.tileItemSoundChanger);
            this.tileGroupSettings.Items.Add(this.tileItemCPUCoreChanger);
            this.tileGroupSettings.Items.Add(this.tileItemShutDown);
            this.tileGroupSettings.Name = "tileGroupSettings";
            this.tileGroupSettings.Text = null;
            // 
            // tileItemMainLarge
            // 
            this.tileItemMainLarge.BackgroundImage = global::UIApplication.Properties.Resources.Tile_headline_only;
            this.tileItemMainLarge.BackgroundImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement1.Image = global::UIApplication.Properties.Resources.windows_easy_transfer_4;
            tileItemElement1.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleRight;
            tileItemElement1.Text = "Pc vs Pc";
            this.tileItemMainLarge.Elements.Add(tileItemElement1);
            this.tileItemMainLarge.Id = 0;
            this.tileItemMainLarge.IsLarge = true;
            this.tileItemMainLarge.Name = "tileItemMainLarge";
            this.tileItemMainLarge.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemMainLarge_ItemClick);
            // 
            // tileItemMainSmall
            // 
            this.tileItemMainSmall.BackgroundImage = global::UIApplication.Properties.Resources.Tile_Legacy4;
            this.tileItemMainSmall.BackgroundImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement2.Image = global::UIApplication.Properties.Resources.user_accounts_alt_3;
            tileItemElement2.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement2.Text = "Player vs PC";
            this.tileItemMainSmall.Elements.Add(tileItemElement2);
            this.tileItemMainSmall.Id = 1;
            this.tileItemMainSmall.Name = "tileItemMainSmall";
            this.tileItemMainSmall.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemMainSmall_ItemClick);
            // 
            // tileItemThemeChanger
            // 
            tileItemElement4.Image = global::UIApplication.Properties.Resources.brightness_3Grey245;
            tileItemElement4.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement4.Text = "Light";
            tileItemElement4.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomCenter;
            tileItemElement5.Text = "Theme";
            tileItemElement5.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            this.tileItemThemeChanger.Elements.Add(tileItemElement4);
            this.tileItemThemeChanger.Elements.Add(tileItemElement5);
            this.tileItemThemeChanger.Id = 3;
            this.tileItemThemeChanger.Name = "tileItemThemeChanger";
            this.tileItemThemeChanger.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemThemeChanger_ItemClick);
            // 
            // tileItemSoundChanger
            // 
            this.tileItemSoundChanger.BackgroundImage = global::UIApplication.Properties.Resources.Tile_Legacy5;
            this.tileItemSoundChanger.BackgroundImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement6.Image = global::UIApplication.Properties.Resources.volume_1_3Grey245;
            tileItemElement6.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement6.Text = "On";
            tileItemElement6.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement7.Text = "Sound";
            tileItemElement7.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            this.tileItemSoundChanger.Elements.Add(tileItemElement6);
            this.tileItemSoundChanger.Elements.Add(tileItemElement7);
            this.tileItemSoundChanger.Id = 4;
            this.tileItemSoundChanger.Name = "tileItemSoundChanger";
            this.tileItemSoundChanger.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemSoundChanger_ItemClick);
            // 
            // tileItemCPUCoreChanger
            // 
            this.tileItemCPUCoreChanger.BackgroundImage = global::UIApplication.Properties.Resources.Tile_Legacy;
            this.tileItemCPUCoreChanger.BackgroundImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement8.Image = global::UIApplication.Properties.Resources.chipGrey245;
            tileItemElement8.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement8.Text = " Cores : 1x";
            tileItemElement8.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomCenter;
            tileItemElement9.Text = "CPU";
            tileItemElement9.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            this.tileItemCPUCoreChanger.Elements.Add(tileItemElement8);
            this.tileItemCPUCoreChanger.Elements.Add(tileItemElement9);
            this.tileItemCPUCoreChanger.Id = 5;
            this.tileItemCPUCoreChanger.Name = "tileItemCPUCoreChanger";
            this.tileItemCPUCoreChanger.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemCPUCoreChanger_ItemClick);
            // 
            // tileItemShutDown
            // 
            this.tileItemShutDown.BackgroundImage = global::UIApplication.Properties.Resources.Tile_Legacy10;
            this.tileItemShutDown.BackgroundImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement10.Image = global::UIApplication.Properties.Resources.power___standby_3Grey245;
            tileItemElement10.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileItemElement10.Text = "ShutDown";
            tileItemElement10.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomCenter;
            this.tileItemShutDown.Elements.Add(tileItemElement10);
            this.tileItemShutDown.Id = 6;
            this.tileItemShutDown.Name = "tileItemShutDown";
            this.tileItemShutDown.ItemClick += new DevExpress.XtraEditors.TileItemClickEventHandler(this.tileItemShutDown_ItemClick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 348);
            this.Controls.Add(this.tileControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.Text = "StarWars";
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.TileControl tileControl;
        private DevExpress.XtraEditors.TileGroup tileGroupMain;
        private DevExpress.XtraEditors.TileItem tileItemMainLarge;
        private DevExpress.XtraEditors.TileItem tileItemMainSmall;
        private DevExpress.XtraEditors.TileItem tileItemMainSmall2;
        private DevExpress.XtraEditors.TileGroup tileGroupSettings;
        private DevExpress.XtraEditors.TileItem tileItemThemeChanger;
        private DevExpress.XtraEditors.TileItem tileItemSoundChanger;
        private DevExpress.XtraEditors.TileItem tileItemCPUCoreChanger;
        private DevExpress.XtraEditors.TileItem tileItemShutDown;
    }
}