﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Algorithm
{
    class Program
    {
        private static int turnNumber;
        private static Coordinates myShipCoordNow;
        private static Coordinates myShipCoordLast;
        private static Coordinates enemyShipNow;
        private static int myShips;
        private static char[,] spaceMap = new char[40, 50];
        private static char myTurn;

        static void Main(string[] args)
        {
            enemyShipNow = null;
            ReadInput();
            PlayTurn();
            PrintTurn();
        }

        private static void PrintTurn()
        {
            using (StreamWriter writer = new StreamWriter("output.txt", false))
            {
                writer.Write(myTurn);
            }
            using (StreamWriter writer = new StreamWriter("LastCoordinates.txt", false))
            {
                writer.WriteLine(string.Format("{0} {1}", myShipCoordNow.Row, myShipCoordNow.Col));
            }
        }

        private static void PlayTurn()
        {
            if (turnNumber < 0) //ambush mod
            {
                Ambush();
            }
            else //Atack Mod
            {
                Atack();
            }

        }

        private static void Ambush()
        {
            if (enemyShipNow == null && myShipCoordLast.Equals(myShipCoordNow))
            {
                if (turnNumber % 2 == 0)
                {
                    myTurn = 'E';
                }
                else
                {
                    myTurn = 'S';
                }
            }

            if (myShipCoordLast == null || myShipCoordLast.Equals(myShipCoordNow)) // not move
            {
                if (myShips == 1)
                {
                    if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Col + 2 < enemyShipNow.Col)
                    {
                        if ((int)spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 114)
                        {
                            DumpMove();
                        }
                        else
                        {
                            myTurn = 'R';
                        }
                    }
                    if (enemyShipNow.Col < enemyShipNow.Row && myShipCoordNow.Row + 2 < enemyShipNow.Row)
                    {
                        if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'd')
                        {
                            DumpMove();
                        }
                        else
                        {
                            myTurn = 'R';
                        }
                    }
                    if (enemyShipNow.Col == enemyShipNow.Row)
                    {
                        myTurn = 'N';
                    }
                }
                else // myships == 2
                {
                    if (enemyShipNow.Row > enemyShipNow.Col && myShipCoordNow.Col - 2 > enemyShipNow.Col)
                    {
                        if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'l')
                        {
                            DumpMove();
                        }
                        else
                        {
                            myTurn = 'L';
                        }
                    }
                    if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Row - 2 > enemyShipNow.Row)
                    {
                        if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'u')
                        {
                            DumpMove();
                        }
                        else
                        {
                            myTurn = 'R';
                        }
                    }
                    if (enemyShipNow.Col == enemyShipNow.Row)
                    {
                        myTurn = 'N';
                    }
                }

            }
            else //moving
            {
                if (myShips == 1)
                {
                    if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Col + 2 < enemyShipNow.Col)
                    {
                        DumpMove();
                    }
                    else if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Col + 2 >= enemyShipNow.Col)
                    {
                        if (myShipCoordNow.Col > 7)
                        {
                            myTurn = 'S';
                        }
                        else
                        {
                            DumpMove();
                        }
                    }
                    if (enemyShipNow.Col < enemyShipNow.Row && myShipCoordNow.Row + 2 < enemyShipNow.Row)
                    {
                        DumpMove();
                    }
                    else if (enemyShipNow.Col < enemyShipNow.Row && myShipCoordNow.Row + 2 >= enemyShipNow.Row)
                    {
                        if (myShipCoordNow.Row > 7)
                        {
                            myTurn = 'S';
                        }
                        else
                        {
                            DumpMove();
                        }
                    }
                }
                else //myship == 2
                {
                    if (enemyShipNow.Row > enemyShipNow.Col && myShipCoordNow.Col - 2 > enemyShipNow.Col)
                    {
                        DumpMove();
                    }
                    else if (enemyShipNow.Row > enemyShipNow.Col && myShipCoordNow.Col - 2 <= enemyShipNow.Col)
                    {
                        if (myShipCoordNow.Col < 42)
                        {
                            myTurn = 'S';
                        }
                        else
                        {
                            DumpMove();
                        }
                    }
                    if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Row - 2 > enemyShipNow.Row)
                    {
                        DumpMove();
                    }
                    else if (enemyShipNow.Col > enemyShipNow.Row && myShipCoordNow.Row - 2 <= enemyShipNow.Row)
                    {
                        if (myShipCoordNow.Row < 32)
                        {
                            myTurn = 'S';
                        }
                        else
                        {
                            DumpMove();
                        }
                    }
                    if (enemyShipNow.Col == enemyShipNow.Row)
                    {
                        myTurn = 'S';
                    }
                }
            }
        }

        private static void Atack()
        {
            if (myShips == 1)
            {
                if (myShipCoordNow.Row < 34 && myShipCoordNow.Col < 44)
                {
                    DumpMove();
                }
                else if (myShipCoordNow.Row == 34 && (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'r' || spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'd'))
                {
                    if (myShipCoordNow.Row > myShipCoordLast.Row && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'd')
                    {
                        myTurn = 'S';
                    }

                    if (myShipCoordNow.Equals(myShipCoordLast) && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] != 'r')
                    {
                        myTurn = 'L';
                        return;
                    }
                    if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'r')
                    {
                        if (spaceMap[34, 44] == '2' || spaceMap[34, 46] == '2' || spaceMap[34, 48] == '2')
                        {
                            DumpMove();
                        }
                        //else 
                        //{
                        //    myTurn = 'S';
                        //}
                    }

                }
                else if (myShipCoordNow.Col == 44 && (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'r' || spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'd'))
                {
                    if (myShipCoordNow.Col > myShipCoordLast.Col && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'r')
                    {
                        myTurn = 'S';
                    }

                    if (myShipCoordNow.Equals(myShipCoordLast) && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] != 'd')
                    {
                        myTurn = 'R';
                        return;
                    }
                    if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'd')
                    {
                        if (spaceMap[34, 44] == '2' || spaceMap[36, 44] == '2' || spaceMap[38, 44] == '2')
                        {
                            //DumpMove();
                            if (turnNumber % 2 == 0)
                            {
                                myTurn = 'S';
                            }
                            else
                            {
                                myTurn = 'E';
                            }
                        }
                        //else 
                        //{
                        //    myTurn = 'S';
                        //}
                    }

                }

            }
            else //myship == 2
            {
                if (myShipCoordNow.Row > 6 && myShipCoordNow.Col > 6)
                {
                    DumpMove();
                }
                else if (myShipCoordNow.Row == 5 && (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'u' || spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'l'))
                {
                    if (myShipCoordNow.Row < myShipCoordLast.Row && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'u')
                    {
                        myTurn = 'S';
                    }

                    if (myShipCoordNow.Equals(myShipCoordLast) && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] != 'l')
                    {
                        myTurn = 'R';
                        return;
                    }
                    if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'l')
                    {
                        if (spaceMap[5, 1] == '1' || spaceMap[5, 3] == '1' || spaceMap[5, 5] == '1')
                        {
                            DumpMove();
                        }
                        //else 
                        //{
                        //    myTurn = 'S';
                        //}
                    }

                }
                else if (myShipCoordNow.Col == 5 && (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'u' || spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'l'))
                {
                    if (myShipCoordNow.Col < myShipCoordLast.Col && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'l')
                    {
                        myTurn = 'S';
                    }

                    if (myShipCoordNow.Equals(myShipCoordLast) && spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] != 'u')
                    {
                        myTurn = 'R';
                        return;
                    }
                    if (spaceMap[myShipCoordNow.Row, myShipCoordNow.Col] == 'u')
                    {
                        if (spaceMap[5, 5] == '1' || spaceMap[3, 5] == '1' || spaceMap[1, 5] == '1')
                        {
                            //DumpMove();
                            if (turnNumber % 2 == 0)
                            {
                                myTurn = 'S';
                            }
                            else
                            {
                                myTurn = 'E';
                            }
                        }
                        //else 
                        //{
                        //    myTurn = 'S';
                        //}
                    }

                }
            }
        }
        
        private static void DumpMove()
        {
            
            if (turnNumber % 2 == 0)
            {
                myTurn = 'E';
            }
            else
            {
                myTurn = 'S';
            }
        }

        private static void ReadInput()
        {
            using (StreamReader reader = new StreamReader("input.txt", Encoding.ASCII))
            {
                turnNumber = int.Parse(reader.ReadLine());
                string[] coor = reader.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                myShipCoordNow = new Coordinates(int.Parse(coor[0]), int.Parse(coor[1]));
                myShips = int.Parse(reader.ReadLine());
                for (int row = 0; row < 40; row++)
                {
                    string line = reader.ReadLine();

                    for (int col = 0; col < 50; col++)
                    {
                        spaceMap[row, col] = line[col];
                        if (line[col] == 'u' || line[col] == 'd' || line[col] == 'r' || line[col] == 'l')
                        {
                            if (col != myShipCoordNow.Col || row != myShipCoordNow.Row)
                            {
                                enemyShipNow = new Coordinates(row, col);
                            }
                        }
                    }
                }
            }

            using (StreamReader reader = new StreamReader("LastCoordinates.txt"))
            {
                string str = reader.ReadLine();
                if (!string.IsNullOrEmpty(str))
                {
                    string[] coor = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    myShipCoordLast = new Coordinates(int.Parse(coor[0]), int.Parse(coor[1]));
                }
                else
                {
                    myShipCoordLast = null;
                }
            }
        }

        class Coordinates
        {
            int row;

            public int Row
            {
                get { return row; }
                set { row = value; }
            }
            int col;

            public int Col
            {
                get { return col; }
                set { col = value; }
            }
            public Coordinates(int row, int col)
            {
                this.row = row;
                this.col = col;
            }

            public override bool Equals(object obj)
            {
                Coordinates c = obj as Coordinates;
                if (c == null) return false;

                if (this.col == c.col && this.row == c.row)
                {
                    return true;
                }
                return false;

            }
        }
    }
}
