﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceWarsDumbAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] worldDataLines = System.IO.File.ReadAllLines("input.txt");
            int turnNumber = int.Parse(worldDataLines[0]);
            if (turnNumber % 2 == 0)
            {
                System.IO.File.WriteAllText("output.txt", "E");
            }
            else
            {
                System.IO.File.WriteAllText("output.txt", "S");
            }
        }
    }
}
