﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    /// <summary>
    /// Perfect example of bad cohesion. Contains several useful methods, mainly working with numbers
    /// </summary>
    public static class Utils
    {
        public static void Swap(ref int x, ref int y)
        {
            x ^= y;
            y ^= x;
            x ^= y;
        }

        public static bool IsEven(long number)
        {
            return (number & 1) == 0;
        }

        public static bool IsOdd(long number)
        {
            return !Utils.IsEven(number);
        }

        public static MatrixCoordinates GetSymetricMatrixCoords(MatrixCoordinates coords, int matrixRows, int matrixCols)
        {
            return new MatrixCoordinates(matrixRows - coords.Row - 1, matrixCols - coords.Col - 1);
        }
    }
}
