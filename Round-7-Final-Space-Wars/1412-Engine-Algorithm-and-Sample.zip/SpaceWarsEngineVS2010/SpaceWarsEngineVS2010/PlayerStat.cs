﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    public class PlayerStat
    {
        public string PlayerName { get; private set; }
        public int Deaths { get; set; }
        public int Kills { get; set; }

        public PlayerStat(string name, int kills = 0, int deaths = 0)
        {
            this.PlayerName = name;
            this.Kills = kills;
            this.Deaths = deaths;
        }
    }
}
