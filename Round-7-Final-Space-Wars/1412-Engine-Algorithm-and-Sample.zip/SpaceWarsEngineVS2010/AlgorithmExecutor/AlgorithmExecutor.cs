﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

public class AlgorithmExecutor
{
    public string AlgorithmFilename { get; private set; }
    public string AlgorithmFullPath { get; private set; }
    public string AlgorithmPath { get; private set; }
    public string AlgorithmOwner { get; private set; }
    protected System.Diagnostics.Process algorithm;
    System.Diagnostics.ProcessStartInfo algorithmStartInfo;

    public AlgorithmExecutor(string algorithmFolder)
    {
        this.AlgorithmPath = algorithmFolder;

        string algorithmExe = System.IO.Directory.GetFiles(this.AlgorithmPath).First(name => name.Contains(".exe") || name.Contains(".bat") || name.Contains(".class"));
        this.AlgorithmOwner = this.AlgorithmPath.Substring(this.AlgorithmPath.LastIndexOf('\\') + 1);

        this.AlgorithmFullPath = algorithmExe;
        this.AlgorithmFilename = algorithmExe.Substring(algorithmExe.LastIndexOf('\\') + 1, algorithmExe.LastIndexOf('.') - algorithmExe.LastIndexOf('\\'));

        this.algorithmStartInfo = new System.Diagnostics.ProcessStartInfo(algorithmExe);
        algorithmStartInfo.ErrorDialog = false;
        algorithmStartInfo.WorkingDirectory = algorithmFolder;
        //algorithmStartInfo.RedirectStandardInput = true;
        //algorithmStartInfo.RedirectStandardOutput = true;
        //algorithmStartInfo.RedirectStandardError = true;
        //algorithmStartInfo.CreateNoWindow = true;
        algorithmStartInfo.UseShellExecute = false;

        //just to test if it runs at all
        //this.StartAlgorithm();
        //this.KillAlgorithm();
    }

    public void StartAlgorithm()
    {
        this.algorithm = System.Diagnostics.Process.Start(algorithmStartInfo);
    }

    public void KillAlgorithm()
    {
        try
        {
            this.algorithm.Kill();
        }
        catch
        {
        }
    }

    public void GetOutput(object outputLines)
    {
        List<string> output = (List<string>) outputLines;
        string[] allLines = this.algorithm.StandardOutput.ReadToEnd().Split(new string[] { "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
        foreach (var line in allLines)
        {
            output.Add(line);
        }
    }

    public void SendInput(string input)
    {
        Console.InputEncoding = Encoding.GetEncoding("Windows-1251");
        Console.OutputEncoding = Encoding.GetEncoding("Windows-1251");
        //StreamWriter writer = new StreamWriter(this.algorithm.StandardInput.BaseStream, Encoding.GetEncoding("Windows-1251"));
        //writer.Write(input);
        //writer.Close();
        this.algorithm.StandardInput.Write(input);
    }

    public void StartWaitAndKill(int waitMilliseconds)
    {
        this.StartAlgorithm();
        Thread.Sleep(waitMilliseconds);
        this.KillAlgorithm();
    }
}