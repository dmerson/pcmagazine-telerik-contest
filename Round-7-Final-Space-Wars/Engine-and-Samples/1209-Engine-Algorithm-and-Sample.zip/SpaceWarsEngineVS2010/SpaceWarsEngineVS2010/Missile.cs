﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    public class Missile : MatrixObject
    {
        const int MAX_SPEED = 1;

        new public const string TYPE_NAME = "missile";

        Direction direction;

        public Missile(WorldData world, MatrixObject owner, int row, int col, Direction direction)
            : base(world, row, col)
        {
            if (owner == null)
            {
                throw new ArgumentNullException("\"owner\" cannot be null");
            }
            this.Owner = owner;
            this.direction = direction;
            this.PrevRow = row;
            this.PrevCol = col;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode() * this.Owner.Name.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            MatrixObject other = obj as MatrixObject;
            if (other.Owner == null)
            {
                return false;
            }

            return base.Equals(obj) && this.Owner.Name.Equals(other.Owner.Name);
        }

        public override void UpdateLocation(long totalTurnsCount)
        {
            switch (direction)
            {
                case Direction.Left:
                    this.Col -= MAX_SPEED;
                    break;
                case Direction.Right:
                    this.Col += MAX_SPEED;
                    break;
                case Direction.Up:
                    this.Row -= MAX_SPEED;
                    break;
                case Direction.Down:
                    this.Row += MAX_SPEED;
                    break;
                default:
                    break;
            }
        }

        public override void Update(long totalTurnsCount)
        {
            this.UpdateLocation(totalTurnsCount);
            if (!this.IsInWorld())
            {
                this.isAlive = false;
            }
        }

        public override char GetVisual()
        {
            return 'o';
        }

        public override string GetObjectTypeName()
        {
            return Missile.TYPE_NAME;
        }

        public override bool CollidesWithSameType()
        {
            return false;
        }
    }
}
