﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    class Explosion : MatrixObject
    {
        public Explosion(WorldData world, int row, int col)
            : base(world, row, col)
        {
        }

        public override bool CanCollide()
        {
            return false;
        }

        public override char GetVisual()
        {
            return '*';
        }

        public override void Update(long totalTurnsCount)
        {
            this.Kill();
        }
    }
}
