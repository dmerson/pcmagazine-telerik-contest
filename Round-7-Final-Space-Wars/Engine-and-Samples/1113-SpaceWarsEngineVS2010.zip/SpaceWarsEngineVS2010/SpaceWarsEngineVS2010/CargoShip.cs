﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    class CargoShip : MatrixObject
    {
        new public const string TYPE_NAME = "cargoship";

        char visual;

        public CargoShip(WorldData world, MatrixObject owner, int row, int col, string name, char visual)
            : base(world, row, col, name)
        {
            this.visual = visual;
            this.Owner = owner;
        }

        public CargoShip(WorldData world, MatrixObject owner, MatrixCoordinates coords, string name, char visual)
            : base(world, coords.Row, coords.Col, name)
        {
            this.visual = visual;
            this.Owner = owner;
        }

        public override char GetVisual()
        {
            return this.visual;
        }

        public override string GetObjectTypeName()
        {
            return CargoShip.TYPE_NAME;
        }
    }
}
