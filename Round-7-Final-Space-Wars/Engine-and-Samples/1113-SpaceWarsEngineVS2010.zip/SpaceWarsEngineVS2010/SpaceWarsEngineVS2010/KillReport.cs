﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    public class KillReport
    {
        public string KillerName { get; private set; }
        public string VictimName { get; private set; }

        public KillReport(string killerName, string victimName)
        {
            this.KillerName = killerName;
            this.VictimName = victimName;
        }
    }
}
