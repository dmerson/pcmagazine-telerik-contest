﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SpaceWarsEngine
{
    public class CollisionPair<T>
    {
        public T ObjectA { get; private set; }
        public T ObjectB { get; private set; }

        public CollisionPair(T objectA, T objectB)
        {
            this.ObjectA = objectA;
            this.ObjectB = objectB;
        }

        public override int GetHashCode()
        {
            return this.ObjectA.GetHashCode() + this.ObjectB.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            CollisionPair<T> other = obj as CollisionPair<T>;
            return (this.ObjectA.Equals(other.ObjectA) && this.ObjectB.Equals(other.ObjectB)) ||
                this.ObjectA.Equals(other.ObjectB) && this.ObjectB.Equals(other.ObjectA);
        }
    }

    public class CollisionMatrix
    {
        public int Rows { get; private set; }
        public int Cols { get; private set; }

        List<MatrixObject>[,] collisionMatrix;

        public CollisionMatrix(ICollection<MatrixObject> objects)
        {
            int maxRow = 0, maxCol = 0;
            foreach (var obj in objects)
            {
                if (obj.Row > maxRow)
                {
                    maxRow = obj.Row;
                }
                if (obj.Col > maxCol)
                {
                    maxCol = obj.Col;
                }
            }

            this.collisionMatrix = new List<MatrixObject>[maxRow + 3, maxCol + 3];

            foreach (var obj in objects)
            {
                if (obj.IsInWorld() && obj.IsAlive() && obj.CanCollide() && (!obj.HasCollided))
                {
                    if (collisionMatrix[obj.Row, obj.Col] == null)
                    {
                        this.collisionMatrix[obj.Row, obj.Col] = new List<MatrixObject>();
                    }
                    this.collisionMatrix[obj.Row, obj.Col].Add(obj);
                }
            }

            this.Rows = this.collisionMatrix.GetLength(0);
            this.Cols = this.collisionMatrix.GetLength(1);
        }

        private bool ContainsObjectsWith(string typeName, int matrixRow, int matrixCol)
        {
            var objects = collisionMatrix[matrixRow, matrixCol];
            if(objects == null)
            {
                return false;
            }
            foreach (var obj in objects)
            {
                if (obj.GetObjectTypeName() == typeName)
                {
                    return true;
                }
            }
            return false;
        }

        public List<CollisionPair<MatrixObject>> GetCollisionPairsAt(int row, int col)
        {
            var collisionPairs = new List<CollisionPair<MatrixObject>>();
            IList<MatrixObject> currentCollisionList = this.collisionMatrix[row, col];

            if (currentCollisionList != null)
            {
                for (int objAIndex = 0; objAIndex < currentCollisionList.Count; objAIndex++)
                {
                    for (int objBIndex = objAIndex + 1; objBIndex < currentCollisionList.Count; objBIndex++)
                    {
                        if (!currentCollisionList[objAIndex].CollidesWithSameType())
                        {
                            if (currentCollisionList[objAIndex].GetObjectTypeName() != currentCollisionList[objBIndex].GetObjectTypeName())
                            {
                                var currentCollisionPair =
                                new CollisionPair<MatrixObject>(currentCollisionList[objAIndex], currentCollisionList[objBIndex]);
                                collisionPairs.Add(currentCollisionPair);
                            }
                        }
                        else
                        {
                            var currentCollisionPair =
                                new CollisionPair<MatrixObject>(currentCollisionList[objAIndex], currentCollisionList[objBIndex]);
                            collisionPairs.Add(currentCollisionPair);
                        }
                    }
                }
            }
            return collisionPairs;
        }

        public List<CollisionPair<MatrixObject>> GetAllCollisionPairs()
        {
            var allCollisionPairs = new List<CollisionPair<MatrixObject>>();

            for (int row = 0; row < this.Rows; row++)
            {
                for (int col = 0; col < this.Cols; col++)
                {
                    var currentCollisionPairs = this.GetCollisionPairsAt(row, col);
                    foreach (var collisionPair in currentCollisionPairs)
                    {
                        allCollisionPairs.Add(collisionPair);
                    }
                }
            }

            return allCollisionPairs;
        }
    }

    public static class CollisionDetection
    {
        static bool CollisionPossible(MatrixObject objA, MatrixObject objB)
        {
            bool aliveNonCollidedCollisionObjects = objA.IsAlive() && objB.IsAlive() && objA.CanCollide() && objB.CanCollide() && (!objA.HasCollided) && (!objA.HasCollided);
            if (aliveNonCollidedCollisionObjects)
            {
                //if they are the same type it is possible for them not to collide
                if (objA.GetObjectTypeName() == objB.GetObjectTypeName())
                {
                    if (!objA.CollidesWithSameType()) //if they are the same type, it doesn't matter which object's collision properties we check
                    {
                        return false;
                    }
                }
                //else, they collide
                return true;
            }
            return false;
        }

        static bool ObjectsSwitchedPositions(MatrixObject objA, MatrixObject objB)
        {
            return (objA.PrevRow == objB.Row) && (objA.PrevCol == objB.Col) &&
                (objA.Row == objB.PrevRow) && (objA.Col == objB.PrevCol);
        }

        private static List<CollisionPair<MatrixObject>> GetPositionSwitchCollisionPairs(ICollection<MatrixObject> objects)
        {
            var switchCollisions = new HashSet<CollisionPair<MatrixObject>>();

            foreach (var objA in objects)
            {
                foreach (var objB in objects)
                {
                    if ((!objA.Equals(objB)) && CollisionDetection.ObjectsSwitchedPositions(objA, objB))
                    {
                        if (CollisionDetection.CollisionPossible(objA, objB))
                        {
                            switchCollisions.Add(new CollisionPair<MatrixObject>(objA, objB));
                        }
                    }
                }
            }

            return switchCollisions.ToList();
        }

        public static List<CollisionPair<MatrixObject>> GetCollisions(ICollection<MatrixObject> objects)
        {
            List<CollisionPair<MatrixObject>> collisions = new List<CollisionPair<MatrixObject>>();
            foreach (var obj in objects)
            {
                obj.HasCollided = false;
            }

            int objectsCount = objects.Count;
            if (objects.Count > 0)
            {
                CollisionMatrix collisionMatrix = new CollisionMatrix(objects);
                var positionSwitchCollisions = CollisionDetection.GetPositionSwitchCollisionPairs(objects);
                collisions = collisionMatrix.GetAllCollisionPairs();
                collisions.AddRange(positionSwitchCollisions);
            }
            return collisions;
        }
    }
}
