﻿/**********************************************************************************
    File:        InfoMessageEventHandler.cs
    Descritpion: Infrastructure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using Task1_Game1_2_3.Algorithm.EventsArgs;

namespace Task1_Game1_2_3.Algorithm.Delegates
{
    public delegate void InfoMessageEventHandler(object sender, InfoEventArgs e);
}
