﻿/**********************************************************************************
    File:        1Fielder.cs
    Descritpion: Data structure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Task1_Game1_2_3.Algorithm.Data.Interfaces;

namespace Task1_Game1_2_3.Algorithm.Data
{
    public class OneFielder : IFielder 
    {
        protected Point a;

        public Point A
        {
            get { return this.a; }
            set { this.a = value; }
        }

        protected double medianIndex = -1;

        public double MedianIndex
        {
            get { return this.medianIndex; }
            set { this.medianIndex = value; }
        }

        public OneFielder(Point a, double medianIndex)
        {
            this.a = a;
            this.medianIndex = medianIndex;
        }

        public OneFielder()
        {
            // Nothing...
        }

        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false.
            if (obj == null)
            {
                return false;
            }

            // If parameter cannot be cast to Point return false.
            OneFielder of = obj as OneFielder;
            if ((System.Object)of == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (this.a == of.a) && (this.medianIndex == of.medianIndex);
        }

        public bool Equals(OneFielder of)
        {
            // If parameter is null return false:
            if ((object)of == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (this.a == of.a) && (this.medianIndex == of.medianIndex);
        }

        public override int GetHashCode()
        {
            int medianIndexInt = Convert.ToInt32(this.medianIndex);
            return medianIndexInt ^ this.a.X ^ this.a.Y;
        }
    }
}
