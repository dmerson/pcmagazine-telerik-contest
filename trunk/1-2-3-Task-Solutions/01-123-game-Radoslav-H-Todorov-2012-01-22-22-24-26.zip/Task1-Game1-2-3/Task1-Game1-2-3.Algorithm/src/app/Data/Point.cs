﻿/**********************************************************************************
    File:        Point.cs
    Descritpion: Data structure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1_Game1_2_3.Algorithm.Data
{
    public class Point
    {
        private int x = -1;

        public int X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        private int y = -1;

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public Point()
        {
            // Nothing...
        }

        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false.
            if (obj == null)
            {
                return false;
            }

            // If parameter cannot be cast to Point return false.
            Point p = obj as Point;
            if ((System.Object)p == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (this.x == p.x) && (this.y == p.y);
        }

        public bool Equals(Point p)
        {
            // If parameter is null return false:
            if ((object)p == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (this.x == p.x) && (this.y == p.y);
        }

        public override int GetHashCode()
        {
            return this.x ^ this.y;
        }

        public override string ToString()
        {
            return string.Format("X: '{0}', Y: {1}", this.x, this.y);
        }
    }
}
