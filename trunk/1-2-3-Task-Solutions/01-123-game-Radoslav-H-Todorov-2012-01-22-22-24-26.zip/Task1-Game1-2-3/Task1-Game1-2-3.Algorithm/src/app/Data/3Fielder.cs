﻿/**********************************************************************************
    File:        3Fielder.cs
    Descritpion: Data structure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Task1_Game1_2_3.Algorithm.Data;

namespace Task1_Game1_2_3.Algorithm.Data
{
    public class ThreeFielder : TwoFielder
    {       
        protected Point c;

        public Point C
        {
            get { return c; }
            set { c = value; }
        }

        public ThreeFielder(Point a, Point b, Point c, double medianIndex)
        {
            base.a = a;
            base.b = b;
            this.c = c;
            base.medianIndex = medianIndex;
        }

        public ThreeFielder()
        {
            // Nothing...
        }
    }
}
