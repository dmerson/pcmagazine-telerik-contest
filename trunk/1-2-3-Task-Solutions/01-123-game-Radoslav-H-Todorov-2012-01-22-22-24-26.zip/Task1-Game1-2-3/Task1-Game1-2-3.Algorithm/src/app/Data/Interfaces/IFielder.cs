﻿/**********************************************************************************
    File:        IFielder.cs
    Descritpion: Data interface
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1_Game1_2_3.Algorithm.Data.Interfaces
{
    public interface IFielder
    {
        double MedianIndex { get; set; }
    }
}
