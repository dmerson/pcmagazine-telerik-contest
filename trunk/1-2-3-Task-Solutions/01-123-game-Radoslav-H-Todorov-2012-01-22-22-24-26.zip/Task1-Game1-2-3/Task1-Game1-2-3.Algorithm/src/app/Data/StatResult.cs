﻿/**********************************************************************************
    File:        StatResult.cs
    Descritpion: Data structure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1_Game1_2_3.Algorithm.Data
{
    public struct StatResult
    {
        private char player;

        public char Player
        {
            get { return player; }
            set { player = value; }
        }

        private int score;

        public int Score
        {
            get { return score; }
            set { score = value; }
        }

        public StatResult(char player, int score)
        {
            this.player = player;
            this.score = score;
        }

        public override string ToString()
        {
            return string.Format("Player: '{0}', Score: {1}", this.player, this.score);
        }
    }
}
