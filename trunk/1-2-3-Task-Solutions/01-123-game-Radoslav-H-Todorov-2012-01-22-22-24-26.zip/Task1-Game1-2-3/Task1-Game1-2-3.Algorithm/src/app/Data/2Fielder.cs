﻿/**********************************************************************************
    File:        2Fielder.cs
    Descritpion: Data structure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1_Game1_2_3.Algorithm.Data
{
    public class TwoFielder : OneFielder
    {
        protected Point b;

        public Point B
        {
            get { return b; }
            set { b = value; }
        }

        public TwoFielder(Point a, Point b, double medianIndex)
        {
            base.a = a;
            this.b = b;
            base.medianIndex = medianIndex;
        }

        public TwoFielder()
        {
            // Nothing...
        }
    }
}
