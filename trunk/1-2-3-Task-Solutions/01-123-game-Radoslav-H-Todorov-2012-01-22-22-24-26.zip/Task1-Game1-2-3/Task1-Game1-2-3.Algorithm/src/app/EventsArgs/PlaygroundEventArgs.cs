﻿/**********************************************************************************
    File:        PlaygroundEventArgs.cs
    Descritpion: Infrastructure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;

namespace Task1_Game1_2_3.Algorithm.EventsArgs
{
    public class PlaygroundEventArgs : EventArgs
    {
        private char[][] playground;

        public char[][] Playground
        {
            get { return playground; }
            set { playground = value; }
        }

        public PlaygroundEventArgs()
        {
            this.playground = null;
        }

        public PlaygroundEventArgs(char[][] playground)
        {
            this.playground = playground;
        }
    }
}