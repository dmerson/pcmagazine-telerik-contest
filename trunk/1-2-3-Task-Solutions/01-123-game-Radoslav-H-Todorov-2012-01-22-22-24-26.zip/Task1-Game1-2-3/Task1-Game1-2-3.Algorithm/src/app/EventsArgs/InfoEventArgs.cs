﻿/**********************************************************************************
    File:        InfoEventArgs.cs
    Descritpion: Infrastructure
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;

namespace Task1_Game1_2_3.Algorithm.EventsArgs
{
    public class InfoEventArgs : EventArgs
    {
        private string message;

        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        public InfoEventArgs()
        {
            this.message = string.Empty;
        }

        public InfoEventArgs(string message)
        {
            this.message = message;
        }
    }
}