﻿/**********************************************************************************
    File:        Games.cs
    Descritpion: Business logic of the '1-2-3 Game'
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Task1_Game1_2_3.Algorithm.Data;
using Task1_Game1_2_3.Algorithm.Data.Interfaces;
using Task1_Game1_2_3.Algorithm.Delegates;
using Task1_Game1_2_3.Algorithm.EventsArgs;

namespace Task1_Game1_2_3.Algorithm
{
    /// <summary>
    /// Encapsulates the business logic of the '1-2-3' Game.
    /// </summary>
    public class Game // Publisher of the events
    {
        #region Events
        /// <summary>
        /// Allows the subscribers to retrieve error information, if an error occurs.
        /// </summary>
        public event ErrorMessageEventHandler ReportError = delegate { }; // cannot be null, important for thread safety

        /// <summary>
        /// Allows the subscribers to retrieve playground information.
        /// </summary>
        public event PlaygroundMessageEventHandler ReportPlayground = delegate { }; // cannot be null, important for thread safety

        /// <summary>
        /// Allows the subscribers to retrieve general information, if such is needed to be sent.
        /// </summary>
        public event InfoMessageEventHandler ReportInfo = delegate { }; // cannot be null, important for thread safety      
        #endregion

        #region Game Settings
        // Standard error message shown on the console
        private static readonly string ERROR_MESSAGE_CONSOLE = "error";

        // Boundaries of the playground
        private static readonly byte MIN_BOUNDARY = 3;
        private static readonly byte MAX_BOUNDARY = 20;

        // Infrastracture...
        private static readonly byte DIMENSIONS = 2;
        private static readonly byte M_INDEX = 0;
        private static readonly byte N_INDEX = 1;

        // The player chars used in the game
        private static readonly string PLAYER_CHARS = "AB";

        // Neutral (empty) char used in the game
        public static readonly char NEUTRAL_CHAR = '-'; 

        // Tag for information messages
        public static readonly string INFO = "INFO";

        // Tag for debug information messages
        public static readonly string DEBUG_INFO = "DEBUG_INFO";

        // Tag for error messages
        public static readonly string ERROR = "ERROR";

        // Player chars + Neutral (empty) char
        private static readonly string GAME_CHARS = string.Format("{0}{1}", PLAYER_CHARS, NEUTRAL_CHAR.ToString());

        // Used in the algorithm
        private Random rnd = new Random();
        #endregion

        #region Game Data
        // Start and end timestamp for the algorithm execution
        private DateTime beginTime;
        private DateTime endTime;
        // Currently playing player
        private char currPlayer = 'A';

        // Size of the playground
        private byte rowsSize = 4;
        private byte columnsSize = 6;

        // Medians of the playground (shows the center of the playground)
        private float medianRowsSize
        {
            get { return (float)(this.rowsSize - 1) / 2; }
        }
        private float medianColumnsSize
        {
            get { return (float)(this.columnsSize - 1) / 2; }
        }

        // Current 'stable' playground, 'estimated' next playground and playground created by the algorithm
        private char[][] playground;
        private char[][] playgroundCycle;
        private char[][] playgroundAlgorithm;

        // Holds the results of the played tournament (all game rounds). Round is a game when one player starts and until the playground is filled. The next round the game starts the second player.
        private Dictionary<char, StatResult> finalStatistics = new Dictionary<char, StatResult>();

        // Holds the incomming data (console input or test case strings)
        private Queue<string> inputBuffer = new Queue<string>();

        // Shows how many game rounds are played (i.e. finished) so far
        private byte playedGames = 0;

        // Loaded algorithms for player 'A' and 'B'
        private List<string> algoPlayerA = new List<string>();
        private List<string> algoPlayerB = new List<string>();
        #endregion

        #region Constructors
        /// <summary>
        /// Constructor of the game. 
        /// Also describes the workflow of the game. 
        /// Used for the test cases and for normal console run of the program.
        /// </summary>
        protected internal Game()
        {
            try
            {
#if TEST_CASE
                this.SimulateInputByTestCase(TestCases.test1);
#endif
                // E.g. 6 columns x 4 rows
                this.InitializeDimensions();

                // E.g. '-' sign for every cell
                this.InitializePlayground();

                // E.g. 'A'
                this.InitializeCurrentPlayer();

#if ALGHORITHM_TEST
                // Just to be able to test the algorithm, otherwise this is not used at all...
                this.InitializePlaygroundSimpleNoPlayground();
                this.PerformSingleCycle();
                this.PrintArray(this.playground);
                return;
#endif
                // Play full tournament (everyone against everyone) in separate round
                while (this.playedGames < PLAYER_CHARS.Length)
                {
                    // Perform the game
                    this.PerformAllCycles();
                    
                    // And the winner is
                    List<StatResult> roundResult = new List<StatResult>();
                    this.ShowStatistics(this.playground, out roundResult);
                    
                    // Merge the result with the final statistics
                    this.MergeStatistics(roundResult);

                    // Increment the 'playeedGames' counter
                    this.playedGames++;

                    // Get the next player to play first in the next round
                    this.currPlayer = this.GetNextPlayerForRound(playedGames);

                    // Initialize the playground
                    this.InitializePlaygroundSimple();
                }
                // Distpaly the final statistics.
                this.DisplayFinalStatistics();                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ERROR_MESSAGE_CONSOLE);
                Debug.WriteLine(ex.Message);
            }
            finally
            {               
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
            }
        }

        /// <summary>
        /// Constructor of the game used by the simulator.
        /// </summary>
        /// <param name="rowsSize"></param>
        /// <param name="columnsSize"></param>
        public Game(int rowsSize, int columnsSize, List<string> algoPlayerA, List<string> algoPlayerB)
        {
            // Assigning the available algorithms.
            this.algoPlayerA = algoPlayerA;
            this.algoPlayerB = algoPlayerB;

            // Assign (initialize) dimensions for the playground
            this.rowsSize = (byte)rowsSize;
            this.columnsSize = (byte)columnsSize;

            // Initialize the playground
            this.InitializePlaygroundSimple();

            // No need to initialize player...
        }
        #endregion

        #region Input (Used for console and test case mode)
        /// <summary>
        /// Captures console's input data.
        /// </summary>
        private void CaptureInput()
        {
            string input = Console.ReadLine();

            // Pre-pre-processor argument input
            input = input.Trim();
            string[] splitter = new string[] { "\r\n" };
            foreach (string uiChunk in input.Split(splitter, StringSplitOptions.RemoveEmptyEntries))
                inputBuffer.Enqueue(uiChunk);

            if (inputBuffer.Count < 1)
                throw new Exception("Missing input line arguments! [Zero found, at least one required]");
        }

        /// <summary>
        /// Analyzes the first input row which gives the dimensions of the playground.
        /// </summary>
        /// <param name="ui"></param>
        /// <returns></returns>
        private byte[] AnalyzeFirstLineInput(string ui)
        {
            // Pre-processor argument input
            string[] MN = ui.Trim().Split(new char[] { ' ' }); //TODO Feature: check and ignore if space intervals are more than one

            // Check input size (as argument)
            if (MN.Length != DIMENSIONS)
                throw new Exception(string.Format("Wrong number of input arguments! [{0} - found, {1} - required]", MN.Length, DIMENSIONS));

            // Result
            byte[] result = new byte[DIMENSIONS];

            // Handle M
            byte M = 0;
            try
            {
                M = Byte.Parse(MN[M_INDEX]);
            }
            catch (FormatException)
            {
                throw new Exception(string.Format("'M' is not in the valid format! ['{0}' - found, expected {1}<='{0}'<={2}]", M, MIN_BOUNDARY, MAX_BOUNDARY));
            }
            catch (OverflowException)
            {
                throw new Exception(string.Format("'M' is not in the valid format! ['{0}' - found, expected {1}<='{0}'<={2}]", M, MIN_BOUNDARY, MAX_BOUNDARY));
            }
            if (!(MIN_BOUNDARY <= M) || !(M <= MAX_BOUNDARY))
                throw new Exception(string.Format("'M' is not in the valid range! [{0}<={1}<={2}]", MIN_BOUNDARY, M, MAX_BOUNDARY));

            result[M_INDEX] = M;

            // Handle N
            byte N = 0;
            try
            {
                N = Byte.Parse(MN[N_INDEX]);
            }
            catch (FormatException)
            {
                throw new Exception(string.Format("'N' is not in the valid format! ['{0}' - found, expected {1}<='{0}'<={2}]", N, MIN_BOUNDARY, MAX_BOUNDARY));
            }
            catch (OverflowException)
            {
                throw new Exception(string.Format("'N' is not in the valid format! ['{0}' - found, expected {1}<='{0}'<={2}]", N, MIN_BOUNDARY, MAX_BOUNDARY));
            }
            result[N_INDEX] = N;
            if (!(MIN_BOUNDARY <= N) || !(N <= MAX_BOUNDARY))
            {
                throw new Exception(string.Format("'N' is not in the valid range! [{0}<={1}<={2}]", MIN_BOUNDARY, N, MAX_BOUNDARY));
            }

            return result;
        }

        /// <summary>
        /// Analyzes an input row. 
        /// </summary>
        /// <param name="currRow"></param>
        /// <param name="ui"></param>
        /// <returns></returns>
        private char[] AnalyzeRowInput(string ui)
        {
            // Pre-processor argument input
            ui = ui.Trim();

            int uiLength = ui.Length;
            if (uiLength != columnsSize)
                throw new Exception(string.Format("Row size is not valid ['{0}' - found, expected '{1}']", uiLength, columnsSize));

            if (!Regex.IsMatch(ui, string.Format("^[{0}]+", GAME_CHARS)))
                throw new Exception(string.Format("Row contains not allowed characters ['{0}' - found, expected '{1}']", ui, GAME_CHARS));

            // Result
            char[] result = ui.ToCharArray();

            return result;
        }

        /// <summary>
        /// Analyzes 'player' letter input 
        /// </summary>
        /// <param name="ui"></param>
        /// <returns></returns>
        private char AnalyzePlayerInput(string ui)
        {
            // Pre-processor argument input
            ui = ui.Trim();

            int uiLength = ui.Length;
            if (uiLength != 1)
                throw new Exception(string.Format("Length is not valid ['{0}' - found, expected '1']", uiLength));

            if (!Regex.IsMatch(ui, string.Format("^[{0}]+", PLAYER_CHARS)))
                throw new Exception(string.Format("Row contains not allowed character ['{0}' - found, expected '{1}']", ui, PLAYER_CHARS));

            // Result
            return Char.Parse(ui);
        }

        /// <summary>
        /// Simulates the user input by passing a parameter with desired input.
        /// This method is used in test case mode.
        /// </summary>
        /// <param name="sui"></param>
        private void SimulateInputByTestCase(string sui)
        {
            sui = sui.Trim();
            string[] splitter = new string[] { "\r\n" };
            foreach (string uiChunk in sui.Split(splitter, StringSplitOptions.RemoveEmptyEntries))
                inputBuffer.Enqueue(uiChunk);

            if (inputBuffer.Count < 1)
                throw new Exception("Incomplete test!");
        }
        #endregion

        #region Game Play
        /// <summary>
        /// Gets the dimensions of the playground from the console or from stored use case.
        /// </summary>
        private void InitializeDimensions()
        {
            // User input (dimensions)
            if (this.inputBuffer.Count == 0)
                this.CaptureInput();

            // Analyze dimensions
            string input = this.inputBuffer.Dequeue();
#if TEST_CASE
            Console.WriteLine(input);
#endif
            byte[] dimensionsSize = this.AnalyzeFirstLineInput(input);
            this.rowsSize = dimensionsSize[0];
            this.columnsSize = dimensionsSize[1];
        }

        /// <summary>
        /// Initializes the playground data from the console or from stored use case.
        /// </summary>
        private void InitializePlayground()
        {
            // User initial input (rows and columns data)
            this.playground = new char[this.rowsSize][];
            this.playgroundCycle = new char[this.rowsSize][];
            for (byte i = 0; i < this.rowsSize; i++)
            {
                if (this.inputBuffer.Count == 0)
                    this.CaptureInput();

                // Analyze each row input
                string input = this.inputBuffer.Dequeue();
#if TEST_CASE
                Console.WriteLine(input);
#endif
                this.playground[i] = this.playgroundCycle[i] = this.AnalyzeRowInput(input);
            }
        }

        /// <summary>
        /// Initializes the playground data by using only 'NEUTRAL_CHAR' equal to '-'.
        /// </summary>
        private void InitializePlaygroundSimple()
        {
            this.playground = new char[this.rowsSize][];
            this.playgroundCycle = new char[this.rowsSize][];
            this.playgroundAlgorithm = new char[this.rowsSize][];
            for (int i = 0; i < this.rowsSize; i++)
            {
                this.playground[i] = new char[this.columnsSize];
                this.playgroundCycle[i] = new char[this.columnsSize];
                this.playgroundAlgorithm[i] = new char[this.columnsSize];
                for (int j = 0; j < this.columnsSize; j++)
                {
                    this.playground[i][j] = this.playgroundCycle[i][j] = this.playgroundAlgorithm[i][j] = NEUTRAL_CHAR;
                }
            }
        }


        /// <summary>
        /// Initializes the playground data by using only 'NEUTRAL_CHAR' equal to '-'.
        /// </summary>
        private void InitializePlaygroundSimpleNoPlayground()
        {
            this.playgroundCycle = new char[this.rowsSize][];
            this.playgroundAlgorithm = new char[this.rowsSize][];
            for (int i = 0; i < this.rowsSize; i++)
            {
                this.playgroundCycle[i] = new char[this.columnsSize];
                this.playgroundAlgorithm[i] = new char[this.columnsSize];
                for (int j = 0; j < this.columnsSize; j++)
                {
                    this.playgroundCycle[i][j] = this.playgroundAlgorithm[i][j] = NEUTRAL_CHAR;
                }
            }
        }

        /// <summary>
        /// Initializes the current player from the console or from stored use case.
        /// </summary>
        private void InitializeCurrentPlayer()
        {
            // Who is playing first?
            if (this.inputBuffer.Count == 0)
                this.CaptureInput();

            string input = inputBuffer.Dequeue();
#if TEST_CASE
            Console.WriteLine(input);
#endif
            this.currPlayer = this.AnalyzePlayerInput(input);
        }

        /// <summary>
        /// Performs all cycles (=steps) for both playsers for one game (round).
        /// </summary>
        private void PerformAllCycles()
        {
            do
            {
                this.PerformSingleCycle();
            }
            // Until the game is over
            while (!this.GameOver(this.playground));
        }
        
        /// <summary>
        /// Perfroms the cycle (=step) for the current player and changes the player. Used in simulator mode.
        /// </summary>
        private void PerformSingleCycle()
        {
            bool algoIsUsed = false;
#if SIMULATOR
            // Time
            this.beginTime = DateTime.UtcNow;

            // Play strategy for a computer player... 
            this.playgroundCycle = this.GenerateSolution(this.playground);

            //Time
            this.endTime = DateTime.UtcNow;
            double algoTime = (this.endTime - this.beginTime).TotalMilliseconds;
            if (algoTime > 1000)
            {
                FireReportCriticalError(string.Format("Algorithm exceeded time! [required: max 1000ms, found: {0}ms", algoTime));
            }
            
            this.FireReportInfo("Measured algorithm time: " + algoTime + " ms.");
           
            algoIsUsed = true;
#endif

#if ALGHORITHM_TEST
            // Just to be able to test the algorithm, otherwise this is not used at al...
            this.beginTime = DateTime.UtcNow;
            this.playgroundCycle = this.GenerateSolution(this.playground);
            this.endTime = DateTime.UtcNow;
            double algoTime = (this.endTime - this.beginTime).TotalMilliseconds;
            //UNTIL .NET LOADS WHATEVER IS NEEDED SOMETIMES THE FIRST USE OF THE ALGORITHME TAKES A LOT OF TIME!!!
            //if (algoTime > 1000)
            //{
            //    throw new Exception(string.Format("Algorithm exceeded time! [required: max 1000ms, found: {0}ms", algoTime));
            //}
            //Console.WriteLine("Measured algorithm time: " + algoTime + " ms.");
            algoIsUsed = true;
#endif 

            if (!algoIsUsed)
            {
                string input = string.Empty;
                //User Input for player (rows and columns data)
                for (byte i = 0; i < this.rowsSize; i++)
                {
                    if (this.inputBuffer.Count == 0)
                        this.CaptureInput();

                    //Analyze row input
                    input = this.inputBuffer.Dequeue();
#if TEST_CASE
                    Console.WriteLine(input);
#endif
                    this.playgroundCycle[i] = this.AnalyzeRowInput(input);
                }
            }
            if (this.VerifyData(this.playground, this.playgroundCycle))
            {
                this.CopyData(this.playgroundCycle, this.playground);
                this.currPlayer = this.GetNextPlayer();
#if (!ALGHORITHM_TEST)
                this.PrintChar(this.currPlayer);
#endif

                this.FireReportPlayground(this.playground);
            }
            else
            {
                string problem = "Data is not valid!";
                this.FireReportError(problem);
#if !SIMULATOR

                throw new Exception(problem);
#endif
            }
        }

        /// <summary>
        /// Perfroms the cycle (=step) for the current player plus changing the current player. 
        /// Afterwards checks if the game is over, if yes - show results and reset the playground.
        /// If the game is over and is the last in the tournament line of games the final results are displayed.
        /// </summary>
        public void PerformSingleCycleOnDemand()
        {            
            this.PerformSingleCycle();

            // Until the game is over
            if (this.GameOver(this.playground))
            {
                // And the winner is
                List<StatResult> roundResult = new List<StatResult>();
                this.ShowStatistics(this.playground, out roundResult);

                // Merge the result with the final statistics
                this.MergeStatistics(roundResult);

                // Increment the 'playeedGames' counter
                this.playedGames++;

                // Get the next player to play first in the next round
                this.currPlayer = this.GetNextPlayerForRound(playedGames);

                // Initialize the playground
                this.InitializePlaygroundSimple();
            }

            if (this.playedGames >= PLAYER_CHARS.Length)
            {
                // Distpaly the final statistics.
                this.DisplayFinalStatistics();     
            }
        }

        /// <summary>
        /// Verifies if the new playground is valid based on the current
        /// </summary>
        /// <param name="curr"></param>
        /// <param name="next"></param>
        /// <returns></returns>
        private bool VerifyData(char[][] curr, char[][] next)
        {
            List<Point> delta = new List<Point>(3);

            for (int i = 0; i < curr.Length; i++)
            {
                for (int j = 0; j < curr[i].Length; j++)
                {
                    if (curr[i][j] != next[i][j])
                    {
                        delta.Add(new Point(i, j));
                    }
                }
            }

            // Too much changes!
            if (delta.Count > 4)
                return false;

            // No changes!
            if (delta.Count == 0)
                return false;

            // One field change
            if (delta.Count == 1)
            {
                // Simply OK for one field change!
                return (curr[delta[0].X][delta[0].Y] == NEUTRAL_CHAR && next[delta[0].X][delta[0].Y] == currPlayer);
            }

            if (delta.Count == 2)
            {
                bool firstField = (curr[delta[0].X][delta[0].Y] == NEUTRAL_CHAR && next[delta[0].X][delta[0].Y] == currPlayer);

                if (!firstField)
                    return false;

                // Two field change
                // \
                if (curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y + 1)
                    return true;

                // -
                if (curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y)
                    return true;

                // /
                if (curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y - 1)
                    return true;

                // |
                if (curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X
                    && delta[1].Y == delta[0].Y + 1)
                    return true;

                return false;
            }

            if (delta.Count == 3)
            {
                bool firstField = (curr[delta[0].X][delta[0].Y] == NEUTRAL_CHAR && next[delta[0].X][delta[0].Y] == currPlayer);

                if (!firstField)
                    return false;

                // Three field change                
                // \
                if ((curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y + 1)
                    &&
                    (curr[delta[2].X][delta[2].Y] == NEUTRAL_CHAR
                    && next[delta[2].X][delta[2].Y] == currPlayer
                    && delta[2].X == delta[1].X + 1
                    && delta[2].Y == delta[1].Y + 1))
                    return true;

                // -
                if ((curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y)
                    &&
                    (curr[delta[2].X][delta[2].Y] == NEUTRAL_CHAR
                    && next[delta[2].X][delta[2].Y] == currPlayer
                    && delta[2].X == delta[1].X + 1
                    && delta[2].Y == delta[1].Y))
                    return true;

                // /
                if ((curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X + 1
                    && delta[1].Y == delta[0].Y - 1)
                    &&
                    (curr[delta[2].X][delta[2].Y] == NEUTRAL_CHAR
                    && next[delta[2].X][delta[2].Y] == currPlayer
                    && delta[2].X == delta[1].X + 1
                    && delta[2].Y == delta[1].Y - 1))
                    return true;

                // |
                if ((curr[delta[1].X][delta[1].Y] == NEUTRAL_CHAR
                    && next[delta[1].X][delta[1].Y] == currPlayer
                    && delta[1].X == delta[0].X
                    && delta[1].Y == delta[0].Y + 1)
                    &&
                    (curr[delta[2].X][delta[2].Y] == NEUTRAL_CHAR
                    && next[delta[2].X][delta[2].Y] == currPlayer
                    && delta[2].X == delta[1].X
                    && delta[2].Y == delta[1].Y + 1))
                    return true;

                return false;
            }
            return true;
        }

        /// <summary>
        /// Retrieves the next player by order (which is predifined in the game settings).
        /// </summary>
        /// <returns></returns>
        private char GetNextPlayer()
        {
            int indCurrPlayer = PLAYER_CHARS.IndexOf(currPlayer);

            // Last Player in the turn. Start again.
            if (indCurrPlayer + 1 == PLAYER_CHARS.Length)
                return PLAYER_CHARS[0];

            // Next player.
            return PLAYER_CHARS[indCurrPlayer + 1];
        }
        
        /// <summary>
        /// Retrieves the next player based on the played games (rounds) so far.
        /// </summary>
        /// <returns></returns>
        private char GetNextPlayerForRound(int playedGames)
        {
            try
            {
                return PLAYER_CHARS[playedGames];
            }
            catch (Exception)
            {
                return NEUTRAL_CHAR;
            }
        }

        /// <summary>
        /// Checks if the game is over i.e. when all free(neutral) fields are filled in.
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        private bool GameOver(char[][] arr)
        {
            Predicate<char> predicate = HasNeutralChar;

            bool result = true;

            for (int i = 0; i < arr.Length; i++)
            {
                result = Array.Exists(arr[i], predicate);

                if (result)
                    return false;
            }

            return true;
        }
        private bool HasNeutralChar(char ch)
        {
            return ch == NEUTRAL_CHAR;
        }

        /// <summary>
        /// Displays the result of the game (round) when is over.
        /// </summary>
        private void ShowStatistics(char[][] arr, out List<StatResult> pResult)
        {
            List<StatResult> result = new List<StatResult>();

            Predicate<char> predicate = FindAll;

            // Calcutlate the result
            char[] players = PLAYER_CHARS.OrderBy(p => p).ToArray();
            for (int j = 0; j < players.Length; j++)
            {
                int resultPlayer = 0;
                for (int i = 0; i < arr.Length; i++)
                {
                    playerSign = players[j];
                    char[] subArr = Array.FindAll(arr[i], predicate);

                    resultPlayer += subArr.Length;
                }
                result.Add(new StatResult(playerSign, resultPlayer));
            }

            // Order it
            result.OrderByDescending(sr => sr.Score);

            // Print it

            string message = string.Empty;
            foreach (StatResult item in result)
            {
                message += item.ToString();
                message += Environment.NewLine;
            }
            this.FireReportInfo(message);
            foreach (StatResult item in result)
            {
                Console.WriteLine(item);
            }
            pResult = result;
        }
        private char playerSign;
        private bool FindAll(char ch)
        {
            return ch == playerSign;
        }

        /// <summary>
        /// Merges the current round result.
        /// </summary>
        /// <param name="pResutl"></param>
        private void MergeStatistics(List<StatResult> pResutl)
        {
            foreach (StatResult item in pResutl)
            {
                StatResult playerFinalRestult;
                this.finalStatistics.TryGetValue(item.Player, out playerFinalRestult);
                
                // Update
                if (playerFinalRestult.Player == item.Player)
                {
                    StatResult sr = this.finalStatistics[playerFinalRestult.Player];
                    sr.Score += item.Score;
                    this.finalStatistics[playerFinalRestult.Player] = sr;
                }
                // Insert
                else
                {
                    this.finalStatistics.Add(item.Player, item);
                }
            }
        }

        /// <summary>
        /// Displays the final statistics of the game (after all rounds are played).
        /// </summary>
        private void DisplayFinalStatistics()
        {

            string message = "Final results:";
            message += Environment.NewLine;
            foreach (KeyValuePair<char, StatResult> item in this.finalStatistics)
            {
                message += item.Value.ToString();
                message += Environment.NewLine;
            }
            this.FireReportInfo(message);
            Console.WriteLine("Final results");
            foreach (KeyValuePair<char, StatResult> item in this.finalStatistics)
            {
                Console.WriteLine(item.Value.ToString());
            }
        }
        #endregion

        #region Algorithm
        /// <summary>
        /// Generates the next playground based on the algorithm.
        /// </summary>
        /// <param name="curr"></param>
        /// <returns></returns>
        private char[][] GenerateSolution(char[][] curr)
        {
            // Determinate the used algorithms
            List<string> used = new List<string>();

            if (this.currPlayer == PLAYER_CHARS[0])
            {
                used = this.algoPlayerA;
            }
            else if (this.currPlayer == PLAYER_CHARS[1])
            {
                used = this.algoPlayerB;
            }
            else
            {
                this.FireReportError(string.Format("Invalid player is seleceted - '{0}'. No algorihms can be used", currPlayer));
                return curr;
            }

            // In case, there are no loaded algorithms
            if (used.Count == 0)
            {
                used.Add("Normal");
            }
          
            #region 3
            // Alsways start first to explore an option solutions with three fields
            List<ThreeFielder> bestOfBestThree = new List<ThreeFielder>();

            List<ThreeFielder> horizontalBestOfThree = this.FindBestHorizontally<ThreeFielder>();
            List<ThreeFielder> vertiacalBestOfThree = this.FindBestVerically<ThreeFielder>();
            List<ThreeFielder> diagonalBestOfThree = this.FindBestDiagonally<ThreeFielder>();
            List<ThreeFielder> revDiagonalBestOfThree = this.FindBestRevDiagonally<ThreeFielder>();

            // Best among all opition solutions
            if (used.Contains("Normal"))
            {
                bestOfBestThree.Clear();
                bestOfBestThree.AddRange(horizontalBestOfThree);
                bestOfBestThree.AddRange(vertiacalBestOfThree);
                bestOfBestThree.AddRange(diagonalBestOfThree);
                bestOfBestThree.AddRange(revDiagonalBestOfThree);
            }

            // Diagonals has priority
            if (used.Contains("DiagonalsFirst"))
            {
                bestOfBestThree.Clear();
                bestOfBestThree.AddRange(diagonalBestOfThree);
                bestOfBestThree.AddRange(revDiagonalBestOfThree);

                if (bestOfBestThree.Count == 0)
                {
                    bestOfBestThree.AddRange(horizontalBestOfThree);
                    bestOfBestThree.AddRange(vertiacalBestOfThree);
                }
            }

            // Order the option solutions (if any)
            bestOfBestThree.OrderBy(o => o.MedianIndex);
            if (bestOfBestThree.Count > 0)
            {
                // More than one option solution
                if (bestOfBestThree.Count > 1)
                {
                    // Find the best 
                    medianIndexBestThree = bestOfBestThree[0].MedianIndex;
                    Predicate<ThreeFielder> predicate = FindAllBestThree;                    
                    bestOfBestThree = bestOfBestThree.FindAll(predicate);

                    // Select from the best
                    if (bestOfBestThree.Count > 1)
                    {
                        int randomIndex = rnd.Next(bestOfBestThree.Count - 1);

                        // Assign the option solution 
                        this.CopyData(this.playground, this.playgroundAlgorithm);
                        this.playgroundAlgorithm[bestOfBestThree[randomIndex].A.X][bestOfBestThree[randomIndex].A.Y] = this.currPlayer;
                        this.playgroundAlgorithm[bestOfBestThree[randomIndex].B.X][bestOfBestThree[randomIndex].B.Y] = this.currPlayer;
                        this.playgroundAlgorithm[bestOfBestThree[randomIndex].C.X][bestOfBestThree[randomIndex].C.Y] = this.currPlayer;

                        this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}],[{5},{6}]"
                            , this.currPlayer, bestOfBestThree[randomIndex].A.X, bestOfBestThree[randomIndex].A.Y,
                                               bestOfBestThree[randomIndex].B.X, bestOfBestThree[randomIndex].B.Y,
                                               bestOfBestThree[randomIndex].C.X, bestOfBestThree[randomIndex].A.Y));

                        return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                    }
                    else
                    {
                        // Assign the option solution 
                        this.CopyData(this.playground, this.playgroundAlgorithm);
                        this.playgroundAlgorithm[bestOfBestThree[0].A.X][bestOfBestThree[0].A.Y] = this.currPlayer;
                        this.playgroundAlgorithm[bestOfBestThree[0].B.X][bestOfBestThree[0].B.Y] = this.currPlayer;
                        this.playgroundAlgorithm[bestOfBestThree[0].C.X][bestOfBestThree[0].C.Y] = this.currPlayer;

                        this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}],[{5},{6}]"
                            , this.currPlayer, bestOfBestThree[0].A.X, bestOfBestThree[0].A.Y,
                                               bestOfBestThree[0].B.X, bestOfBestThree[0].B.Y,
                                               bestOfBestThree[0].C.X, bestOfBestThree[0].A.Y));

                        return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                    }
                }
                // Only one option solution
                else
                {
                    // Assign the option solution 
                    this.CopyData(this.playground, this.playgroundAlgorithm);
                    this.playgroundAlgorithm[bestOfBestThree[0].A.X][bestOfBestThree[0].A.Y] = this.currPlayer;
                    this.playgroundAlgorithm[bestOfBestThree[0].B.X][bestOfBestThree[0].B.Y] = this.currPlayer;
                    this.playgroundAlgorithm[bestOfBestThree[0].C.X][bestOfBestThree[0].C.Y] = this.currPlayer;

                    this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}],[{5},{6}]"
                            , this.currPlayer, bestOfBestThree[0].A.X, bestOfBestThree[0].A.Y,
                                               bestOfBestThree[0].B.X, bestOfBestThree[0].B.Y,
                                               bestOfBestThree[0].C.X, bestOfBestThree[0].A.Y));

                    return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                }
            }
            else
            {
                // Nothing... start to look an option solution with two fields
            }

            #endregion

            #region 2
            // If no option solution is found yet start the same process with two fields...
            if (bestOfBestThree.Count == 0)
            {
                List<TwoFielder> bestOfBestTwo = new List<TwoFielder>();

                List<TwoFielder> horizontalBestOfTwo = this.FindBestHorizontally<TwoFielder>();
                List<TwoFielder> vertiacalBestOfTwo = this.FindBestVerically<TwoFielder>();
                List<TwoFielder> diagonalBestOfTwo = this.FindBestDiagonally<TwoFielder>();
                List<TwoFielder> revDiagonalBestOfTwo = this.FindBestRevDiagonally<TwoFielder>();

                if (used.Contains("Normal"))
                {
                    bestOfBestTwo.Clear();
                    bestOfBestTwo.AddRange(horizontalBestOfTwo);
                    bestOfBestTwo.AddRange(vertiacalBestOfTwo);
                    bestOfBestTwo.AddRange(diagonalBestOfTwo);
                    bestOfBestTwo.AddRange(revDiagonalBestOfTwo);
                }

                if (used.Contains("DiagonalsFirst"))
                {
                    bestOfBestTwo.Clear();
                    bestOfBestTwo.AddRange(diagonalBestOfTwo);
                    bestOfBestTwo.AddRange(revDiagonalBestOfTwo);

                    if (bestOfBestThree.Count == 0)
                    {
                        bestOfBestTwo.AddRange(horizontalBestOfTwo);
                        bestOfBestTwo.AddRange(vertiacalBestOfTwo);
                    }
                }

                // Order the option solutions (if any)
                bestOfBestTwo.OrderBy(o => o.MedianIndex);
                if (bestOfBestTwo.Count > 0)
                {
                    // More than one option solution
                    if (bestOfBestTwo.Count > 1)
                    {
                        // Find the best
                        medianIndexBestTwo = bestOfBestTwo[0].MedianIndex;
                        Predicate<TwoFielder> predicate = FindAllBestTwo;
                        bestOfBestTwo = bestOfBestTwo.FindAll(predicate);

                        // Select from the best
                        if (bestOfBestTwo.Count > 1)
                        {
                            int randomIndex = rnd.Next(bestOfBestTwo.Count - 1);

                            // Assign the option solution 
                            this.CopyData(this.playground, this.playgroundAlgorithm);
                            this.playgroundAlgorithm[bestOfBestTwo[randomIndex].A.X][bestOfBestTwo[randomIndex].A.Y] = this.currPlayer;
                            this.playgroundAlgorithm[bestOfBestTwo[randomIndex].B.X][bestOfBestTwo[randomIndex].B.Y] = this.currPlayer;
                            
                            this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}]"
                                                        , this.currPlayer, bestOfBestTwo[randomIndex].A.X, bestOfBestTwo[randomIndex].A.Y,
                                                                           bestOfBestTwo[randomIndex].B.X, bestOfBestTwo[randomIndex].B.Y));

                            return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                        }
                        else
                        {
                            // Assign the option solution 
                            this.CopyData(this.playground, this.playgroundAlgorithm);
                            this.playgroundAlgorithm[bestOfBestTwo[0].A.X][bestOfBestTwo[0].A.Y] = this.currPlayer;
                            this.playgroundAlgorithm[bestOfBestTwo[0].B.X][bestOfBestTwo[0].B.Y] = this.currPlayer;

                            this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}]"
                                                        , this.currPlayer, bestOfBestTwo[0].A.X, bestOfBestTwo[0].A.Y,
                                                                           bestOfBestTwo[0].B.X, bestOfBestTwo[0].B.Y));

                            return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                        }
                    }
                    // Only one option solution
                    else
                    {
                        // Assign the option solution 
                        this.CopyData(this.playground, this.playgroundAlgorithm);
                        this.playgroundAlgorithm[bestOfBestTwo[0].A.X][bestOfBestTwo[0].A.Y] = this.currPlayer;
                        this.playgroundAlgorithm[bestOfBestTwo[0].B.X][bestOfBestTwo[0].B.Y] = this.currPlayer;

                        this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}],[{3},{4}]"
                                                        , this.currPlayer, bestOfBestTwo[0].A.X, bestOfBestTwo[0].A.Y,
                                                                           bestOfBestTwo[0].B.X, bestOfBestTwo[0].B.Y));

                        return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                    }
                }
                else
                {
                    // Nothing... start to look an option solution with two fields
                }

                #endregion

                #region 1
                // Finally do it for one field
                if (horizontalBestOfTwo.Count == 0 && vertiacalBestOfTwo.Count == 0 && diagonalBestOfTwo.Count == 0 && revDiagonalBestOfTwo.Count == 0)
                {
                    List<OneFielder> bestOfBestOne = new List<OneFielder>();

                    List<OneFielder> horizontalBestOfOne = this.FindBestHorizontally<OneFielder>();

                    // No need to scan all the directions...but is required to eliminate the duplicate option solutions from the horizontal scan
                    bestOfBestOne.AddRange(horizontalBestOfOne);
                    bestOfBestOne = bestOfBestOne.Distinct().ToList();
                    
                    // Order the option solutions (if any)
                    bestOfBestOne.OrderBy(o => o.MedianIndex);
                    if (bestOfBestOne.Count > 0)
                    {
                        // More than one option solution
                        if (bestOfBestOne.Count > 1)
                        {
                            // Find the best
                            medianIndexBestOne = bestOfBestOne[0].MedianIndex;
                            Predicate<OneFielder> predicate = FindAllBestOne;
                            bestOfBestOne = bestOfBestOne.FindAll(predicate);

                            // Select from the best
                            if (bestOfBestOne.Count > 1)
                            {
                                int randomIndex = rnd.Next(bestOfBestOne.Count - 1);

                                // Assign the option solution 
                                this.CopyData(this.playground, this.playgroundAlgorithm);
                                this.playgroundAlgorithm[bestOfBestOne[randomIndex].A.X][bestOfBestOne[randomIndex].A.Y] = this.currPlayer;

                                this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}]"
                                                        , this.currPlayer, bestOfBestOne[randomIndex].A.X, bestOfBestOne[randomIndex].A.Y));

                                return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                            }
                            else
                            {
                                // Assign the option solution 
                                this.CopyData(this.playground, this.playgroundAlgorithm);
                                this.playgroundAlgorithm[bestOfBestOne[0].A.X][bestOfBestOne[0].A.Y] = this.currPlayer;

                                this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}]"
                                                        , this.currPlayer, bestOfBestOne[0].A.X, bestOfBestOne[0].A.Y));

                                return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                            }
                        }
                        // Only one option solution
                        else
                        {
                            // Assign the option solution 
                            this.CopyData(this.playground, this.playgroundAlgorithm);
                            this.playgroundAlgorithm[bestOfBestOne[0].A.X][bestOfBestOne[0].A.Y] = this.currPlayer;

                            this.FireReportDebugInfo(string.Format("'{0}':[{1},{2}]"
                                                        , this.currPlayer, bestOfBestOne[0].A.X, bestOfBestOne[0].A.Y));

                            return this.playgroundAlgorithm; // NOTE: the method exits here and let it be so...
                        }
                    }

                    if (horizontalBestOfOne.Count == 0)
                    {
                        throw new Exception("No solution found but it was requested!");
                    }
                }
                #endregion
            }
            return curr;
        }
        private double medianIndexBestThree = -1;
        private bool FindAllBestThree(ThreeFielder tf)
        {
            return tf.MedianIndex == medianIndexBestThree;
        }
        private double medianIndexBestTwo = -1;
        private bool FindAllBestTwo(TwoFielder tf)
        {
            return tf.MedianIndex == medianIndexBestTwo;
        }
        private double medianIndexBestOne = -1;
        private bool FindAllBestOne(OneFielder tf)
        {
            return tf.MedianIndex == medianIndexBestOne;
        }

        /// <summary>
        /// Calculates the distance from the center ('medianRows' value, 'medianColumns' value) of the proposed 3,2 or 1 point(s).
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="medianRows"></param>
        /// <param name="medianColumns"></param>
        /// <returns></returns>
        private double CalculateMedianIndex(Point a, Point b, Point c)
        {
            double aXRow =                Math.Abs(a.X - this.medianRowsSize);
            double bXRow = ((b != null) ? Math.Abs(b.X - this.medianRowsSize) : 0);
            double cXRow = ((c != null) ? Math.Abs(c.X - this.medianRowsSize) : 0);

            double subResultRowsX =  aXRow + bXRow + cXRow;

            double aYRow =                Math.Abs(a.Y - this.medianColumnsSize);
            double bYRow = ((b != null) ? Math.Abs(b.Y - this.medianColumnsSize) : 0);
            double cYRow = ((c != null) ? Math.Abs(c.Y - this.medianColumnsSize) : 0);

            double subResultColumnsY = aYRow + bYRow + cYRow;

            return subResultRowsX + subResultColumnsY;
        }

        /// <summary>
        /// Finds the best possible solution consisting from 3, 2 or 1 field(s) in the horizonatal direction.
        /// The best possible is equal to a solution close to the center of the playground.
        /// </summary>
        /// <returns></returns>
        private List<T> FindBestHorizontally<T>() where T : IFielder, new ()
        {
            List<Point> points = new List<Point>();

            List<T> horizonalBest = new List<T>();
            
            // Scan horizontally for 1,2 or 3 empty fields (build string, make point list)
            for (int i = 0; i < this.rowsSize; i++)                                         // rows
            {
                StringBuilder sbRow = new StringBuilder(this.columnsSize);
                points.Clear();
                for (int j = 0; j < this.columnsSize; j++)                                  // columns
                {
                    sbRow.Append(this.playground[i][j]);
                    points.Add(new Point(i, j));
                }

                // Scanned horizonal line
                string rowString = sbRow.ToString();
                string rowStringOriginal = sbRow.ToString();

                // Option solution indexes                
                int firstIndex = -1;
                int lastIndex = -1;
                int stopIndex = -1;

                T temp = new T();
                if (temp is ThreeFielder)
                {
                    firstIndex = rowString.IndexOf("---");
                    lastIndex = rowString.LastIndexOf("---");
                    stopIndex = 2;
                }
                else if (temp is TwoFielder)
                {
                    firstIndex = rowString.IndexOf("--");
                    lastIndex = rowString.LastIndexOf("--");
                    stopIndex = 1;
                }
                else if (temp is OneFielder)
                {
                    firstIndex = rowString.IndexOf("-");
                    lastIndex = rowString.LastIndexOf("-");
                    stopIndex = 0;
                }
                else
                {
                    throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                }

                // More than one option to choose from
                if (firstIndex != lastIndex && firstIndex != -1)
                {
                    int rowStringOriginalLength = rowStringOriginal.Length;

                    for (int k = 0; k < rowStringOriginalLength - stopIndex; k++)
                    {
                        rowString = rowStringOriginal.Substring(k);

                        // Re-Calculate option solution indexes & Evaluate option solution
                        if (temp is ThreeFielder)
                        {
                            firstIndex = rowString.IndexOf("---") + k;
                            lastIndex = rowString.LastIndexOf("---") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref horizonalBest);
                        }
                        else if (temp is TwoFielder)
                        {
                            firstIndex = rowString.IndexOf("--") + k ;
                            lastIndex = rowString.LastIndexOf("--") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], null, ref horizonalBest);
                        }
                        else if (temp is OneFielder)
                        {
                            firstIndex = rowString.IndexOf("-") + k;
                            lastIndex = rowString.LastIndexOf("-") + k;

                            this.EvaluateOption(points[firstIndex], null, null, ref horizonalBest);
                        }
                        else
                        {
                            throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                        }

                        // If you have reached the last index already, start with the next row
                        if (firstIndex == lastIndex)
                            break;
                    }
                }
                // Exactly one occurance to choose from
                else if (firstIndex == lastIndex && firstIndex != -1)
                {
                    // Evaluate the option solution
                    if (temp is ThreeFielder)
                    {
                        firstIndex = rowString.IndexOf("---");
                        lastIndex = rowString.LastIndexOf("---");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref horizonalBest);
                    }
                    else if (temp is TwoFielder)
                    {
                        firstIndex = rowString.IndexOf("--");
                        lastIndex = rowString.LastIndexOf("--");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], null, ref horizonalBest);
                    }
                    else if (temp is OneFielder)
                    {
                        firstIndex = rowString.IndexOf("-");
                        lastIndex = rowString.LastIndexOf("-");

                        this.EvaluateOption(points[firstIndex], null, null, ref horizonalBest);
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }
                }
                // Not suitable 
                else
                {
                    // No action
                }
            }

            return horizonalBest;
        }

        /// <summary>
        /// Finds the best possible solution consisting from 3, 2 or 1 field(s) in the vertical direction.
        /// The best possible is equal to a solution close to the center of the playground.
        /// </summary>
        /// <returns></returns>
        private List<T> FindBestVerically<T>() where T : IFielder, new()
        {
            List<Point> points = new List<Point>();

            List<T> verticalBest = new List<T>();

            // Scan vertically for 1,2 or 3 empty fields (build string, make point list)
            for (int i = 0; i < this.columnsSize; i++)                        // columns
            {
                StringBuilder sbColumn = new StringBuilder(this.rowsSize);
                points.Clear();
                for (int j = 0; j < this.rowsSize; j++)                       // rows
                {
                    sbColumn.Append(this.playground[j][i]);
                    points.Add(new Point(j, i));
                }
                // Scanner vertical line
                string columnString = sbColumn.ToString();
                string columnStringOriginal = sbColumn.ToString();

                // Option solution indexes                
                int firstIndex = -1;
                int lastIndex = -1;
                int stopIndex = -1;

                T temp = new T();
                if (temp is ThreeFielder)
                {
                    firstIndex = columnString.IndexOf("---");
                    lastIndex = columnString.LastIndexOf("---");
                    stopIndex = 2;
                }
                else if (temp is TwoFielder)
                {
                    firstIndex = columnString.IndexOf("--");
                    lastIndex = columnString.LastIndexOf("--");
                    stopIndex = 1;
                }
                else if (temp is OneFielder)
                {
                    firstIndex = columnString.IndexOf("-");
                    lastIndex = columnString.LastIndexOf("-");
                    stopIndex = 0;
                }
                else
                {
                    throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                }

                // More than one option to choose from
                if (firstIndex != lastIndex && firstIndex != -1)
                {
                    int columnStringOriginalLength = columnStringOriginal.Length;

                    for (int k = 0; k < columnStringOriginalLength - stopIndex; k++)
                    {
                        columnString = columnStringOriginal.Substring(k);

                        // Re-Calculate option solution indexes & Evaluate option solution
                        if (temp is ThreeFielder)
                        {
                            firstIndex = columnString.IndexOf("---") + k;
                            lastIndex = columnString.LastIndexOf("---") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref verticalBest);
                        }
                        else if (temp is TwoFielder)
                        {
                            firstIndex = columnString.IndexOf("--") + k;
                            lastIndex = columnString.LastIndexOf("--") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], null, ref verticalBest);
                        }
                        else if (temp is OneFielder)
                        {
                            firstIndex = columnString.IndexOf("-") + k;
                            lastIndex = columnString.LastIndexOf("-") + k;

                            this.EvaluateOption(points[firstIndex], null, null, ref verticalBest);
                        }
                        else
                        {
                            throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                        }

                        // If you have reached the last index already, start with the next row
                        if (firstIndex == lastIndex)
                            break;
                    }
                }
                // Exactly one occurance to choose from
                else if (firstIndex == lastIndex && firstIndex != -1)
                {
                    // Evaluate the option solution
                    if (temp is ThreeFielder)
                    {
                        firstIndex = columnString.IndexOf("---");
                        lastIndex = columnString.LastIndexOf("---");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref verticalBest);
                    }
                    else if (temp is TwoFielder)
                    {
                        firstIndex = columnString.IndexOf("--");
                        lastIndex = columnString.LastIndexOf("--");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], null, ref verticalBest);
                    }
                    else if (temp is OneFielder)
                    {
                        firstIndex = columnString.IndexOf("-");
                        lastIndex = columnString.LastIndexOf("-");

                        this.EvaluateOption(points[firstIndex], null, null, ref verticalBest);
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }
                }
                // Not suitable 
                else
                {
                    // No action
                }
            }

            return verticalBest;
        }

        /// <summary>
        /// Finds the best possible solution consisting from 3, 2 or 1 field(s) in the diagonal direction.
        /// The best possible is equal to a solution close to the center of the playground.
        /// </summary>
        /// <returns></returns>
        private List<T> FindBestDiagonally<T>() where T : IFielder, new()
        {
            List<Point> points = new List<Point>();

            List<T> diagonalBest = new List<T>();

            // Scan diagonally for 1,2 or 3 empty fields (build string, make point list)
            for (int i = 0; i < this.rowsSize + this.columnsSize - 1; ++i)  // rows + columns - 1 
            {
                StringBuilder sbDiagonal1 = new StringBuilder();
                int z1 = i < this.columnsSize ? 0 : i - this.columnsSize + 1; // how many items should be skipped at the end, again starting at zero for the first row slices
                int z2 = i < this.rowsSize ? 0 : i - this.rowsSize + 1;       // how many items must be skipped before the first number should be printed
                points.Clear();
                for (int j = i - z2; j >= z1; --j)                         //vary
                {
                    sbDiagonal1.Append(this.playground[j][i - j]);
                    points.Add(new Point(j, i - j));
                }
                string diagonalString = sbDiagonal1.ToString();
                string diagonalStringOriginal = sbDiagonal1.ToString();
                
                // Option solution indexes                
                int firstIndex = -1;
                int lastIndex = -1;
                int stopIndex = -1;

                T temp = new T();
                if (temp is ThreeFielder)
                {
                    firstIndex = diagonalString.IndexOf("---");
                    lastIndex = diagonalString.LastIndexOf("---");
                    stopIndex = 2;
                }
                else if (temp is TwoFielder)
                {
                    firstIndex = diagonalString.IndexOf("--");
                    lastIndex = diagonalString.LastIndexOf("--");
                    stopIndex = 1;
                }
                else if (temp is OneFielder)
                {
                    firstIndex = diagonalString.IndexOf("-");
                    lastIndex = diagonalString.LastIndexOf("-");
                    stopIndex = 0;
                }
                else
                {
                    throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                }

                // More than one option to choose from
                if (firstIndex != lastIndex && firstIndex != -1)
                {
                    int rowStringOriginalLength = diagonalStringOriginal.Length;

                    for (int k = 0; k < rowStringOriginalLength - stopIndex; k++)
                    {
                        diagonalString = diagonalStringOriginal.Substring(k);

                        // Re-Calculate option solution indexes & Evaluate option solution
                        if (temp is ThreeFielder)
                        {
                            firstIndex = diagonalString.IndexOf("---") + k;
                            lastIndex = diagonalString.LastIndexOf("---") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref diagonalBest);
                        }
                        else if (temp is TwoFielder)
                        {
                            firstIndex = diagonalString.IndexOf("--") + k;
                            lastIndex = diagonalString.LastIndexOf("--") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], new Point(), ref diagonalBest);
                        }
                        else if (temp is OneFielder)
                        {
                            firstIndex = diagonalString.IndexOf("-") + k;
                            lastIndex = diagonalString.LastIndexOf("-") + k;

                            this.EvaluateOption(points[firstIndex], new Point(), new Point(), ref diagonalBest);
                        }
                        else
                        {
                            throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                        }

                        // If you have reached the last index already, start with the next row
                        if (firstIndex == lastIndex)
                            break;
                    }
                }
                // Exactly one occurance to choose from
                else if (firstIndex == lastIndex && firstIndex != -1)
                {
                    // Evaluate the option solution
                    if (temp is ThreeFielder)
                    {
                        firstIndex = diagonalString.IndexOf("---");
                        lastIndex = diagonalString.LastIndexOf("---");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref diagonalBest);
                    }
                    else if (temp is TwoFielder)
                    {
                        firstIndex = diagonalString.IndexOf("--");
                        lastIndex = diagonalString.LastIndexOf("--");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], new Point(), ref diagonalBest);
                    }
                    else if (temp is OneFielder)
                    {
                        firstIndex = diagonalString.IndexOf("-");
                        lastIndex = diagonalString.LastIndexOf("-");

                        this.EvaluateOption(points[firstIndex], new Point(), new Point(), ref diagonalBest);
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }
                }
                // Not suitable 
                else
                {
                    // No action
                }
            }

            return diagonalBest;
        }

        /// <summary>
        /// Finds the best possible solution consisting from 3, 2 or 1 field(s) in the reverse diagonal direction.
        /// The best possible is equal to a solution close to the center of the playground.
        /// </summary>
        /// <returns></returns>
        private List<T> FindBestRevDiagonally<T>() where T : IFielder, new()
        {
            List<Point> points = new List<Point>();

            List<T> horizonalBest = new List<T>();

            // Scan reverse diagonally for 1,2 or 3 empty fields (build string, make point list)
            for (int i = 0; i < this.rowsSize + this.columnsSize - 1; ++i)  // rows + columns - 1 
            {
                StringBuilder sbDiagonal2 = new StringBuilder();
                int z1 = i < this.columnsSize ? 0 : i - this.columnsSize + 1;
                int z2 = i < this.rowsSize ? 0 : i - this.rowsSize + 1;
                points.Clear();
                for (int j = i - z2; j >= z1; --j)
                {
                    sbDiagonal2.Append(this.playground[this.rowsSize - j - 1][i - j]);
                    points.Add(new Point(this.rowsSize - j - 1, i - j));
                }
                string revDiagonalString = sbDiagonal2.ToString();
                string revDiagonalStringOriginal = sbDiagonal2.ToString();

                // Option solution indexes                
                int firstIndex = -1;
                int lastIndex = -1;
                int stopIndex = -1;

                T temp = new T();
                if (temp is ThreeFielder)
                {
                    firstIndex = revDiagonalString.IndexOf("---"); 
                    lastIndex = revDiagonalString.LastIndexOf("---");
                    stopIndex = 2;
                }
                else if (temp is TwoFielder)
                {
                    firstIndex = revDiagonalString.IndexOf("--");
                    lastIndex = revDiagonalString.LastIndexOf("--");
                    stopIndex = 1;
                }
                else if (temp is OneFielder)
                {
                    firstIndex = revDiagonalString.IndexOf("-");
                    lastIndex = revDiagonalString.LastIndexOf("-");
                    stopIndex = 0;
                }
                else
                {
                    throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                }

                // More than one option to choose from
                if (firstIndex != lastIndex && firstIndex != -1)
                {
                    int rowStringOriginalLength = revDiagonalStringOriginal.Length;

                    for (int k = 0; k < rowStringOriginalLength - stopIndex; k++)
                    {
                        revDiagonalString = revDiagonalStringOriginal.Substring(k);

                        // Re-Calculate option solution indexes & Evaluate option solution
                        if (temp is ThreeFielder)
                        {
                            firstIndex = revDiagonalString.IndexOf("---") + k;
                            lastIndex = revDiagonalString.LastIndexOf("---") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref horizonalBest);
                        }
                        else if (temp is TwoFielder)
                        {
                            firstIndex = revDiagonalString.IndexOf("--") + k;
                            lastIndex = revDiagonalString.LastIndexOf("--") + k;

                            this.EvaluateOption(points[firstIndex], points[firstIndex + 1], new Point(), ref horizonalBest);
                        }
                        else if (temp is OneFielder)
                        {
                            firstIndex = revDiagonalString.IndexOf("-") + k;
                            lastIndex = revDiagonalString.LastIndexOf("-") + k;

                            this.EvaluateOption(points[firstIndex], new Point(), new Point(), ref horizonalBest);
                        }
                        else
                        {
                            throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                        }

                        // If you have reached the last index already, start with the next row
                        if (firstIndex == lastIndex)
                            break;
                    }
                }
                // Exactly one occurance to choose from
                else if (firstIndex == lastIndex && firstIndex != -1)
                {
                    // Evaluate the option solution
                    if (temp is ThreeFielder)
                    {
                        firstIndex = revDiagonalString.IndexOf("---");
                        lastIndex = revDiagonalString.LastIndexOf("---");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], points[firstIndex + 2], ref horizonalBest);
                    }
                    else if (temp is TwoFielder)
                    {
                        firstIndex = revDiagonalString.IndexOf("--");
                        lastIndex = revDiagonalString.LastIndexOf("--");

                        this.EvaluateOption(points[firstIndex], points[firstIndex + 1], new Point(), ref horizonalBest);
                    }
                    else if (temp is OneFielder)
                    {
                        firstIndex = revDiagonalString.IndexOf("-");
                        lastIndex = revDiagonalString.LastIndexOf("-");

                        this.EvaluateOption(points[firstIndex], new Point(), new Point(), ref horizonalBest);
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }
                }
                // Not suitable 
                else
                {
                    // No action
                }
            }

            return horizonalBest;
        }

        /// <summary>
        /// Evaluates suggested option for solution and adds it to the best solutions list if it is capable.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="horizonalBest"></param>
        private void EvaluateOption<T>(Point a, Point b, Point c, ref List<T> horizonalBest) where T : IFielder, new ()
        {
            T temp = new T();

            // Calculate the median index of an option solution
            double tempMedianIndex = this.CalculateMedianIndex(a, b, c);

            // There are already seleceted and evaluated option solutions
            if (horizonalBest.Count > 0)
            {
                // Better option solution was found
                if (horizonalBest[0].MedianIndex > tempMedianIndex)
                {
                    horizonalBest.Clear();

                    if (horizonalBest is List<ThreeFielder>)
                    {
                        (horizonalBest as List<ThreeFielder>).Add(new ThreeFielder(a, b, c, tempMedianIndex));  
                    }
                    else if (temp is TwoFielder)
                    {
                        (horizonalBest as List<TwoFielder>).Add(new TwoFielder(a, b, tempMedianIndex));  
                    }
                    else if (temp is OneFielder)
                    {
                        (horizonalBest as List<OneFielder>).Add(new OneFielder(a, tempMedianIndex));     
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }                    
                }
                // Equal option solution was found
                else if (horizonalBest[0].MedianIndex == tempMedianIndex)
                {
                    if (horizonalBest is List<ThreeFielder>)
                    {
                        (horizonalBest as List<ThreeFielder>).Add(new ThreeFielder(a, b, c, tempMedianIndex));
                    }
                    else if (temp is TwoFielder)
                    {
                        (horizonalBest as List<TwoFielder>).Add(new TwoFielder(a, b, tempMedianIndex));
                    }
                    else if (temp is OneFielder)
                    {
                        (horizonalBest as List<OneFielder>).Add(new OneFielder(a, tempMedianIndex));
                    }
                    else
                    {
                        throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                    }

                }
                // Worse option solution was found
                else
                {
                    // Discard this option solution
                }
            }
            // This is the first option solution found
            else
            {
                if (horizonalBest is List<ThreeFielder>)
                {
                    (horizonalBest as List<ThreeFielder>).Add(new ThreeFielder(a, b, c, tempMedianIndex));
                }
                else if (temp is TwoFielder)
                {
                    (horizonalBest as List<TwoFielder>).Add(new TwoFielder(a, b, tempMedianIndex));
                }
                else if (temp is OneFielder)
                {
                    (horizonalBest as List<OneFielder>).Add(new OneFielder(a, tempMedianIndex));
                }
                else
                {
                    throw new Exception(string.Format("Unexpected type: '{0}'", temp.GetType()));
                }

            }
        }
        #endregion

        #region Printing / Utility
        /// <summary>
        /// Prints the array (the playground).
        /// </summary>
        private void PrintArray(char[][] array)
        {
            Debug.WriteLine("Debug Print of Array started...");
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j < array[i].Length; j++)
                {
                    Console.Write(array[i][j]);
                }
                Console.WriteLine(string.Empty);
            }
            Debug.WriteLine("Debug Print of Array finished...");
        }

        /// <summary>
        /// Prints single char to the console.
        /// </summary>
        /// <param name="ch"></param>
        private void PrintChar(char ch)
        {
            Console.WriteLine(ch);
        }

        /// <summary>
        /// Copy the data from one array[][] to another array[][].
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        private void CopyData(char[][] from, char[][] to)
        {
            //Array.Copy(from, to, from.Length); <-- Shallow copy..

            for (int i = 0; i < from.Length; i++)
            {
                for (int j = 0; j < from[i].Length; j++)
                {
                    to[i][j] = from[i][j];
                }
            }
        }
        #endregion

        #region Events Helper Methods
        #region Report Error
        /// <summary>
        /// Subscribes to the event 'ReportError'.
        /// </summary>
        public void SubscribeReportError(ErrorMessageEventHandler listener)
        {
            this.ReportError += listener;
        }

        /// <summary>
        /// Fires the event 'ReportError'.
        /// </summary>
        public void FireReportError(string message) // == OnReportError()
        {
            Debug.WriteLine(string.Format("{0}:{1}", ERROR, message));
            ReportError(this, new ErrorEventArgs(string.Format("{0}:{1}", ERROR, message)));
        }

        public void FireReportCriticalError(string message) // == OnReportError()
        {
            Debug.WriteLine(string.Format("{0}", message));
            ReportError(this, new ErrorEventArgs(string.Format("{0}", message)));
        }

        /// <summary>
        /// Unsubscribes from the event 'ReportError'.
        /// </summary>
        public void UnsubscribeReportError(ErrorMessageEventHandler listener)
        {
            this.ReportError -= listener;
        }
        #endregion

        #region Report Playground
        /// <summary>
        /// Subscribes to the event 'ReportPlayground'.
        /// </summary>
        public void SubscribeReportPlayground(PlaygroundMessageEventHandler listener)
        {
            this.ReportPlayground += listener;
        }

        /// <summary>
        /// Fires the event 'ReportPlayground'.
        /// </summary>
        public void FireReportPlayground(char[][] playground) // == OnReportPlayground()
        {
            Debug.WriteLine(string.Format("Playground sent."));
            ReportPlayground(this, new PlaygroundEventArgs(playground));
        }

        /// <summary>
        /// Unsubscribes from the event 'ReportPlayground'.
        /// </summary>
        public void UnsubscribeReportPlayground(PlaygroundMessageEventHandler listener)
        {
            this.ReportPlayground -= listener;
        }
        #endregion

        #region Report Info
        /// <summary>
        /// Subscribes to the event 'ReportInfo'.
        /// </summary>
        public void SubscribeReportInfo(InfoMessageEventHandler listener)
        {
            this.ReportInfo += listener;
        }

        /// <summary>
        /// Fires the event 'ReportInfo'.
        /// </summary>
        public void FireReportInfo(string message) // == OnReportInfo()
        {
            Debug.WriteLine(string.Format("{0}:{1}", INFO, message));
            this.ReportInfo(this, new InfoEventArgs(string.Format("{0}:{1}", INFO, message)));
        }

        /// <summary>
        /// Fires the event 'ReportInfo'.
        /// </summary>
        public void FireReportDebugInfo(string message) // == OnReportInfo()
        {
            Debug.WriteLine(string.Format("{0}:{1}", DEBUG_INFO, message));
            this.ReportInfo(this, new InfoEventArgs(string.Format("{0}:{1}", DEBUG_INFO, message)));
        }

        /// <summary>
        /// Unsubscribes from the event 'ReportInfo'.
        /// </summary>
        public void UnsubscribeReportInfo(InfoMessageEventHandler listener)
        {
            this.ReportInfo -= listener;
        }
        #endregion
        #endregion
    }
}
