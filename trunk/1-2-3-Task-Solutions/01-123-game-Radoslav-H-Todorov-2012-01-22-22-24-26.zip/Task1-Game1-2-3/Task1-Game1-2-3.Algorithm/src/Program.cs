﻿/**********************************************************************************
    File:        Program.cs
    Descritpion: Console start of the '1-2-3 Game'
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/


using System.Diagnostics;

namespace Task1_Game1_2_3.Algorithm
{
    static class Program
    {
        static void Main(string[] args)
        {
            Debug.WriteLine("Program started...");

            new Game();

            Debug.WriteLine("Program finished.");
        }
    }
}
