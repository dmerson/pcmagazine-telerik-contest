﻿/**********************************************************************************
    File:        TestCases.cs
    Descritpion: Repository of example test case strings
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;

public static class TestCases
{
    public static string test1 = "3 3\r\n---\r\n---\r\n---\r\nA\r\nAAA\r\n---\r\n---\r\nAAA\r\nBBB\r\n---\r\nAAA\r\nBBB\r\nAAA\r\n"
                                                                + "BBB\r\n---\r\n---\r\nBBB\r\nAAA\r\n---\r\nBBB\r\nAAA\r\nBBB\r\n";
}