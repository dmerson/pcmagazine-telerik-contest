﻿/**********************************************************************************
    File:        MainForm.cs
    Descritpion: Simulator of the '1-2-3 Game'
 
    Name:        Radoslav H Todorov
    E-mail:      roosterchief@gmail.com
    
    Version:     1.0.0.0
    Date:        21-Jan-2012
 
    Licence:     Apache License
 **********************************************************************************/
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ComponentModel;
using Task1_Game1_2_3.Algorithm;
using Task1_Game1_2_3.Algorithm.Delegates;
using Task1_Game1_2_3.Algorithm.EventsArgs;

namespace Task1_Game1_2_3.Simulator
{
    /// <summary>
    /// UI of the '1-2-3' Game Simulator.
    /// </summary>
    public partial class MainForm : Form // Consumer of the events
    {
        #region Simulator Settings
        private static readonly string HEADING = "Game 1-2-3 (Simulator)";
        private static readonly char DISPLAY_NEUTRAL_CHAR = '\u2014';
        #endregion

        #region Fields
        private bool isSimulating = false;
        private Game game = null;
        #endregion

        #region Constructor & Initializing methods
        /// <summary>
        /// Constructor of the form.
        /// </summary>
        public MainForm()
        {
            this.InitializeComponent();

            this.Initialize();
        }

        /// <summary>
        /// Additional initialization method.
        /// </summary>
        private void Initialize()
        {
            this.lbAlgoPlayerA.SelectedIndex = 0;
            this.lbAlgoPlayerB.SelectedIndex = 0;
        }
        #endregion

        #region Event Handlers
        private void btnNextStep_Click(object sender, EventArgs e)
        {
            if (!this.isSimulating)
            {
                this.isSimulating = true;

                // Setup algorithms
                List<string> algoPlayerA = new List<string>();
                foreach (var item in this.lbAlgoPlayerA.SelectedItems)
                    algoPlayerA.Add(item as string);


                List<string> algoPlayerB = new List<string>();
                foreach (var item in this.lbAlgoPlayerB.SelectedItems)
                    algoPlayerB.Add(item as string);           

                // Setup game
                this.game = new Game((int)this.numericUpRows.Value, (int)this.numUpDownColumns.Value, algoPlayerA, algoPlayerB);
                this.game.SubscribeReportError(new ErrorMessageEventHandler(WhenErrorMessageIsReceived));
                this.game.SubscribeReportInfo(new InfoMessageEventHandler(WhenInfoMessageIsReceived));
                this.game.SubscribeReportPlayground(new PlaygroundMessageEventHandler(WhenPlaygroundMessageIsReceived));
            }

            this.game.PerformSingleCycleOnDemand();         
        }

        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            // Preview
            if (e.TabPageIndex == 1)
            {
                // Re-build playground 
                this.tbPlayground.Text = string.Empty;
                int rows = (int)this.numericUpRows.Value;
                int columns = (int)this.numUpDownColumns.Value;
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        this.tbPlayground.Text += DISPLAY_NEUTRAL_CHAR.ToString() + " ";  
                    }
                    this.tbPlayground.Text += Environment.NewLine;
                 }

                // Clean the last message if exists
                this.lblMessageInfo.Text = string.Empty;
                this.lblMessageDebugInfo.Text = string.Empty;
            }

            // Settings
            else if (e.TabPageIndex == 0)
            {
                if (this.isSimulating)
                {
                    DialogResult dr = MessageBox.Show(this, "Do you want to terminate the current simulation?", HEADING, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                    if (dr == System.Windows.Forms.DialogResult.Yes)
                    {
                        this.isSimulating = false;
                    }
                    else if (dr == System.Windows.Forms.DialogResult.No)
                    {
                        e.Cancel = true;
                    }
                }
            }
        }
       
        private void numericUpRows_Validating(object sender, CancelEventArgs e)
        {
            if (this.numericUpRows.Value < 3 || this.numericUpRows.Value > 20)
                e.Cancel = true;
        }

        private void numUpDownColumns_Validating(object sender, CancelEventArgs e)
        {
            if (this.numUpDownColumns.Value < 3 || this.numUpDownColumns.Value > 20)
                e.Cancel = true;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.isSimulating)
            {
                DialogResult dr = MessageBox.Show(this, "Do you want to terminate the current simulation?", HEADING, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (dr == System.Windows.Forms.DialogResult.Yes)
                {
                    this.isSimulating = false;
                }
                else if (dr == System.Windows.Forms.DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }
        #endregion

        #region Event Method Hanlders - Game
        /// <summary>
        /// When an error happens in the 'game' object.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WhenErrorMessageIsReceived(object sender, ErrorEventArgs e)
        {
            this.isSimulating = false;

            this.game.UnsubscribeReportInfo(new InfoMessageEventHandler(WhenInfoMessageIsReceived));
            this.game.UnsubscribeReportPlayground(new PlaygroundMessageEventHandler(WhenPlaygroundMessageIsReceived));
            this.game.UnsubscribeReportError(new ErrorMessageEventHandler(WhenErrorMessageIsReceived));

            if (e.Message.Contains(Game.ERROR))
            {
                // Discard none-critical errors ...
            }
            else
            {
                this.lblMessageInfo.Text = e.Message;
                this.lblMessageDebugInfo.Text = string.Empty;
            }
        }

        /// <summary>
        /// When an info message happens in the 'game' object.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WhenInfoMessageIsReceived(object sender, InfoEventArgs e)
        {
            if (e.Message.Contains(Game.DEBUG_INFO))
            {
                this.lblMessageDebugInfo.Text = e.Message.Substring(e.Message.IndexOf(":")+1);
            }
            else if (e.Message.Contains(Game.INFO)) 
            {
                this.lblMessageInfo.Text = e.Message.Substring(e.Message.IndexOf(":")+1);
            }            
        }

        /// <summary>
        /// When a new playground is available in the 'game' object.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WhenPlaygroundMessageIsReceived(object sender, PlaygroundEventArgs e)
        {
            char[][] playground = e.Playground;
            this.tbPlayground.Text = string.Empty;
            for (int i = 0; i < playground.Length; i++)
            {
                for (int j = 0; j < playground[i].Length; j++)
                {
                    this.tbPlayground.Text += ((playground[i][j]  == Game.NEUTRAL_CHAR) 
                        ? DISPLAY_NEUTRAL_CHAR.ToString() : playground[i][j].ToString()) + " ";
                }
                this.tbPlayground.Text += Environment.NewLine;
            }
        } 
        #endregion
    }
}
