﻿namespace Task1_Game1_2_3.Simulator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageSettungs = new System.Windows.Forms.TabPage();
            this.grpAlgoLoaded = new System.Windows.Forms.GroupBox();
            this.lbAlgoPlayerB = new System.Windows.Forms.ListBox();
            this.lbAlgoPlayerA = new System.Windows.Forms.ListBox();
            this.lblPlayerB = new System.Windows.Forms.Label();
            this.lblPlayerA = new System.Windows.Forms.Label();
            this.grpPlaygroundSettings = new System.Windows.Forms.GroupBox();
            this.numericUpRows = new System.Windows.Forms.NumericUpDown();
            this.lblRows = new System.Windows.Forms.Label();
            this.numUpDownColumns = new System.Windows.Forms.NumericUpDown();
            this.lblColumns = new System.Windows.Forms.Label();
            this.tabPagePreview = new System.Windows.Forms.TabPage();
            this.panelMessage2 = new System.Windows.Forms.Panel();
            this.lblMessageDebugInfo = new System.Windows.Forms.Label();
            this.panelMessages = new System.Windows.Forms.Panel();
            this.lblMessageInfo = new System.Windows.Forms.Label();
            this.btnNextStep = new System.Windows.Forms.Button();
            this.grpPlayground = new System.Windows.Forms.GroupBox();
            this.tbPlayground = new System.Windows.Forms.TextBox();
            this.tabControl.SuspendLayout();
            this.tabPageSettungs.SuspendLayout();
            this.grpAlgoLoaded.SuspendLayout();
            this.grpPlaygroundSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownColumns)).BeginInit();
            this.tabPagePreview.SuspendLayout();
            this.panelMessage2.SuspendLayout();
            this.panelMessages.SuspendLayout();
            this.grpPlayground.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageSettungs);
            this.tabControl.Controls.Add(this.tabPagePreview);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(298, 352);
            this.tabControl.TabIndex = 0;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // tabPageSettungs
            // 
            this.tabPageSettungs.Controls.Add(this.grpAlgoLoaded);
            this.tabPageSettungs.Controls.Add(this.grpPlaygroundSettings);
            this.tabPageSettungs.Location = new System.Drawing.Point(4, 22);
            this.tabPageSettungs.Name = "tabPageSettungs";
            this.tabPageSettungs.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSettungs.Size = new System.Drawing.Size(290, 326);
            this.tabPageSettungs.TabIndex = 0;
            this.tabPageSettungs.Text = "Settings";
            this.tabPageSettungs.UseVisualStyleBackColor = true;
            // 
            // grpAlgoLoaded
            // 
            this.grpAlgoLoaded.Controls.Add(this.lbAlgoPlayerB);
            this.grpAlgoLoaded.Controls.Add(this.lbAlgoPlayerA);
            this.grpAlgoLoaded.Controls.Add(this.lblPlayerB);
            this.grpAlgoLoaded.Controls.Add(this.lblPlayerA);
            this.grpAlgoLoaded.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpAlgoLoaded.Location = new System.Drawing.Point(3, 89);
            this.grpAlgoLoaded.Name = "grpAlgoLoaded";
            this.grpAlgoLoaded.Size = new System.Drawing.Size(284, 234);
            this.grpAlgoLoaded.TabIndex = 1;
            this.grpAlgoLoaded.TabStop = false;
            this.grpAlgoLoaded.Text = "Loaded Algorithms:";
            // 
            // lbAlgoPlayerB
            // 
            this.lbAlgoPlayerB.FormattingEnabled = true;
            this.lbAlgoPlayerB.Items.AddRange(new object[] {
            "Normal",
            "DiagonalsFirst"});
            this.lbAlgoPlayerB.Location = new System.Drawing.Point(144, 32);
            this.lbAlgoPlayerB.Name = "lbAlgoPlayerB";
            this.lbAlgoPlayerB.Size = new System.Drawing.Size(120, 186);
            this.lbAlgoPlayerB.TabIndex = 3;
            // 
            // lbAlgoPlayerA
            // 
            this.lbAlgoPlayerA.FormattingEnabled = true;
            this.lbAlgoPlayerA.Items.AddRange(new object[] {
            "Normal",
            "DiagonalsFirst"});
            this.lbAlgoPlayerA.Location = new System.Drawing.Point(18, 32);
            this.lbAlgoPlayerA.Name = "lbAlgoPlayerA";
            this.lbAlgoPlayerA.Size = new System.Drawing.Size(120, 186);
            this.lbAlgoPlayerA.TabIndex = 1;
            // 
            // lblPlayerB
            // 
            this.lblPlayerB.AutoSize = true;
            this.lblPlayerB.Location = new System.Drawing.Point(215, 16);
            this.lblPlayerB.Name = "lblPlayerB";
            this.lblPlayerB.Size = new System.Drawing.Size(49, 13);
            this.lblPlayerB.TabIndex = 2;
            this.lblPlayerB.Text = "Player B:";
            // 
            // lblPlayerA
            // 
            this.lblPlayerA.AutoSize = true;
            this.lblPlayerA.Location = new System.Drawing.Point(15, 16);
            this.lblPlayerA.Name = "lblPlayerA";
            this.lblPlayerA.Size = new System.Drawing.Size(49, 13);
            this.lblPlayerA.TabIndex = 0;
            this.lblPlayerA.Text = "Player A:";
            // 
            // grpPlaygroundSettings
            // 
            this.grpPlaygroundSettings.Controls.Add(this.numericUpRows);
            this.grpPlaygroundSettings.Controls.Add(this.lblRows);
            this.grpPlaygroundSettings.Controls.Add(this.numUpDownColumns);
            this.grpPlaygroundSettings.Controls.Add(this.lblColumns);
            this.grpPlaygroundSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpPlaygroundSettings.Location = new System.Drawing.Point(3, 3);
            this.grpPlaygroundSettings.Name = "grpPlaygroundSettings";
            this.grpPlaygroundSettings.Size = new System.Drawing.Size(284, 86);
            this.grpPlaygroundSettings.TabIndex = 0;
            this.grpPlaygroundSettings.TabStop = false;
            this.grpPlaygroundSettings.Text = "Playground settings:";
            // 
            // numericUpRows
            // 
            this.numericUpRows.BackColor = System.Drawing.Color.White;
            this.numericUpRows.Cursor = System.Windows.Forms.Cursors.Default;
            this.numericUpRows.Location = new System.Drawing.Point(144, 41);
            this.numericUpRows.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpRows.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpRows.Name = "numericUpRows";
            this.numericUpRows.Size = new System.Drawing.Size(44, 20);
            this.numericUpRows.TabIndex = 2;
            this.numericUpRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpRows.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpRows.Validating += new System.ComponentModel.CancelEventHandler(this.numericUpRows_Validating);
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.Location = new System.Drawing.Point(194, 43);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(46, 13);
            this.lblRows.TabIndex = 3;
            this.lblRows.Text = "<- Rows";
            // 
            // numUpDownColumns
            // 
            this.numUpDownColumns.BackColor = System.Drawing.Color.White;
            this.numUpDownColumns.Location = new System.Drawing.Point(94, 41);
            this.numUpDownColumns.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numUpDownColumns.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numUpDownColumns.Name = "numUpDownColumns";
            this.numUpDownColumns.Size = new System.Drawing.Size(44, 20);
            this.numUpDownColumns.TabIndex = 1;
            this.numUpDownColumns.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numUpDownColumns.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numUpDownColumns.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numUpDownColumns.Validating += new System.ComponentModel.CancelEventHandler(this.numUpDownColumns_Validating);
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.Location = new System.Drawing.Point(29, 43);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(59, 13);
            this.lblColumns.TabIndex = 0;
            this.lblColumns.Text = "Columns ->";
            // 
            // tabPagePreview
            // 
            this.tabPagePreview.Controls.Add(this.panelMessage2);
            this.tabPagePreview.Controls.Add(this.panelMessages);
            this.tabPagePreview.Controls.Add(this.btnNextStep);
            this.tabPagePreview.Controls.Add(this.grpPlayground);
            this.tabPagePreview.Location = new System.Drawing.Point(4, 22);
            this.tabPagePreview.Name = "tabPagePreview";
            this.tabPagePreview.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePreview.Size = new System.Drawing.Size(290, 326);
            this.tabPagePreview.TabIndex = 1;
            this.tabPagePreview.Text = "Preview";
            this.tabPagePreview.UseVisualStyleBackColor = true;
            // 
            // panelMessage2
            // 
            this.panelMessage2.BackColor = System.Drawing.Color.DarkGray;
            this.panelMessage2.Controls.Add(this.lblMessageDebugInfo);
            this.panelMessage2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMessage2.Location = new System.Drawing.Point(100, 289);
            this.panelMessage2.Name = "panelMessage2";
            this.panelMessage2.Size = new System.Drawing.Size(101, 34);
            this.panelMessage2.TabIndex = 3;
            // 
            // lblMessageDebugInfo
            // 
            this.lblMessageDebugInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMessageDebugInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessageDebugInfo.Location = new System.Drawing.Point(0, 0);
            this.lblMessageDebugInfo.Name = "lblMessageDebugInfo";
            this.lblMessageDebugInfo.Size = new System.Drawing.Size(101, 34);
            this.lblMessageDebugInfo.TabIndex = 0;
            // 
            // panelMessages
            // 
            this.panelMessages.Controls.Add(this.lblMessageInfo);
            this.panelMessages.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMessages.Location = new System.Drawing.Point(3, 289);
            this.panelMessages.Name = "panelMessages";
            this.panelMessages.Size = new System.Drawing.Size(97, 34);
            this.panelMessages.TabIndex = 2;
            // 
            // lblMessageInfo
            // 
            this.lblMessageInfo.BackColor = System.Drawing.Color.Silver;
            this.lblMessageInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMessageInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessageInfo.Location = new System.Drawing.Point(0, 0);
            this.lblMessageInfo.Name = "lblMessageInfo";
            this.lblMessageInfo.Size = new System.Drawing.Size(97, 34);
            this.lblMessageInfo.TabIndex = 0;
            // 
            // btnNextStep
            // 
            this.btnNextStep.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNextStep.Location = new System.Drawing.Point(207, 295);
            this.btnNextStep.Name = "btnNextStep";
            this.btnNextStep.Size = new System.Drawing.Size(75, 23);
            this.btnNextStep.TabIndex = 1;
            this.btnNextStep.Text = "Simulate!";
            this.btnNextStep.UseVisualStyleBackColor = true;
            this.btnNextStep.Click += new System.EventHandler(this.btnNextStep_Click);
            // 
            // grpPlayground
            // 
            this.grpPlayground.Controls.Add(this.tbPlayground);
            this.grpPlayground.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpPlayground.Location = new System.Drawing.Point(3, 3);
            this.grpPlayground.Name = "grpPlayground";
            this.grpPlayground.Padding = new System.Windows.Forms.Padding(12);
            this.grpPlayground.Size = new System.Drawing.Size(284, 286);
            this.grpPlayground.TabIndex = 0;
            this.grpPlayground.TabStop = false;
            this.grpPlayground.Text = "Playground:";
            // 
            // tbPlayground
            // 
            this.tbPlayground.BackColor = System.Drawing.Color.White;
            this.tbPlayground.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbPlayground.Location = new System.Drawing.Point(12, 25);
            this.tbPlayground.Multiline = true;
            this.tbPlayground.Name = "tbPlayground";
            this.tbPlayground.ReadOnly = true;
            this.tbPlayground.Size = new System.Drawing.Size(260, 249);
            this.tbPlayground.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 352);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game 1-2-3 (Simulator)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.tabControl.ResumeLayout(false);
            this.tabPageSettungs.ResumeLayout(false);
            this.grpAlgoLoaded.ResumeLayout(false);
            this.grpAlgoLoaded.PerformLayout();
            this.grpPlaygroundSettings.ResumeLayout(false);
            this.grpPlaygroundSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownColumns)).EndInit();
            this.tabPagePreview.ResumeLayout(false);
            this.panelMessage2.ResumeLayout(false);
            this.panelMessages.ResumeLayout(false);
            this.grpPlayground.ResumeLayout(false);
            this.grpPlayground.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageSettungs;
        private System.Windows.Forms.TabPage tabPagePreview;
        private System.Windows.Forms.GroupBox grpAlgoLoaded;
        private System.Windows.Forms.ListBox lbAlgoPlayerB;
        private System.Windows.Forms.ListBox lbAlgoPlayerA;
        private System.Windows.Forms.Label lblPlayerB;
        private System.Windows.Forms.Label lblPlayerA;
        private System.Windows.Forms.GroupBox grpPlaygroundSettings;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Label lblColumns;
        private System.Windows.Forms.GroupBox grpPlayground;
        private System.Windows.Forms.Button btnNextStep;
        private System.Windows.Forms.TextBox tbPlayground;
        private System.Windows.Forms.NumericUpDown numericUpRows;
        private System.Windows.Forms.NumericUpDown numUpDownColumns;
        private System.Windows.Forms.Panel panelMessages;
        private System.Windows.Forms.Label lblMessageInfo;
        private System.Windows.Forms.Panel panelMessage2;
        private System.Windows.Forms.Label lblMessageDebugInfo;
    }
}