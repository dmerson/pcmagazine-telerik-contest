﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game123_Console
{
    class Game123
    {
        static char[][] field;
        static char player;

        static void Main(string[] args)
        {
            if (Input())
            {
                if (player == 'A')
                {
                    Most();
                }
                else
                {
                    Least();
                }
                PrintField();
            }
        }

        static bool Input()
        {
            // used to find wrong input
            bool isError = false;
            string errorLog = "";

            // reads the size
            string input = Console.ReadLine();
            string[] numbersToString = input.Split(' ');

            // if the spaces are not 2, there is error
            if (numbersToString.Length != 2)
            {
                numbersToString = new string[] { "", "" };
                isError = true;
                errorLog += "N.01 - On line 1 there are more or less than 2 words.\t";
            }

            // Size of the field
            int[] size = new int[2];
            for (int i = 0; i < 2; i++)
            {
                if (!int.TryParse(numbersToString[i], out size[i])) // checks if the input is valid integer
                {
                    size = new int[] { 0, 0 };
                    isError = true;
                    errorLog += "N.02 - On line 1, the " + (i + 1) + " word is not integer.\t";
                    
                }
                if (size[i] < 3 || size[i] > 20)
                {
                    isError = true;
                    errorLog += "N.03 - On line 1, " + (i + 1) + " number is not in range [3, 20].\t";
                }
            }

            // game field
            field = new char[size[1]][];
            for (int i = 0; i < size[1]; i++)
            {
                input = Console.ReadLine();

                if (input.Length != size[0])
                {
                    isError = true;
                    errorLog += "N.04 - On line " + (i + 2) + " there are more or less symbols.\t";
                }
                else
                {
                    field[i] = input.ToCharArray();
                    foreach (char ch in field[i])
                    {
                        if (ch != '-' && ch != 'A' && ch != 'B')
                        {
                            isError = true;
                            errorLog += "N.05 - On line " + (i + 2) + " there are non-game symbols.\t";
                        }
                    }
                }
            }

            input = Console.ReadLine();
            if (input.Length > 1)
            {
                isError = true;
                errorLog += "N.06 - On last line there are more than 1 symbols.\t";
            }
            player = input.ElementAt(0);
            if (player != 'A' && player != 'B')
            {
                isError = true;
                errorLog += "N.07 - On last line there is invalid symbol.\t";
            }

            if (isError)
            {
                Console.WriteLine("error");
                Console.WriteLine(errorLog);
            }

            return !isError;
        }

        static void Most()
        {
            PlayerTurn(true);
        }

        static void Least()
        {
            PlayerTurn(false);
        }

        // r, c, l, d
        static int[] GetDirections(bool max)
        {
            int row = 0; // coordinates
            int col = 0;
            int l = -1; // lenght
            int dir = -1; // 0 - right, 1 - down, 2 - diag, 3 - obr diag
            int[,] point = new int[field.Length, field[0].Length];
            
            int val = max ? -1 : 10;

            // find three
            for (int r = 0; r < field.Length; r++)
            {
                for (int c = 0; c < field[0].Length; c++)
                {
                    if (field[r][c] == '-')
                    {
                        //counting
                        if (c < field[0].Length - 2 && field[r][c + 1] == '-' && field[r][c + 2] == '-')
                        {
                            point[r, c]++;
                            point[r, c + 1]++;
                            point[r, c + 2]++;
                        }
                        if (r < field.Length - 2 && field[r + 1][c] == '-' && field[r + 2][c] == '-')
                        {
                            point[r, c]++;
                            point[r + 1, c]++;
                            point[r + 2, c]++;
                        }
                        if (c < field[0].Length - 2 && r < field.Length - 2 && field[r + 1][c + 1] == '-' && field[r + 2][c + 2] == '-')
                        {
                            point[r, c]++;
                            point[r + 1, c + 1]++;
                            point[r + 2, c + 2]++;
                        }
                        if (c > 1 && r < field.Length - 2 && field[r + 1][c - 1] == '-' && field[r + 2][c - 2] == '-')
                        {
                            point[r, c]++;
                            point[r + 1, c - 1]++;
                            point[r + 2, c - 2]++;
                        }

                        // find max/min
                        int temp;
                        if (c > 1 && field[r][c - 1] == '-' && field[r][c - 2] == '-')
                        {
                            temp = point[r, c] + point[r, c - 1] + point[r, c - 2];
                            if ((temp > val) == max)
                            {
                                val = temp;
                                dir = 0;
                                row = r;
                                col = c - 2;
                                l = 3;
                            }
                        }

                        if (r > 1 && field[r - 1][c] == '-' && field[r - 2][c] == '-')
                        {
                            temp = point[r, c] + point[r - 1, c] + point[r - 2, c];
                            if ((temp > val) == max)
                            {
                                val = temp;
                                dir = 1;
                                row = r - 2;
                                col = c;
                                l = 3;
                            }
                        }

                        if (c > 1 && r > 1 && field[r - 1][c - 1] == '-' && field[r - 2][c - 2] == '-')
                        {
                            temp = point[r, c] + point[r - 1, c - 1] + point[r - 2, c - 2];
                            if ((temp > val) == max)
                            {
                                val = temp;
                                dir = 2;
                                row = r - 2;
                                col = c - 2;
                                l = 3;
                            }
                        }

                        if (r > 1 && c < field[0].Length - 2 && field[r - 1][c + 1] == '-' && field[r - 2][c + 2] == '-')
                        {
                            temp = point[r, c] + point[r - 1, c + 1] + point[r - 2, c + 2];
                            if ((temp > val) == max)
                            {
                                val = temp;
                                dir = 3;
                                row = r - 2;
                                col = c + 2;
                                l = 3;
                            }
                        }

                        if (r < 2 && c < 2)
                        {
                            if (c < field[0].Length - 2 && field[r][c + 1] == '-' && field[r][c + 2] == '-')
                            {
                                temp = point[r, c] + point[r, c + 1] + point[r, c + 2];
                                if ((temp > val) == max)
                                {
                                    val = temp;
                                    dir = 0;
                                    row = r;
                                    col = c;
                                    l = 3;
                                }
                            }
                            if (r < field.Length - 2 && field[r + 1][c] == '-' && field[r + 2][c] == '-')
                            {
                                temp = point[r, c] + point[r + 1, c] + point[r + 2, c];
                                if ((temp > val) == max)
                                {
                                    val = temp;
                                    dir = 1;
                                    row = r;
                                    col = c;
                                    l = 3;
                                }
                            }
                            if (r < field.Length - 2 && c < field[0].Length - 2 && field[r + 1][c + 1] == '-' && field[r + 2][c + 2] == '-')
                            {
                                temp = point[r, c] + point[r + 1, c + 1] + point[r + 2, c + 2];
                                if ((temp > val) == max)
                                {
                                    val = temp;
                                    dir = 2;
                                    row = r;
                                    col = c;
                                    l = 3;
                                }
                            }
                        }
                    }
                }
            }

            if (l == -1)
            {
                //find two
                for (int r = 0; r < field.Length; r++)
                {
                    for (int c = 0; c < field[0].Length; c++)
                    {
                        if (field[r][c] == '-')
                        {
                            //counting
                            if (c < field[0].Length - 1 && field[r][c + 1] == '-')
                            {
                                point[r, c]++;
                                point[r, c + 1]++;
                            }
                            if (r < field.Length - 1 && field[r + 1][c] == '-')
                            {
                                point[r, c]++;
                                point[r + 1, c]++;
                            }
                            if (c < field[0].Length - 1 && r < field.Length - 1 && field[r + 1][c + 1] == '-')
                            {
                                point[r, c]++;
                                point[r + 1, c + 1]++;
                            }
                            if (c > 0 && r < field.Length - 1 && field[r + 1][c - 1] == '-')
                            {
                                point[r, c]++;
                                point[r + 1, c - 1]++;
                            }
                            if (c < field[0].Length - 2 && field[r][c + 1] == player && field[r][c + 2] == '-')
                            {
                                point[r, c]++;
                                point[r, c + 2]++;
                            }
                            if (r < field.Length - 2 && field[r + 1][c] == player && field[r + 2][c] == '-')
                            {
                                point[r, c]++;
                                point[r + 2, c]++;
                            }
                            if (c < field[0].Length - 2 && r < field.Length - 2 && field[r + 1][c + 1] == player && field[r + 2][c + 2] == '-')
                            {
                                point[r, c]++;
                                point[r + 2, c + 2]++;
                            }
                            if (c > 1 && r < field.Length - 2 && field[r + 1][c - 1] == player && field[r + 2][c - 2] == '-')
                            {
                                point[r, c]++;
                                point[r + 2, c - 2]++;
                            }

                            //find max/min
                            int temp;
                            if (c > 0 && field[r][c - 1] == '-')
                            {
                                temp = point[r, c] + point[r, c - 1];
                                if ((temp > val) == max)
                                {
                                    l = 2;
                                    val = temp;
                                    dir = 0;
                                    row = r;
                                    col = c - 1;
                                }
                            }
                            if (r > 0 && field[r - 1][c] == '-')
                            {
                                temp = point[r, c] + point[r - 1, c];
                                if ((temp > val) == max)
                                {
                                    l = 2;
                                    val = temp;
                                    dir = 1;
                                    row = r - 1;
                                    col = c;
                                }
                            }
                            if (c > 0 && r > 0 && field[r - 1][c - 1] == '-')
                            {

                                temp = point[r, c] + point[r - 1, c - 1];
                                if ((temp > val) == max)
                                {
                                    l = 2;
                                    val = temp;
                                    dir = 2;
                                    row = r - 1;
                                    col = c - 1;
                                }
                            }
                            if (c < field[0].Length - 1 && r > 0 && field[r - 1][c + 1] == '-')
                            {

                                temp = point[r, c] + point[r - 1, c + 1];
                                if ((temp > val) == max)
                                {
                                    l = 2;
                                    val = temp;
                                    dir = 3;
                                    row = r - 1;
                                    col = c + 1;
                                }
                            }
                            if (c > 1 && field[r][c - 1] == player && field[r][c - 2] == '-')
                            {

                                temp = point[r, c] + point[r, c - 2];
                                if ((temp > val) == max)
                                {
                                    l = 3;
                                    val = temp;
                                    dir = 0;
                                    row = r;
                                    col = c - 2;
                                }
                            }
                            if (r > 1 && field[r - 1][c] == player && field[r - 2][c] == '-')
                            {

                                temp = point[r, c] + point[r - 2, c];
                                if ((temp > val) == max)
                                {
                                    l = 3;
                                    val = temp;
                                    dir = 1;
                                    row = r - 2;
                                    col = c;
                                }
                            }
                            if (c > 1 && r > 1 && field[r - 1][c - 1] == player && field[r - 2][c - 2] == '-')
                            {

                                temp = point[r, c] + point[r - 2, c - 2];
                                if ((temp > val) == max)
                                {
                                    l = 3;
                                    val = temp;
                                    dir = 2;
                                    row = r - 2;
                                    col = c - 2;
                                }
                            }
                            if (c < field[0].Length - 2 && r > 1 && field[r - 1][c + 1] == player && field[r - 2][c + 2] == '-')
                            {

                                temp = point[r, c] + point[r - 2, c + 2];
                                if ((temp > val) == max)
                                {
                                    l = 3;
                                    val = temp;
                                    dir = 3;
                                    row = r - 2;
                                    col = c + 2;
                                }
                            }
                        }
                    }
                }

                if (l == -1)
                {
                    // find one
                    for (int r = 0; r < field.GetLength(0); r++)
                    {
                        for (int c = 0; c < field.GetLength(1); c++)
                        {
                            if (field[r][c] == '-')
                            {
                                l = 1;
                                row = r;
                                col = c;
                                dir = 0;
                                break;
                            }
                        }
                    }
                }
            }

            return new int[] { row, col, l, dir };
        }

        static void PlayerTurn(bool max)
        {
            int[] dir = GetDirections(max);

            if (dir[3] == 0)
            {
                for (int i = 0; i < dir[2]; i++)
                {
                    field[dir[0]][dir[1] + i] = player;
                }
            }
            else if (dir[3] == 1)
            {
                for (int i = 0; i < dir[2]; i++)
                {
                    field[dir[0] + i][dir[1]] = player;
                }
            }
            else if (dir[3] == 2)
            {
                for (int i = 0; i < dir[2]; i++)
                {
                    field[dir[0] + i][dir[1] + i] = player;
                }
            }
            else if (dir[3] == 3)
            {
                for (int i = 0; i < dir[2]; i++)
                {
                    field[dir[0] + i][dir[1] - i] = player;
                }
            }
        }

        static void PrintField()
        {
            for (int r = 0; r < field.Length; r++)
            {
                for (int c = 0; c < field[0].Length; c++)
                {
                    Console.Write(field[r][c]);
                }
                Console.WriteLine();
            }
        }
    }
}
