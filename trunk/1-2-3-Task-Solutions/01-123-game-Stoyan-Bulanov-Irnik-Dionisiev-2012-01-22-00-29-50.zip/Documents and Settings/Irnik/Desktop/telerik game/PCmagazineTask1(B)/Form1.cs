﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
namespace PCmagazineTask1_B_
{
    public partial class theForm : Form
    {

        OpenFileDialog Bot1 = new OpenFileDialog();
        OpenFileDialog Bot2 = new OpenFileDialog();
        char yourWord = 'A';



        public theForm()
        {
            InitializeComponent();
        }


        private void customize1_Click(object sender, EventArgs e)
        {
            Bot1.Title = "Chose the first bot";
            Bot1.InitialDirectory = @"c:\";
            Bot1.Filter = "Applications (*.exe)|*.exe";
            Bot1.FilterIndex = 2;
            Bot1.Multiselect = false;
            Bot1.RestoreDirectory = true;
            if (Bot1.ShowDialog() == DialogResult.OK)
            {
                string fileName = Bot1.FileName;
                fileName = fileName.Split(Path.DirectorySeparatorChar)[fileName.Split(Path.DirectorySeparatorChar).Length - 1];
                fileName = fileName.Remove(fileName.Length - 4);
                if (fileName.Length > 18)
                {
                    name1.Text = "Player A: " + fileName.Remove(16) + " . . .";
                }
                else
                    name1.Text = "Player A: " + fileName;
                score1.ResetText();
                Print("Player A is chosen, his name is " + fileName + "." + System.Environment.NewLine);
            }
        }

        private void customize2_Click(object sender, EventArgs e)
        {
            Bot2.Title = "Chose the second bot";
            Bot2.InitialDirectory = @"c:\";
            Bot2.Filter = "Applications (*.exe)|*.exe";
            Bot2.FilterIndex = 2;
            Bot2.Multiselect = false;
            Bot2.RestoreDirectory = true;
            if (Bot2.ShowDialog() == DialogResult.OK)
            {
                string fileName = Bot2.FileName;
                fileName = fileName.Split(Path.DirectorySeparatorChar)[fileName.Split(Path.DirectorySeparatorChar).Length - 1];
                fileName = fileName.Remove(fileName.Length - 4);
                if (fileName.Length > 18)
                {
                    name2.Text = "Player B: " + fileName.Remove(16) + " . . .";
                }
                else
                    name2.Text = "Player B: " + fileName;
                score2.ResetText();
                Print("Player B is chosen, his name is " + fileName + "." + System.Environment.NewLine);
            }
        }
        string appPath = Path.GetDirectoryName(Application.ExecutablePath);
       
        private void mChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            TableCheck();
        }

        private void nChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            TableCheck();
        }
        private void PlayerAFirst_Click(object sender, EventArgs e)
        {
            yourWord = 'A';
        }

        private void PlayerBFirst_Click(object sender, EventArgs e)
        {
            yourWord = 'B';
        }

        private void start_Click(object sender, EventArgs e)
        {
            if (File.Exists(Bot1.FileName)&&File.Exists(Bot2.FileName))
            {
                start.Visible = false;
                customize1.Enabled = false;
                customize2.Enabled = false;
                mChoice.Enabled = false;
                nChoice.Enabled = false;
                PlayerAFirst.Enabled = false;
                PlayerBFirst.Enabled = false;
                
            }
            else
            {
                Print("Choose both players' programs and then we shell start." + System.Environment.NewLine);
                
            }
        }
        void Print(string print)
        {
            Dialog.AppendText(print);
        }

        private void next_Click(object sender, EventArgs e)
        {

            char[,] table = Table.Board;
            Stopwatch watch = new Stopwatch();
            if (File.Exists(Bot1.FileName) && File.Exists(Bot2.FileName))
            {
                ProcessStartInfo BotLunching = new ProcessStartInfo();
                if (yourWord=='A')
                {
                    BotLunching.FileName = Bot1.FileName;
                }
                if (yourWord=='B')
                {
                    BotLunching.FileName = Bot2.FileName;
                }
                BotLunching.CreateNoWindow = true;
                BotLunching.RedirectStandardOutput = true;
                BotLunching.UseShellExecute = false;
                System.Diagnostics.Process listFiles;
                listFiles = System.Diagnostics.Process.Start(BotLunching);
                BotLunching.Arguments = Table.Rows + ' ' + Table.Columns + System.Environment.NewLine + table + System.Environment.NewLine + yourWord;
                System.IO.StreamReader myOutput = listFiles.StandardOutput;
                listFiles.WaitForExit(1000);
                if (listFiles.HasExited)
                {
                    char[] output = myOutput.ReadToEnd().ToCharArray();
                    int problem = 0,freeSpaceExist=0;
                    for (int i = 0; i < Table.Columns; i++)
                    {
                        for (int j = 0; j < Table.Rows; j++)
                        {
                            try
                            {
                                if (output[i * Table.Rows + j] == 'A' || output[i * Table.Rows + j] == 'B')
                                    table[i, j] = output[i * Table.Rows + j];
                                else if(output[i * Table.Rows + j] == '-')
                                {
                                    freeSpaceExist++;
                                    table[i, j] = output[i * Table.Rows + j];
                                }
                                else
                                    problem++;
                            }
                            catch
                            {
                                problem++;
                            }
                        }
                    }
                    if (output.Length > Table.Columns * Table.Rows || problem != 0||!IsThisMoveLegal(table))
                    {
                        Print("The output is not correct, the other player take this score." + System.Environment.NewLine);
                        Table.InitializeBoard();
                        start.Visible = true;
                        customize1.Enabled = true;
                        customize2.Enabled = true;
                        mChoice.Enabled = true;
                        nChoice.Enabled = true;
                        PlayerAFirst.Enabled = true;
                        PlayerBFirst.Enabled = true;
                        if (yourWord == 'A')
                        {
                            score2.Text = "Score: " + Convert.ToString(Convert.ToInt32(score2.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                        }
                        if (yourWord == 'B')
                        {
                            score1.Text = "Score: " + Convert.ToString(Convert.ToInt32(score1.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                        }
                    }
                    else
                    {
                        if (freeSpaceExist==0)
                        {
                            Print("The board is full, the results are: ");
                            int PlayerAPoints=0,PlayerBPoints=0;
                            for (int i = 0; i < Table.Columns; i++)
                            {
                                for (int j = 0; j < Table.Rows; j++)
                                {
                                    if (Table.Board[i, j] == 'A')
                                        PlayerAPoints++;
                                    if (Table.Board[i, j] == 'B')
                                        PlayerBPoints++;
                                }
                            }
                            Print("Player A: " + PlayerAPoints+" and the ");
                            Print("Player B: " + PlayerBPoints+", so ");
                            if (PlayerAPoints > PlayerBPoints)
                            {
                                Print("the winner is: Player A.");
                                score1.Text = "Score: " + Convert.ToString(Convert.ToInt32(score1.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                            }
                            else if (PlayerAPoints < PlayerBPoints)
                            {
                                score2.Text = "Score: " + Convert.ToString(Convert.ToInt32(score2.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                                Print("the winner is: Player B.");
                            }
                            else
                            {
                                Print("there is no winner.");
                            }
                            Table.InitializeBoard();
                            start.Visible = true;
                            customize1.Enabled = true;
                            customize2.Enabled = true;
                            mChoice.Enabled = true;
                            nChoice.Enabled = true;
                            PlayerAFirst.Enabled = true;
                            PlayerBFirst.Enabled = true;
                        }
                        else
                        {
                            Print("The Player " + yourWord + " played, the other player is on move." + System.Environment.NewLine);
                            if (yourWord == 'A')
                                yourWord = 'B';
                            else yourWord = 'A';
                        }
                    }
                }
                else
                {
                    Print("Player " + yourWord + " can't finish in less than a second." + System.Environment.NewLine + "The other player take this score." + System.Environment.NewLine);
                    Table.InitializeBoard();
                    start.Visible = true;
                    customize1.Enabled = true;
                    customize2.Enabled = true;
                    mChoice.Enabled = true;
                    nChoice.Enabled = true;
                    PlayerAFirst.Enabled = true;
                    PlayerBFirst.Enabled = true;
                    if (yourWord == 'A')
                    {
                        score2.Text = "Score: " + Convert.ToString(Convert.ToInt32(score2.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                    }
                    if (yourWord == 'B')
                    {
                        score1.Text = "Score: " + Convert.ToString(Convert.ToInt32(score1.Text.TrimStart('S', 'c', 'o', 'r', 'e', ':', ' ')) + 1);
                    }

                }

            }
        }

        private bool IsThisMoveLegal(char[,] table)
        {
            int[] il = new int[3];
            int[] jn = new int[3];
            int k=0;
                    for (int i = 0; i < Table.Columns; i++)
                    {
                        for (int j = 0; j < Table.Rows; j++)
                        {
                            if (table[i,j]!=Table.Board[i,j])
                            {
                                if(k>3)
                                    return false;
                                k++;
                                il[k]=i;
                                jn[k]=j;
                            }
                        }
                    }
            if ((il[0]-il[1])==(il[1]-il[2])&&(jn[0]-jn[1])==(jn[1]-jn[2]))
                return true;
            if (k==1)
            {
                return true;
            }
            return false;
        }

        private void TableCheck()
        {
            int N = Convert.ToInt16(nChoice.Text);
            int M = Convert.ToInt16(mChoice.Text);
            Table.Rows = M;
            Table.Columns = N;
            if (N < 5)
            {
                this.ClientSize = new System.Drawing.Size(332 + M * 32, 151 + 5 * 32);
                Dialog.Location = new System.Drawing.Point(220, 40 + 5 * 32);
                Dialog.Size = new System.Drawing.Size(100 + M * 32, 100);
            }
            else if (N < 8)
            {
                this.ClientSize = new System.Drawing.Size(332 + M * 32, 151 + N * 32);
                Dialog.Location = new System.Drawing.Point(220, 40 + N * 32);
                Dialog.Size = new System.Drawing.Size(100 + M * 32, 100);
            }
            else if (N == 8)
            {
                this.ClientSize = new System.Drawing.Size(332 + M * 32, 151 + 9 * 32);
                Dialog.Location = new System.Drawing.Point(20, 40 + 9 * 32);
                Dialog.Size = new System.Drawing.Size(300 + M * 32, 100);
            }
            else
            {
                this.ClientSize = new System.Drawing.Size(332 + M * 32, 151 + N * 32);
                Dialog.Location = new System.Drawing.Point(20, 40 + N * 32);
                Dialog.Size = new System.Drawing.Size(300 + M * 32,100);
            }








            
        }


    }

}