﻿using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace PCmagazineTask1_B_
{
    public partial class CustomControlBoard : Control
    {
        private int columns = 5;
        private int rows = 5;
        private const int cellSize = 32;
        private char[,] board;

        [Category("Behavior"), Description("Specifies the board rows count.")]
        public int Rows
        {
            get
            {
                return this.rows;
            }
            set
            {
                this.rows = value;
                this.Height = cellSize * rows;
                InitializeBoard();
            }
        }

        [Category("Behavior"), Description("Specifies the board columns count.")]
        public int Columns
        {
            get
            {
                return this.columns;
            }
            set
            {
                this.columns = value;
                this.Width = cellSize * columns;
                InitializeBoard();
            }
        }

        [Category("Behavior"), Description("Specifies the board contents.")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public char[,] Board
        {
            get
            {
                return this.board;
            }
            set
            {
                this.board = value;
                this.rows = this.board.GetLength(0);
                this.columns = this.board.GetLength(1);
                this.Invalidate();
            }
        }

        public void InitializeBoard()
        {
            this.board = new char[this.rows, this.columns];
            for (int row = 0; row < this.rows; row++)
            {
                for (int col = 0; col < this.columns; col++)
                {
                    this.board[row, col] = '-';
                }
            }
            this.Invalidate();
        }

        public CustomControlBoard()
        {
            InitializeComponent();
            this.Columns = columns;
            this.Rows = rows;
        }

        protected override void OnPaint(PaintEventArgs paintEvent)
        {
            base.OnPaint(paintEvent);

            Graphics graphic = paintEvent.Graphics;
            for (int row = 0; row < this.rows; row++)
            {
                for (int col = 0; col < this.columns; col++)
                {
                    if (this.DesignMode)
                    {
                        graphic.DrawRectangle(Pens.Black, col * cellSize, row * cellSize,
                            cellSize - 1, cellSize - 1);
                    }
                    else
                    {
                        char cellChar = this.board[row, col];
                        Image img = ImageUtils.GetImage(cellChar);
                        graphic.DrawImage(img, col * cellSize, row * cellSize);
                    }
                }
            }
        }
    }
}