﻿using System.Collections.Generic;
using System.Drawing;
using System;
using System.Reflection;
using System.IO;
using System.Windows.Forms;
namespace PCmagazineTask1_B_
{
    class ImageUtils
    {
        private static Dictionary<string, Image> images =
            new Dictionary<string, Image>();

        public static Image GetImage(char letter)
        {
            string imageFileName;
            switch (letter)
            {
                case 'A':
                    imageFileName = "BlockA.png";
                    break;
                case 'B':
                    imageFileName = "BlockB.png";
                    break;
                case '-':
                    imageFileName = "BlockEmpty.png";
                    break;
                default:
                    throw new ArgumentException("Invalid letter: " + letter);
            }

            if (images.ContainsKey(imageFileName))
            {
                return images[imageFileName];
            }

            Image img = LoadImage(imageFileName);
            images[imageFileName] = img;
            return img;
        }

        private static Image LoadImage(string imageFileName)
        {
            Assembly currentAssembly = Assembly.GetExecutingAssembly();
            string imageResourceName = Path.GetDirectoryName(Application.ExecutablePath).Remove(Path.GetDirectoryName(Application.ExecutablePath).Length-10) +
                Path.DirectorySeparatorChar + "Images" + Path.DirectorySeparatorChar + "BlockEmpty.png";
            Stream imageStream = currentAssembly.
                GetManifestResourceStream(imageResourceName);
            
                Image img = Image.FromFile(imageResourceName);
                return img;
        }
    }
}
