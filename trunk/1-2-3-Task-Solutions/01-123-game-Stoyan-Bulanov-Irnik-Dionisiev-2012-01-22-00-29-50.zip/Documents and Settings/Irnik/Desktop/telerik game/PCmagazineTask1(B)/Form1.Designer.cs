﻿namespace PCmagazineTask1_B_
{
    partial class theForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.customize1 = new System.Windows.Forms.Button();
            this.name1 = new System.Windows.Forms.Label();
            this.customize2 = new System.Windows.Forms.Button();
            this.name2 = new System.Windows.Forms.Label();
            this.mChoice = new System.Windows.Forms.ComboBox();
            this.nChoice = new System.Windows.Forms.ComboBox();
            this.mShow = new System.Windows.Forms.Label();
            this.nShow = new System.Windows.Forms.Label();
            this.score1 = new System.Windows.Forms.Label();
            this.score2 = new System.Windows.Forms.Label();
            this.Dialog = new System.Windows.Forms.TextBox();
            this.finish = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.start = new System.Windows.Forms.Button();
            this.PlayerAFirst = new System.Windows.Forms.RadioButton();
            this.PlayerBFirst = new System.Windows.Forms.RadioButton();
            this.RadioButtonLabel = new System.Windows.Forms.Label();
            this.Table = new PCmagazineTask1_B_.CustomControlBoard();
            this.SuspendLayout();
            // 
            // customize1
            // 
            this.customize1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customize1.Location = new System.Drawing.Point(23, 69);
            this.customize1.Name = "customize1";
            this.customize1.Size = new System.Drawing.Size(79, 23);
            this.customize1.TabIndex = 0;
            this.customize1.Text = "Customize";
            this.customize1.UseVisualStyleBackColor = true;
            this.customize1.Click += new System.EventHandler(this.customize1_Click);
            // 
            // name1
            // 
            this.name1.AutoSize = true;
            this.name1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name1.Location = new System.Drawing.Point(19, 25);
            this.name1.Margin = new System.Windows.Forms.Padding(3);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(71, 20);
            this.name1.TabIndex = 1;
            this.name1.Text = "Player A:";
            // 
            // customize2
            // 
            this.customize2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customize2.Location = new System.Drawing.Point(23, 159);
            this.customize2.Name = "customize2";
            this.customize2.Size = new System.Drawing.Size(80, 23);
            this.customize2.TabIndex = 2;
            this.customize2.Text = "Customize";
            this.customize2.UseVisualStyleBackColor = true;
            this.customize2.Click += new System.EventHandler(this.customize2_Click);
            // 
            // name2
            // 
            this.name2.AutoSize = true;
            this.name2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name2.Location = new System.Drawing.Point(19, 117);
            this.name2.Margin = new System.Windows.Forms.Padding(3);
            this.name2.Name = "name2";
            this.name2.Size = new System.Drawing.Size(71, 20);
            this.name2.TabIndex = 3;
            this.name2.Text = "Player B:";
            // 
            // mChoice
            // 
            this.mChoice.FormattingEnabled = true;
            this.mChoice.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.mChoice.Location = new System.Drawing.Point(50, 200);
            this.mChoice.Name = "mChoice";
            this.mChoice.Size = new System.Drawing.Size(45, 21);
            this.mChoice.TabIndex = 4;
            this.mChoice.Text = "5";
            this.mChoice.SelectedIndexChanged += new System.EventHandler(this.mChoice_SelectedIndexChanged);
            // 
            // nChoice
            // 
            this.nChoice.FormattingEnabled = true;
            this.nChoice.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.nChoice.Location = new System.Drawing.Point(145, 200);
            this.nChoice.Name = "nChoice";
            this.nChoice.Size = new System.Drawing.Size(44, 21);
            this.nChoice.TabIndex = 5;
            this.nChoice.Text = "5";
            this.nChoice.SelectedIndexChanged += new System.EventHandler(this.nChoice_SelectedIndexChanged);
            // 
            // mShow
            // 
            this.mShow.AutoSize = true;
            this.mShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mShow.Location = new System.Drawing.Point(20, 200);
            this.mShow.Name = "mShow";
            this.mShow.Size = new System.Drawing.Size(26, 20);
            this.mShow.TabIndex = 6;
            this.mShow.Text = "M:";
            // 
            // nShow
            // 
            this.nShow.AutoSize = true;
            this.nShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nShow.Location = new System.Drawing.Point(115, 200);
            this.nShow.Name = "nShow";
            this.nShow.Size = new System.Drawing.Size(24, 20);
            this.nShow.TabIndex = 7;
            this.nShow.Text = "N:";
            // 
            // score1
            // 
            this.score1.AutoSize = true;
            this.score1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score1.Location = new System.Drawing.Point(20, 50);
            this.score1.Name = "score1";
            this.score1.Size = new System.Drawing.Size(57, 16);
            this.score1.TabIndex = 8;
            this.score1.Text = "Score: 0";
            // 
            // score2
            // 
            this.score2.AutoSize = true;
            this.score2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score2.Location = new System.Drawing.Point(20, 140);
            this.score2.Name = "score2";
            this.score2.Size = new System.Drawing.Size(57, 16);
            this.score2.TabIndex = 9;
            this.score2.Text = "Score: 0";
            // 
            // Dialog
            // 
            this.Dialog.Enabled = false;
            this.Dialog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dialog.Location = new System.Drawing.Point(220, 200);
            this.Dialog.Multiline = true;
            this.Dialog.Name = "Dialog";
            this.Dialog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Dialog.Size = new System.Drawing.Size(260, 100);
            this.Dialog.TabIndex = 10;
            this.Dialog.WordWrap = false;
            // 
            // finish
            // 
            this.finish.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finish.Location = new System.Drawing.Point(130, 265);
            this.finish.Name = "finish";
            this.finish.Size = new System.Drawing.Size(60, 35);
            this.finish.TabIndex = 12;
            this.finish.Text = "Finish";
            this.finish.UseVisualStyleBackColor = true;
            // 
            // next
            // 
            this.next.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.Location = new System.Drawing.Point(23, 265);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(101, 35);
            this.next.TabIndex = 13;
            this.next.Text = "Next";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // start
            // 
            this.start.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start.Location = new System.Drawing.Point(23, 265);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(166, 35);
            this.start.TabIndex = 14;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // PlayerAFirst
            // 
            this.PlayerAFirst.AutoSize = true;
            this.PlayerAFirst.Checked = true;
            this.PlayerAFirst.Location = new System.Drawing.Point(119, 238);
            this.PlayerAFirst.Name = "PlayerAFirst";
            this.PlayerAFirst.Size = new System.Drawing.Size(32, 17);
            this.PlayerAFirst.TabIndex = 15;
            this.PlayerAFirst.TabStop = true;
            this.PlayerAFirst.Text = "A";
            this.PlayerAFirst.UseVisualStyleBackColor = true;
            this.PlayerAFirst.Click += new System.EventHandler(this.PlayerAFirst_Click);
            // 
            // PlayerBFirst
            // 
            this.PlayerBFirst.AutoSize = true;
            this.PlayerBFirst.Location = new System.Drawing.Point(157, 238);
            this.PlayerBFirst.Name = "PlayerBFirst";
            this.PlayerBFirst.Size = new System.Drawing.Size(32, 17);
            this.PlayerBFirst.TabIndex = 16;
            this.PlayerBFirst.Text = "B";
            this.PlayerBFirst.UseVisualStyleBackColor = true;
            this.PlayerBFirst.Click += new System.EventHandler(this.PlayerBFirst_Click);
            // 
            // RadioButtonLabel
            // 
            this.RadioButtonLabel.AutoSize = true;
            this.RadioButtonLabel.Location = new System.Drawing.Point(20, 240);
            this.RadioButtonLabel.Name = "RadioButtonLabel";
            this.RadioButtonLabel.Size = new System.Drawing.Size(93, 13);
            this.RadioButtonLabel.TabIndex = 17;
            this.RadioButtonLabel.Text = "First will be Player:";
            // 
            // Table
            // 
            this.Table.Columns = 20;
            this.Table.Location = new System.Drawing.Point(275, 25);
            this.Table.Name = "Table";
            this.Table.Rows = 20;
            this.Table.Size = new System.Drawing.Size(160, 160);
            this.Table.TabIndex = 11;
            // 
            // theForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 311);
            this.Controls.Add(this.RadioButtonLabel);
            this.Controls.Add(this.PlayerBFirst);
            this.Controls.Add(this.PlayerAFirst);
            this.Controls.Add(this.start);
            this.Controls.Add(this.next);
            this.Controls.Add(this.finish);
            this.Controls.Add(this.Table);
            this.Controls.Add(this.Dialog);
            this.Controls.Add(this.score2);
            this.Controls.Add(this.score1);
            this.Controls.Add(this.nShow);
            this.Controls.Add(this.mShow);
            this.Controls.Add(this.nChoice);
            this.Controls.Add(this.mChoice);
            this.Controls.Add(this.name2);
            this.Controls.Add(this.customize2);
            this.Controls.Add(this.name1);
            this.Controls.Add(this.customize1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "theForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button customize1;
        private System.Windows.Forms.Label name1;
        private System.Windows.Forms.Button customize2;
        private System.Windows.Forms.Label name2;
        private System.Windows.Forms.ComboBox mChoice;
        private System.Windows.Forms.ComboBox nChoice;
        private System.Windows.Forms.Label mShow;
        private System.Windows.Forms.Label nShow;
        private System.Windows.Forms.Label score1;
        private System.Windows.Forms.Label score2;
        private System.Windows.Forms.TextBox Dialog;
        private PCmagazineTask1_B_.CustomControlBoard Table;
        private System.Windows.Forms.Button finish;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.RadioButton PlayerAFirst;
        private System.Windows.Forms.RadioButton PlayerBFirst;
        private System.Windows.Forms.Label RadioButtonLabel;
    }
}

