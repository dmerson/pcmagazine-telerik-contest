#include<iostream>
#include<string.h>
#include <ctime>
using namespace std;
int main()
{
    int m,n,i=0,j=0;
    try
    {
    cin>>m;
    }
    catch(char notNumber)
    {
        cout<<"error";
    }
    if(m<3||m>20)
    {
        cout<<"error";
        return 0;
    }
    try
    {
    cin>>n;
    }
    catch(char notNumber)
    {
        cout<<"error";
    }
    if(n<3||n>20)
    {
        cout<<"error";
        return 0;
    }
    char a[m][n],validator;
    for(i;i<m;i++)
    for(j=0;j<n;j++)
    {
    cin>>validator;
    if(validator!='A'&&validator!='B'&&validator!='-')
    {
    cout<<"error";
    return 0;
    }
    a[i][j]=validator;
    }
    cin>>validator;
    if(validator!='A'&&validator!='B')
    {
    cout<<"error";
    return 0;
    }
    char MyWord=validator;
        
        for(i=0;i+2<m;i++)//1
        for(j=0;j+2<n;j++)
        if(a[i+2][j]=='-'&&a[i+1][j+1]=='-'&&a[i][j+2]=='-')
        {
            a[i+2][j]=MyWord;
            a[i+1][j+1]=MyWord;
            a[i][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//2
        for(j=0;j+2<n;j++)
        if(a[i][j]=='-'&&a[i+1][j+1]=='-'&&a[i+2][j+2]=='-')
        {
            a[i][j]=MyWord;
            a[i+1][j+1]=MyWord;
            a[i+2][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i<m;i++)//3
        for(j=0;j+2<n;j++)
        if(a[i][j]=='-'&&a[i][j+1]=='-'&&a[i][j+2]=='-')
        {
            a[i][j]=MyWord;
            a[i][j+1]=MyWord;
            a[i][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//4
        for(j=0;j<n;j++)
        if(a[i+2][j]=='-'&&a[i+1][j]=='-'&&a[i][j]=='-')
        {
            a[i+2][j]=MyWord;
            a[i+1][j]=MyWord;
            a[i][j]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+1<m;i++)//5
        for(j=0;j+1<n;j++)
        if(a[i+1][j]=='-'&&a[i][j+1]=='-')
        {
            a[i+1][j]=MyWord;
            a[i][j+1]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+1<m;i++)//6
        for(j=0;j+1<n;j++)
        if(a[i][j]=='-'&&a[i+1][j+1]=='-')
        {
            a[i][j]=MyWord;
            a[i+1][j+1]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i<m;i++)//7
        for(j=0;j+2<n;j++)
        if(a[i][j]=='-'&&a[i][j+1]=='-')
        {
            a[i][j]=MyWord;
            a[i][j+1]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//8
        for(j=0;j<n;j++)
        if(a[i+1][j]=='-'&&a[i][j]=='-')
        {
            a[i+1][j]=MyWord;
            a[i][j]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//9
        for(j=0;j+2<n;j++)
        if(a[i+2][j]=='-'&&a[i+1][j+1]==MyWord&&a[i][j+2]=='-')
        {
            a[i+2][j]=MyWord;
            a[i+1][j+1]=MyWord;
            a[i][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//10
        for(j=0;j+2<n;j++)
        if(a[i][j]=='-'&&a[i+1][j+1]==MyWord&&a[i+2][j+2]=='-')
        {
            a[i][j]=MyWord;
            a[i+1][j+1]=MyWord;
            a[i+2][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i<m;i++)//11
        for(j=0;j+2<n;j++)
        if(a[i][j]=='-'&&a[i][j+1]==MyWord&&a[i][j+2]=='-')
        {
            a[i][j]=MyWord;
            a[i][j+1]=MyWord;
            a[i][j+2]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i+2<m;i++)//12
        for(j=0;j<n;j++)
        if(a[i+2][j]=='-'&&a[i+1][j]==MyWord&&a[i][j]=='-')
        {
            a[i+2][j]=MyWord;
            a[i+1][j]=MyWord;
            a[i][j]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
        for(i=0;i<m;i++)//13
        for(j=0;j<n;j++)
        if(a[i][j]=='-')
        {
            a[i][j]=MyWord;
                for(i=0;i<m;i++)
                {
                    for(j=0;j<n;j++)
                    cout<<a[i][j];
                    cout<<endl;
                }
            return 0;
        }
    cout<<"error";
    return 0;
}
