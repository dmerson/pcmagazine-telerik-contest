﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StupidEngine
{
    class StupidEngine
    {
        const char EMPTY_CELL = '-';
        const char PLAYER_A_SYMBOL = 'A';
        const char PLAYER_B_SYMBOL = 'B';
        static void Input(ref char[,] board,ref char playerOnMOveLetter)
        {
            string firstLine = Console.ReadLine();
            int columns = int.Parse((firstLine.Split(' '))[0]);
            int rows = int.Parse((firstLine.Split(' '))[1]);
            if (columns<3 || columns>20 || rows<3 || rows>20)
            {
                throw new ArgumentOutOfRangeException("Invalid Data!");
            }
            board = new char[rows, columns];
            for (int i = 0; i < rows; i++)
            {
                string currentLine = Console.ReadLine();
                if (currentLine.Length!=columns)
                {
                    throw new ArgumentOutOfRangeException("Line is not the required length!");
                }
                for (int j = 0; j < currentLine.Length; j++)
                {
                    if (currentLine[j]!=EMPTY_CELL && currentLine[j]!=PLAYER_A_SYMBOL &&
                        currentLine[j]!=PLAYER_B_SYMBOL)
                    {
                        throw new ArgumentOutOfRangeException("Invalid data!");
                    }
                    board[i, j] = currentLine[j];
                }
            }
            string lastLine = Console.ReadLine();
            if (lastLine[0]!=PLAYER_A_SYMBOL && lastLine[0]!=PLAYER_B_SYMBOL)
            {
                throw new ArgumentOutOfRangeException("Invalid data!");
            }
            playerOnMOveLetter=lastLine[0];
        }
        static void MakeMove(ref char[,] board, char playerLetter)
        {
            bool validMoveFound = false;
            for (int NumberOfCells = 3; NumberOfCells >= 1; NumberOfCells--)
            {
                for (int i = 0; i < board.GetLength(0); i++)
                {
                    for (int j = 0; j < board.GetLength(1); j++)
                    {
                        if (RightMoveValid(board, playerLetter,i,j,NumberOfCells))
                        {
                            for (int m = j; m < j + NumberOfCells; m++)
                            {
                                board[i, m] = playerLetter;
                                
                            }
                            return;
                        }
                        if (DownMoveValid(board, playerLetter, i, j, NumberOfCells))
                        {
                            for (int m = i; m < i + NumberOfCells; m++)
                            {
                                board[m, j] = playerLetter;
                                
                            }
                            return;
                        }
                        if (DiagonalMoveValid(board, playerLetter, i, j, NumberOfCells))
                        {
                            for (int m = 0; m < NumberOfCells; m++)
                            {
                                board[i+m, j+m] = playerLetter;
                                
                            }
                            return;
                        }
                    }
                }
            }
            if (!validMoveFound)
            {
                throw new InvalidOperationException("No moves found!");
            }
        }
        static bool RightMoveValid(char [,] board, char playerLetter, int i, int j, int NumberOfCells)
        {
            if (j+NumberOfCells-1>=board.GetLength(0))
            {
                return false;
            }
            for (int m = j; m < j+NumberOfCells; m++)
            {
                if (board[i,m]!=EMPTY_CELL)
                {
                    return false;
                }
            }
            return true;
        }
        static bool DownMoveValid(char[,] board, char playerLetter, int i, int j, int NumberOfCells)
        {
            if (i + NumberOfCells - 1 >= board.GetLength(1))
            {
                return false;
            }
            for (int m = i; m < i + NumberOfCells; m++)
            {
                if (board[m, j] != EMPTY_CELL)
                {
                    return false;
                }
            }
            return true;
        }
        static bool DiagonalMoveValid(char[,] board, char playerLetter, int i, int j, int NumberOfCells)
        {
            if (j + NumberOfCells - 1 >= board.GetLength(1) || i + NumberOfCells - 1 >= board.GetLength(0))
            {
                return false;
            }
            for (int m = 0; m < NumberOfCells; m++)
            {
                if (board[i+m, j+m] != EMPTY_CELL)
                {
                    return false;
                }
            }
            return true;
        }
        static void Output(char[,] board)
        {
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    Console.Write(board[i,j]);
                }
                Console.WriteLine();
            }
        }
        static void Main()
        {
            char[,] board= new char[1,1];
            char playerOnMOveLetter='-';
            try
            {
                Input(ref board, ref playerOnMOveLetter);
                MakeMove(ref board, playerOnMOveLetter);
                Output(board);
            }
            catch (Exception)
            {

                Console.WriteLine("error");
            }
        }
    }
}
