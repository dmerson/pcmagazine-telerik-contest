﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _123GameSimulator
{
    /// <summary>
    /// Interaction logic for PlayerWindow.xaml
    /// </summary>
    public partial class PlayerWindow : UserControl
    {
        public Player player { get; private set; }
        public bool EngineLoaded { get; private set; }
        public string EngineName { get; private set; }
        public PlayerWindow()
        {
            InitializeComponent();
        }
        public void ResetScore()
        {
            player.Score=0;
        }
        public void IncreaseScore()
        {
            player.Score++;
        }
        private void EngineButton_Click(object sender, RoutedEventArgs e)
        {
            player = new Player();
            player.PlayerLetter = ((string)PlayerLetterLabel.Content)[0];
            Microsoft.Win32.OpenFileDialog selectEngineDialog = new Microsoft.Win32.OpenFileDialog();
            selectEngineDialog.FileName = "Engine"; 
            selectEngineDialog.DefaultExt = ".exe"; 
            selectEngineDialog.Filter = "Game Engines(.exe)|*.exe"; 

            Nullable<bool> result = selectEngineDialog.ShowDialog();
            string fileName=null;
            if (result == true)
            {
                fileName = selectEngineDialog.FileName;
            }
            if (!String.IsNullOrEmpty(fileName))
            {
                try
                {
                    player.LoadEngine(fileName);
                    EngineName = fileName;
                    EngineLoaded = true;
                    EngineIndicator.Fill = new SolidColorBrush(Colors.SpringGreen);
                }
                catch (Exception ex)
                {
                    EngineLoaded = false;
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
