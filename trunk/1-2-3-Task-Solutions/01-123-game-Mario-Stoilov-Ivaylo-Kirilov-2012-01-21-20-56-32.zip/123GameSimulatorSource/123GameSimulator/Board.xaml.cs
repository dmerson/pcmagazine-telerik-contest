﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _123GameSimulator
{
    /// <summary>
    /// Interaction logic for Board.xaml
    /// </summary>
    public partial class Board : UserControl
    {
        private const char EMPTY_CELL = '-';
        private const char PLAYER_A_SYMBOL = 'A';
        private const char PLAYER_B_SYMBOL = 'B';
        private int rowsCount, columnsCount;

        public char[,] cells;
        public Board(int columns, int rows)
        {
            InitializeComponent();
            this.columnsCount = columns;
            this.rowsCount = rows;
            cells = new char[rowsCount,columnsCount];
            for (int i = 0; i < rowsCount; i++)
            {
                for (int j = 0; j < columnsCount; j++)
                {
                    cells[i, j] = EMPTY_CELL;
                }
            }
            RedrawBoard();
        }
        public bool CheckForValidMoves()
        {
            for (int i = 0; i < rowsCount; i++)
            {
                for (int j = 0; j < columnsCount; j++)
                {
                    if (cells[i, j] == EMPTY_CELL)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public void RedrawBoard()
        {
            double CELL_SIZE = 154/5;
            Container.Width = CELL_SIZE * columnsCount;
            Container.Height = CELL_SIZE * rowsCount;
            for (int i = 0; i < rowsCount; i++)
            {
                for (int j = 0; j < columnsCount; j++)
                {
                    Image newCell = new Image();
                    if (cells[i, j]==EMPTY_CELL)
                    {
                        newCell.Source = EmptyCellImage.Source;
                    }
                    else if (cells[i, j] == PLAYER_A_SYMBOL)
                    {
                        newCell.Source = CellImageA.Source;
                    }
                    else if (cells[i, j] == PLAYER_B_SYMBOL)
                    {
                        newCell.Source = CellImageB.Source;
                    }
                    //newCell.RenderTransform = new ScaleTransform(0.4, 0.4);
                    newCell.Width = CELL_SIZE;
                    newCell.Height = CELL_SIZE;
                    Canvas.SetLeft(newCell, CELL_SIZE * j);
                    Canvas.SetTop(newCell, CELL_SIZE * i);
                    Container.Children.Add(newCell);
                }
            }
        }
    }
}
