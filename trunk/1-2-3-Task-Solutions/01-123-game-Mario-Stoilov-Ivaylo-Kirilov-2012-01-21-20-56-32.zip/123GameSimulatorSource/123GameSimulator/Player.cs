﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace _123GameSimulator
{
    public class Player
    {
        public int Score { get; set; }
        public char PlayerLetter { get; set; }
        public String EnginePath { get; private set; }

        public void LoadEngine(string fileName)
        {
            string fileExtension = fileName.Substring(fileName.IndexOf('.'));
            bool engineLoaded = false;
            if (fileExtension==".exe")
            {
                engineLoaded = true;
            }
            if (!engineLoaded)
            {
                throw new InvalidOperationException(
                    "Could not load engine!");
            }
        }
    }
}
