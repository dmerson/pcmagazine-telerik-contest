﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;

namespace _123GameSimulator
{
    public struct Move
    {
        public int X;
        public int Y;
    }
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const char EMPTY_CELL = '-';
        private const char PLAYER_A_SYMBOL = 'A';
        private const char PLAYER_B_SYMBOL = 'B';
        private int COLUMS_COUNT;
        private int ROWS_COUNT;
        private const int TURN_TIME_MILLISECONDS = 1000;

        private int playerOnMoveIndex;

        Board GameBoard;
        public MainWindow()
        {
            InitializeComponent();
            playerWindowA.PlayerLetterLabel.Content = "A";
            playerWindowB.PlayerLetterLabel.Content = "B";
        }
        void ShowBoardSpecifier()
        {
            this.IsEnabled = false;
            BoardSpecifier boardSpecifierDIalogBox = new BoardSpecifier();
            boardSpecifierDIalogBox.Closing += new System.ComponentModel.CancelEventHandler(delegate(object sender, System.ComponentModel.CancelEventArgs e)
                {
                    this.IsEnabled = true;
                }

                );
            boardSpecifierDIalogBox.OKButton.Click += new RoutedEventHandler(delegate(object sender, RoutedEventArgs e)
                {
                    try
                    {
                        UpdateBoardBounds((int)boardSpecifierDIalogBox.ColumnsSlider.Value,
                            (int)boardSpecifierDIalogBox.RowsSlider.Value);
                        boardSpecifierDIalogBox.Close();
                        ResizeWindow();
                        playerWindowA.EngineButton.IsEnabled = true;
                        playerWindowB.EngineButton.IsEnabled = true;
                        nextMoveButton.IsEnabled = false;
                        startGameButton.IsEnabled = true;
                    }
                    catch (ArgumentOutOfRangeException ex)
                    {
                        string message = ex.Message.Substring(ex.Message.IndexOf(':') + 2);
                        MessageBox.Show(message);
                    }
                    catch
                    {
                        MessageBox.Show("An unknown error occured. Please, contact the developer.");
                    }
                });
            boardSpecifierDIalogBox.Show();
        }

        private void ResizeWindow()
        {

            GameBoard = new Board(COLUMS_COUNT, ROWS_COUNT);
            if (BoardContainer.Children.Count > 0)
            {
                BoardContainer.Children.RemoveAt(0);
            }
            if (GameBoard.Container.Width >= BoardContainer.MinWidth)
            {
                BoardContainer.Width = GameBoard.Container.Width;
            }
            else
            {
                BoardContainer.Width = BoardContainer.MinWidth;
            }
            if (GameBoard.Container.Height >= BoardContainer.MinHeight)
            {
                BoardContainer.Height = GameBoard.Container.Height;
            }
            else
            {
                BoardContainer.Height = BoardContainer.MinHeight;
            }
            BoardContainer.Children.Add(GameBoard);
            LayoutRoot.Width = 150 + BoardContainer.Width;
            LayoutRoot.Height = BoardContainer.Height + LogBox.Height;
            
            this.Width = 150 + BoardContainer.Width +10;
            this.Height = BoardContainer.Height + LogBox.Height +25;
            LogBox.Width = LayoutRoot.ActualWidth - 2 * playerWindowA.Width;
            
        }

        
        private void UpdateBoardBounds(int columnsCount, int rowsCount)
        {
            if (columnsCount<3 || columnsCount>20)
            {
                throw new ArgumentOutOfRangeException("Columns should be between 3 and 20!");
            }
            if (rowsCount<3 || rowsCount>20)
            {
                throw new ArgumentOutOfRangeException("Rows should be between 3 and 20!");
            }
            COLUMS_COUNT = columnsCount;
            ROWS_COUNT = rowsCount;
        }

        private void newGameButton_Click(object sender, RoutedEventArgs e)
        {
            ShowBoardSpecifier();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            foreach (Window window in App.Current.Windows)
            {
                if (!window.Equals(this))
                {
                    window.Close();
                }
                
            }
        }

        private void nextMoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (playerOnMoveIndex==0)
            {
                
                try
                {
                    char[,] newBoard = new char[1,1];
                    char[,] oldBoard = ((Board)BoardContainer.Children[0]).cells;
                    MoveTimer.TryMove(delegate()
                    {
                        newBoard = CallEngine(oldBoard, PLAYER_A_SYMBOL, playerWindowA.EngineName);
                    }, 1000);

                    List<Move> moves = 
                       ValidateMove(newBoard, ((Board)BoardContainer.Children[0]).cells, PLAYER_A_SYMBOL);
                    ((Board)BoardContainer.Children[0]).cells = newBoard;
                    ((Board)BoardContainer.Children[0]).RedrawBoard();
                    LogMove(ref playerWindowA, moves);
                    playerOnMoveIndex = 1;
                    if (!((Board)BoardContainer.Children[0]).CheckForValidMoves())
                    {
                        EndGame();
                    }
                    else
                    {
                        LogBox.Text += "Player B on move! \n";
                    }
                }
                catch (Exception ex)
                {

                    EndGame(PLAYER_A_SYMBOL, ex.Message);
                }
                

            }
            else if (playerOnMoveIndex == 1)
            {
                
                try
                {
                    char[,] newBoard = new char[1, 1];
                    char[,] oldBoard = ((Board)BoardContainer.Children[0]).cells;
                    MoveTimer.TryMove(delegate()
                    {
                        newBoard = CallEngine(oldBoard, PLAYER_B_SYMBOL, playerWindowB.EngineName);
                    }, 1000);
                    List<Move> moves = 
                        ValidateMove(newBoard, ((Board)BoardContainer.Children[0]).cells, PLAYER_B_SYMBOL);
                    ((Board)BoardContainer.Children[0]).cells = newBoard;
                    ((Board)BoardContainer.Children[0]).RedrawBoard();
                    LogMove(ref playerWindowB, moves);
                    playerOnMoveIndex = 0;
                    if (!((Board)BoardContainer.Children[0]).CheckForValidMoves())
                    {
                        EndGame();
                    }
                    else
                    {
                        LogBox.Text += "Player A on move! \n";
                    }
                }
                catch (Exception ex)
                {

                    EndGame(PLAYER_B_SYMBOL, ex.Message);
                }
            }
        }

        private char[,] CallEngine(char [,] oldBoard, char playerLetter, string Engine)
        {
            char[,] newBoard = new char[ROWS_COUNT,COLUMS_COUNT];
            Process p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.FileName = Engine;

            p.Start();
            StreamWriter processInput = p.StandardInput;
            processInput.WriteLine(COLUMS_COUNT.ToString() + " " + ROWS_COUNT.ToString());
            for (int i = 0; i < ROWS_COUNT; i++)
            {
                for (int j = 0; j < COLUMS_COUNT; j++)
                {
                    char charToinput = oldBoard[i, j];
                    processInput.Write(charToinput);
                }
                processInput.WriteLine();
            }
            processInput.WriteLine(playerLetter);
            StreamReader processOutput = p.StandardOutput;
            p.WaitForExit();
            p.Close();
            int f = 0;
            while (!processOutput.EndOfStream)
            {
                string output = processOutput.ReadLine();
                for (int g = 0; g < output.Length; g++)
                {
                    newBoard[f, g] = output[g];
                }
                f++;
            }
            return newBoard;
        }
        private void LogMove(ref PlayerWindow playerWindow, List<Move> moves)
        {
            LogBox.Text += "Player " + playerWindow.player.PlayerLetter + " moved: ";
            foreach (Move move in moves)
            {
                playerWindow.player.Score++;
                LogBox.Text += "{" + move.X + "," + move.Y + "} ";
            }
            LogBox.Text += "\n";
            UpadteScores();
        }
        void UpadteScores()
        {
            playerWindowA.ScoreLabel.Content = playerWindowA.player.Score;
            playerWindowB.ScoreLabel.Content = playerWindowB.player.Score;
        }
        void EndGame()
        {
            nextMoveButton.IsEnabled = false;
            if (playerWindowA.player.Score>playerWindowB.player.Score)
            {
                LogBox.Text += "Player A wins!";
            }
            else if (playerWindowA.player.Score < playerWindowB.player.Score)
            {
                LogBox.Text += "Player B wins!";
            }
            else
            {
                LogBox.Text += "The game is a tie!";
            }
        }

        private void startGameButton_Click(object sender, RoutedEventArgs e)
        {
            if (!playerWindowA.EngineLoaded)
            {
                MessageBox.Show("Cannot start game! Player A has no engine loaded.");
                return;
            }
            if (!playerWindowB.EngineLoaded)
            {
                MessageBox.Show("Cannot start game! Player B has no engine loaded.");
                return;
            }
            playerWindowA.ResetScore();
            playerWindowA.ScoreLabel.Content = playerWindowA.player.Score;
            playerWindowB.ResetScore();
            playerWindowB.ScoreLabel.Content = playerWindowB.player.Score;
            LogBox.Text = "";
            nextMoveButton.IsEnabled = true;
            startGameButton.IsEnabled = false;
            LogBox.Text += "Game Started! \n";
            LogBox.Text += "Player A uses " + playerWindowA.EngineName + "\n";
            LogBox.Text += "Player B uses " + playerWindowB.EngineName + "\n";
            LogBox.Text += "Player A, please make your move! \n";
            playerOnMoveIndex = 0;
        }

        private void LogBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LogBox.ScrollToEnd();
        }
        List<Move> ValidateMove(char[,] newBoard, char[,] oldBoard, char playerLetter)
        {
            List<Move> changes = new List<Move>();
            //validate board
            for (int i = 0; i < newBoard.GetLength(0); i++)
            {
                for (int j = 0; j < newBoard.GetLength(1); j++)
                {
                    if (newBoard[i, j] != EMPTY_CELL && newBoard[i, j] != PLAYER_A_SYMBOL &&
                        newBoard[i, j] != PLAYER_B_SYMBOL)
                    {
                        throw new InvalidDataException("Invalid characters found!");
                    }
                    if (newBoard[i,j]!=oldBoard[i,j])
                    {
                        Move newMove = new Move();
                        newMove.Y = i;
                        newMove.X = j;
                        changes.Add(newMove);
                    }
                }
            }
            //validate number of moves
            if (changes.Count==0)
            {
                throw new Exception("No moves were made!");
            }
            if (changes.Count>3)
            {
                throw new Exception("Too much moves were made!");
            }
            //check for overlapping
            foreach (Move change in changes)
            {
                if (oldBoard[change.Y, change.X]!=EMPTY_CELL &&
                    newBoard[change.Y, change.X] != oldBoard[change.Y, change.X])
                {
                    throw new InvalidOperationException("Move overlapes other moves!");
                }
            }
            if (changes.Count>1)
            {
                int differencX = changes[0].X-changes[1].X;
                int differencY = changes[0].Y-changes[1].Y;
                if (Math.Abs(differencX) > 1 || Math.Abs(differencY) > 1)
                {
                    throw new InvalidOperationException("Move structure is not correct!");
                }
                if (changes.Count == 3)
                {
                    if (changes[1].X-changes[2].X!=differencX ||
                        changes[1].Y - changes[2].Y != differencY)
                    {
                        throw new InvalidOperationException("Move structure is not correct!");
                    }
                }
            }
            return changes;
        }
        void EndGame(char playerLetter, string errorMessage)
        {
            nextMoveButton.IsEnabled = false;
            MessageBox.Show("Player " + playerLetter + " loses!\n" +
                "Reason: " + errorMessage);
            LogBox.Text += "Player " + playerLetter + " disqualified. " +
                "Reason: " + errorMessage + "\n";
        }

    }
}
