﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace _123GameSimulator
{
    static class MoveTimer
    {
        public static void TryMove(ThreadStart functionality, int timeOutInMilliseconds)
        {

            Thread thread = new Thread(delegate()
            {
                try
                {
                    functionality();
                }
                catch (Exception)
                {
                    
                    //throw new Exception("Thread could not be executed due to an unknown error!"); // for some reason this exception is not caught in the MainWindow
                }
            });
            thread.Start();
            if (!thread.Join(timeOutInMilliseconds))
            {
                thread.Abort();
                throw new InvalidOperationException("Move exceeded its time to move!.");
            }
        }
    }
}
