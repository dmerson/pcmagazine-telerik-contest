import java.util.ArrayList;
// import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

public class Zad2_1 {

		/**
		 * @param args
		 */
		public static final int MAXROW = 50;
		public static final int MAXCOL = 50;
		public static final int MAXWORDLENGHT = 30;
		public static final int MAXOFFSET = 10000000;
		public static final int MAXMSEC=19900;
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner input = new Scanner(System.in);
	//		System.out.println("=================================================");
	//		System.out.println("==            ��������� �� �������             ==");
	//		System.out.println("=================================================");
	//		System.out.println("==            �������� ���� ����: W            ==");
	//		System.out.println("=================================================");
			int w = input.nextInt();
			input.nextLine();
	//		System.out.println("=================================================");
	//		System.out.printf("==             �������� %4d ����              ==%n",
	//				w);
	//		System.out.println("=================================================");
			StringBuilder[] wordsArr = new StringBuilder[2*w];
			String tempStr = "";
			for (int i = 0; i < 2*w; i+=2) {
				tempStr = input.nextLine().toUpperCase();
				
				wordsArr[i] = new StringBuilder(tempStr);
				wordsArr[i+1] = new StringBuilder(tempStr);
				wordsArr[i+1].reverse();
			}

	//		for (StringBuilder str : wordsArr) {
	//			System.out.println(str);
	//		}

			
	//		System.out.println("=================================================");
	//		System.out.printf( "==           �������� ���� ���������: L        ==");
	//		System.out.println("=================================================");
			int l = input.nextInt();
			input.nextLine();
	//		System.out.println("=================================================");
	//		System.out.printf("==           �������� %4d ���������           ==%n",l);
	//		System.out.println("=================================================");
		
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < l; i++) {
				sb.append(input.nextLine().replaceAll("[^a-zA-Z�-��-�]", "").toUpperCase());
			}

		// ������� �� ���� � ������
			Date startTime = new Date();
			Date endTime = new Date();
	//		System.out.println(startTime);
			int length = sb.length();
			int offset = 0;
			int c = 0;
			int r = 0;

			ArrayList<String> wordsArrList = new ArrayList<String>();
			ArrayList<Integer> startPosArrList = new ArrayList<Integer>();
			ArrayList<Integer> deltaArrList = new ArrayList<Integer>();

			//Searching for words
			for(int i=0;i<sb.length();i++){						// Elements from all capital letters matrix 
				for(int j=0;j<2*w;j++){							// Elements from the wordsArr[]
					for(int d=1;d<2*MAXCOL;d++){						// Delta offset between consecutive letters
						for(int k=0;k<wordsArr[j].length();k++){	// Letter index from words from wordsArr[]
							if((i+k*d)>=length){break;}
							if(sb.charAt(i+k*d)!=wordsArr[j].charAt(k)){break;}
							if(wordsArr[j].length()==k+1){
								wordsArrList.add(wordsArr[j].toString());
								startPosArrList.add(i);
								deltaArrList.add(d);
								} 
						}
					}
				}
			}
			
	//		endTime = new Date();
	//		System.out.printf("Searching for words: %d msec%n",endTime.getTime()-startTime.getTime());
			
			//Print results from Array Lists : "word position delta"
	//		for(int i=0;i<wordsArrList.size();i++){
	//			System.out.printf("%10s i=%10d d=%10d %n",
	//					wordsArrList.get(i) ,startPosArrList.get(i) ,deltaArrList.get(i));
	//		}
			//Sort the results from Array List
			// First on words length second on alphabetical order third on delta 
			for(int i=0;i<wordsArrList.size();i++){
				for(int j=i;j<wordsArrList.size();j++){
					if(wordsArrList.get(j).length() > wordsArrList.get(i).length()){
				    		Collections.swap(wordsArrList, i, j);
				    		Collections.swap(startPosArrList, i, j);
				    		Collections.swap(deltaArrList, i, j);
					}
					else if((wordsArrList.get(j).length() == wordsArrList.get(i).length())&&
							wordsArrList.get(j).compareTo(wordsArrList.get(i))<0){
								Collections.swap(wordsArrList, i, j);
								Collections.swap(startPosArrList, i, j);
								Collections.swap(deltaArrList, i, j);
					}
					else if(((wordsArrList.get(j).length() == wordsArrList.get(i).length())&&
							wordsArrList.get(j).compareTo(wordsArrList.get(i))==0)&&
							deltaArrList.get(j)>deltaArrList.get(i)){
								Collections.swap(wordsArrList, i, j);
								Collections.swap(startPosArrList, i, j);
								Collections.swap(deltaArrList, i, j);
					}
				}
			}
			
	//		endTime = new Date();
	//		System.out.printf("Sort the results from Array List: %d msec%n",endTime.getTime()-startTime.getTime());
			
			//Print sorted results from Array Lists : "word position delta"
	//		for(int i=0;i<wordsArrList.size();i++){
	//			System.out.printf("%10s i=%10d d=%10d %n",
	//					wordsArrList.get(i) ,startPosArrList.get(i) ,deltaArrList.get(i));
	//		}
			// Compute the value for c
			String lastWord="";
			int sum=0;
			int cnt=0;
			for(int i=0;i<wordsArrList.size();i++){
				if(wordsArrList.get(i).compareTo(lastWord)!=0&&
						wordsArrList.get(i).length()>2){sum+=deltaArrList.get(i);cnt++;lastWord=wordsArrList.get(i);}
			}
			c=sum/cnt+1;
			if(c>MAXCOL)c=MAXCOL;
			
	//		endTime = new Date();
	//		System.out.printf("Compute the value for c: %d msec%n",endTime.getTime()-startTime.getTime());
			
	//		System.out.printf("sum=%d cnt=%d c=%d %n", sum,cnt,c);
			
			// Compute start and stop searching position
			int startPos =length;
			int stopPos = 0;
			int wordEndPos = 0;
			for(int i=0;i<wordsArrList.size();i++){
				if(wordsArrList.get(i).length()>2 && 
						startPosArrList.get(i)<startPos){startPos=startPosArrList.get(i);}
				wordEndPos = startPosArrList.get(i)+ (wordsArrList.get(i).length()-1)* deltaArrList.get(i);
				if(wordsArrList.get(i).length()>2 && 
						wordEndPos>stopPos){stopPos=wordEndPos;}
			}
			
	//		endTime = new Date();
	//		System.out.printf("Compute start and stop searching position: %d msec%n",endTime.getTime()-startTime.getTime());
			
	//		System.out.printf("startPos=%d stopPos=%d %n", startPos,stopPos);
			
			//Searching for words in different possible matrices
			r =(length-offset)/c;
			if(r>MAXROW)r=MAXROW;
			int[] arrCnt = new int[2*w];	// Every element will count the number of findings for every word in wordsArr[]
			int[] arrCntFound = new int[2*w];	//Found copy of arrCnt
			
			int wordsFound=0;
			int wordsFoundMax=0;
			int offsetFound=0;
		//	int startRowTemp = 0;
		//	int startColTemp = 0;
		//	int wordsArrLengthTemp = 0;
			for(offset=0;offset<=startPos;offset+=c/2){
		//		System.out.printf("offset=%d%n", offset);
				for(int i=startPos;i<stopPos;i++){						// Elements from letter matrix 	
					for(int j=0;j<2*w;j++){							    // Elements from the wordsArr[]
					//	if (arrCnt[j]>0)break;
					//	wordsArrLengthTemp = wordsArr[j].length();
						for(int d=1;d<=2*c;d++){					// Delta offset between consecutive letters
							for(int k=0;k<wordsArr[j].length();k++){	// Letters from j-th word from wordsArr[]
								if((i+k*d)>=stopPos){break;}
								if(sb.charAt(i+k*d)!=wordsArr[j].charAt(k)){break;}
							//	startRowTemp = (i-offset)/c;
							//	startColTemp = (i-offset)%c;
								if(wordsArr[j].length()==k+1 && (i-offset)/c >=0 && (i-offset)/c <=r  &&
										(i-offset)%c >=0 && (i-offset)%c <=c &&
										ruleType1(r,c,d,wordsArr[j].length(),(i-offset)/c,(i-offset)%c)>0 ){
							//		System.out.print("FOUND: ");
							//		System.out.printf("i=%d d=%d %s rule=%s - ",i+1,d,wordsArr[j],
							//				ruleType(r,c,d,wordsArr[j].length()));
							//		System.out.printf("i=%d d=%d %s rule=%s - ",i+1,d,wordsArr[j],
							//				ruleType1(r,c,d,wordsArr[j].length(),startRowTemp,startColTemp));
							//		System.out.printf("startRow=%d startCol=%d%n", startRowTemp+1,startColTemp+1);
									arrCnt[j]++;}
							}
						}
					}
				}
		//		System.out.println(Arrays.toString(arrCnt));
				for(int i=0;i<2*w;i+=2){	
					if(arrCnt[i]>0||arrCnt[i+1]>0)wordsFound++; 
					} 
		//		System.out.printf("wordsFound=%d%n", wordsFound);
				if(wordsFoundMax<wordsFound){
					wordsFoundMax=wordsFound;
					offsetFound=offset;
					System.arraycopy(arrCnt, 0, arrCntFound, 0, 2*w);
					}
				wordsFound=0;
				for(int i=0;i<2*w;i++){arrCnt[i]=0;}
		//		System.out.printf("wordsFoundMax=%d %n", wordsFoundMax);
		//		printMatrix(r,c,offset,length,sb);
		
				if(wordsFoundMax==w)break;
				endTime = new Date();
//				System.out.printf("Laps Time: %d msec%n",endTime.getTime()-startTime.getTime());
				if(endTime.getTime()-startTime.getTime()>MAXMSEC)break;
			}
			endTime = new Date();
		//	System.out.printf("Time for searching: %d msec%n",endTime.getTime()-startTime.getTime());
		// ���� �� ��������� �� ���� � ������	
			
			if(offsetFound>MAXOFFSET)offsetFound=MAXOFFSET;
			printMatrix(r,c,offsetFound,length,sb);
		//	System.out.printf("wordsFoundMax=%d %n", wordsFoundMax);
			System.out.printf("%d%n", wordsFoundMax);
		//	System.out.println(Arrays.toString(arrCntFound));
			// Found words positions
			offset=offsetFound;
			int rowStepTemp=0;
			int colStepTemp=0;
			for(int i=startPos;i<stopPos;i++){						// Elements from all capital letters matrix 	
				for(int j=0;j<2*w;j++){							// Elements from the wordsArr[]
					for(int d=1;d<=2*MAXCOL;d++){						// Delta offset between consecutive letters
						for(int k=0;k<wordsArr[j].length();k++){	// Letters from j-th word from wordsArr[]
							if((i+k*d)>=length){break;}
							if(sb.charAt(i+k*d)!=wordsArr[j].charAt(k)){break;}
							if(wordsArr[j].length()==k+1 && 
									ruleType1(r,c,d,wordsArr[j].length(),(i-offset)/c,(i-offset)%c)>0 ){
		//						System.out.print("FOUND: ");
		//						System.out.printf("i=%d d=%d %s rule=%s - ",i+1,d,wordsArr[j],
		//								ruleType(r,c,d,wordsArr[j].length()));
		//						System.out.printf("i=%d d=%d %s rule=%s - ",i+1,d,wordsArr[j],
		//								ruleType1(r,c,d,wordsArr[j].length(),(i-offset)/c,(i-offset)%c));
								if(arrCntFound[j]>0)
								{
									rowStepTemp = rowStep(r,c,d,wordsArr[j].length(),(i-offset)/c,(i-offset)%c,j);
									colStepTemp = colStep(r,c,d,wordsArr[j].length(),(i-offset)/c,(i-offset)%c,j);
								
									if (j%2==0)System.out.printf("%s ",wordsArr[j].toString().toLowerCase());
									else System.out.printf("%s ",wordsArr[j-1].toString().toLowerCase());
								
		//							if(j%2==0){System.out.printf("startRow=%d startCol=%d ", (i-offset)/c+1,(i-offset)%c+1);}
		//							else{System.out.printf("startRow=%d startCol=%d ", (i-offset)/c+1 - rowStepTemp*(wordsArr[j].length()-1),
		//									(i-offset)%c+1 - colStepTemp*(wordsArr[j].length()-1)       );}
								
									if(j%2==0){System.out.printf("%d %d ", (i-offset)/c+1,(i-offset)%c+1);}
									else{System.out.printf("%d %d ", (i-offset)/c+1 - rowStepTemp*(wordsArr[j].length()-1),
											(i-offset)%c+1 - colStepTemp*(wordsArr[j].length()-1)       );}
								
		//							System.out.printf("RowStep=%d ColStep=%d%n",rowStepTemp,colStepTemp);
									System.out.printf("%d %d%n",rowStepTemp,colStepTemp);
									arrCntFound[j]=0;
									if(j%2==0)arrCntFound[j+1]=0;else arrCntFound[j-1]=0;
								}
								
								}
						}
					}
				}
			}
			
			

		}
		public static void printMatrix(int r, int c, int offset, int length, StringBuilder sb){
	//		System.out.println("=================================================");
	//		System.out.println("==                ������� �����:               ==");
	//		System.out.println("=================================================");
			System.out.printf("%d %d %d%n",offset+1,r,c );
	//		System.out.println("          00000000011111111112222222222333333333344444444445");
	//		System.out.println("          12345678901234567890123456789012345678901234567890");
	//		System.out.printf("%4d %4d %s%n",0,1,sb.substring(0,offset));
			int maxRow = (length-offset)/c;
			if (maxRow>MAXROW)maxRow=MAXROW; 
			for(int row=0;row<maxRow;row++){
	//			System.out.printf("%4d %4d %s%n",row+1,row*c+offset+1,sb.substring(offset+row*c, offset+row*c+c));
				System.out.printf("%s%n",sb.substring(offset+row*c, offset+row*c+c));
			}
	//		System.out.printf("%4d %4d %s%n",(length-offset)/c+1,((length-offset)/c)*c+offset+1,sb.substring(((length-offset)/c)*c+offset));
						
		}
		public static String ruleType(int r,int c,int d,int wordLenght){
			String rule = "unknown";
			if(d<=2*c){
				if((d==c)&&(wordLenght<=r)){rule="vertical";}
				else if((d<c)&&((wordLenght-1)*d<=c)){rule="horizontal";}
				else if(Math.abs(d-c)>0&&(((wordLenght-1)*Math.abs(d-c))<=c)){rule="diagonal";}
			}
			return rule;
		}
		public static int ruleType1(int r,int c,int d,int wordLenght,int startRow,int startCol){
			int rule = -1;
			if(d<=2*c){
				if((d==c)&&(wordLenght-1+startRow<=r)){rule=1;}	// pure vertical
				else if((d<c)&&((wordLenght-1)*d+startCol<=c)){rule=2;}	 //pure horizontal
				else if((d>c)&&(((wordLenght-1)*(d-c)+startCol)<=c)&&
						((wordLenght-1+startRow)<=r)){rule=3;}	//diagonal pointing to the bottom right angle of the matrix
				else if((d<c)&& (wordLenght*(c-d)<=startCol)&&
						((wordLenght-1+startRow)<=r)){rule=4;}	//diagonal pointing to the bottom left angle of the matrix
			}
			return rule;
		}
		public static int rowStep(int r,int c,int d,int wordLenght,int startRow,int startCol,int wordIdx){
			int rowStep=0;
			if((d==c)&&(wordLenght-1+startRow<=r)){if (wordIdx%2==0) rowStep=1; else rowStep=-1;}	// pure vertical
			else if((d<c)&&((wordLenght-1)*d+startCol<=c)){rowStep=0;}	 //pure horizontal
			else if((d>c)&&(((wordLenght-1)*(d-c)+startCol)<=c)&&
					((wordLenght-1+startRow)<=r)){if (wordIdx%2==0) rowStep=1; else rowStep=-1;}	//diagonal pointing to the bottom right angle of the matrix
			else if((d<c)&& (wordLenght*(c-d)<=startCol)&&
					((wordLenght-1+startRow)<=r)){if (wordIdx%2==0) rowStep=1; else rowStep=-1;}	//diagonal pointing to the bottom left angle of the matrix
			return rowStep;
		}
		public static int colStep(int r,int c,int d,int wordLenght,int startRow,int startCol,int wordIdx){
			int colStep=0;
			if((d==c)&&(wordLenght-1+startRow<=r)){colStep=0;}	// pure vertical
			else if((d<c)&&((wordLenght-1)*d+startCol<=c)){if (wordIdx%2==0) colStep=d; else colStep=-d;}	 //pure horizontal
			else if((d>c)&&(((wordLenght-1)*(d-c)+startCol)<=c)&&
					((wordLenght-1+startRow)<=r)){if (wordIdx%2==0) colStep=d-c; else colStep=c-d;}	//diagonal pointing to the bottom right angle of the matrix
			else if((d<c)&& (wordLenght*(c-d)<=startCol)&&
					((wordLenght-1+startRow)<=r)){if (wordIdx%2==0) colStep=d-c; else colStep=c-d;}	//diagonal pointing to the bottom left angle of the matrix
			return colStep;
		}
	}
