﻿namespace TelerikSimulator
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponents()
        {
            int fieldSize=32;
            if(gameVariables.n > gameVariables.m) fieldSize=400/(gameVariables.n+1);
            else fieldSize = 280 / (gameVariables.m+1);
            for (int i = 0; i < gameVariables.n; i++)
            {
                for (int j = 0; j < gameVariables.m; j++)
                {
                    boardLabels[i, j] = new System.Windows.Forms.Label();
                    boardLabels[i, j].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                    boardLabels[i, j].BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                    boardLabels[i, j].Font = new System.Drawing.Font("Microsoft Sans Serif", fieldSize/2, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                    boardLabels[i, j].Location = new System.Drawing.Point((450-gameVariables.n*fieldSize)/2+i * fieldSize,20+(300-gameVariables.m*fieldSize)/2+j * fieldSize);
                    boardLabels[i, j].Name = "board" + i + j;
                    boardLabels[i, j].Size = new System.Drawing.Size(fieldSize, fieldSize);
                    boardLabels[i, j].TabIndex = 6;
                    boardLabels[i, j].Text = " ";
                    boardLabels[i, j].BackColor = System.Drawing.Color.White;
                    this.Controls.Add(boardLabels[i, j]);
                    if (i == 0)
                    {
                        boardNamesLabels[j] = new System.Windows.Forms.Label();
                        boardNamesLabels[j].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                        boardNamesLabels[j].ForeColor = System.Drawing.Color.Honeydew;
                        boardNamesLabels[j].Font = new System.Drawing.Font("Microsoft Sans Serif", fieldSize / 2, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                        boardNamesLabels[j].Location = new System.Drawing.Point((450 - gameVariables.n * fieldSize) / 2 + i * fieldSize - fieldSize *5/6, 20 + (300 - gameVariables.m * fieldSize) / 2 + j * fieldSize);
                        boardNamesLabels[j].Name = "boardName" + i + j;
                        boardNamesLabels[j].Size = new System.Drawing.Size(fieldSize, fieldSize);
                        boardNamesLabels[j].TabIndex = 6;
                        boardNamesLabels[j].Text = ((char)('A'+j)).ToString();
                        this.Controls.Add(boardNamesLabels[j]);
                    }
                    if (j == gameVariables.m-1)
                    {
                        boardNamesLabels[j + i] = new System.Windows.Forms.Label();
                        boardNamesLabels[j + i].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                        boardNamesLabels[j + i].ForeColor = System.Drawing.Color.Honeydew;
                        boardNamesLabels[j + i].Font = new System.Drawing.Font("Microsoft Sans Serif", fieldSize / 2, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                        boardNamesLabels[j + i].Location = new System.Drawing.Point((450 - gameVariables.n * fieldSize) / 2 + i * fieldSize, 20 + (300 - gameVariables.m * fieldSize) / 2 + j * fieldSize + fieldSize * 5 / 6);
                        boardNamesLabels[j + i].Name = "boardName" + i + j;
                        boardNamesLabels[j + i].Size = new System.Drawing.Size(fieldSize, fieldSize);
                        boardNamesLabels[j + i].TabIndex = 6;
                        boardNamesLabels[j + i].Text = ((char)('a' + i)).ToString();
                        this.Controls.Add(boardNamesLabels[j + i]);
                    }
                }
            }
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.turnsBox = new System.Windows.Forms.ListBox();
            this.messageBox = new System.Windows.Forms.TextBox();
            this.autoplayCheckbox = new System.Windows.Forms.CheckBox();
            this.nextMoveButton = new System.Windows.Forms.Button();
            this.newGame = new System.Windows.Forms.Button();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.resultButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // turnsBox
            // 
            this.turnsBox.BackColor = System.Drawing.Color.Honeydew;
            this.turnsBox.FormattingEnabled = true;
            this.turnsBox.Location = new System.Drawing.Point(437, 58);
            this.turnsBox.Name = "turnsBox";
            this.turnsBox.Size = new System.Drawing.Size(99, 251);
            this.turnsBox.TabIndex = 1;
            this.turnsBox.SelectedIndexChanged += new System.EventHandler(this.turnsBox_SelectedIndexChanged);
            // 
            // messageBox
            // 
            this.messageBox.BackColor = System.Drawing.Color.Honeydew;
            this.messageBox.Location = new System.Drawing.Point(9, 327);
            this.messageBox.Multiline = true;
            this.messageBox.Name = "messageBox";
            this.messageBox.ReadOnly = true;
            this.messageBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.messageBox.Size = new System.Drawing.Size(415, 112);
            this.messageBox.TabIndex = 10;
            // 
            // autoplayCheckbox
            // 
            this.autoplayCheckbox.AutoSize = true;
            this.autoplayCheckbox.Location = new System.Drawing.Point(449, 329);
            this.autoplayCheckbox.Name = "autoplayCheckbox";
            this.autoplayCheckbox.Size = new System.Drawing.Size(67, 17);
            this.autoplayCheckbox.TabIndex = 2;
            this.autoplayCheckbox.Text = "Autoplay";
            this.autoplayCheckbox.UseVisualStyleBackColor = true;
            this.autoplayCheckbox.CheckedChanged += new System.EventHandler(this.autoplayCheckbox_CheckedChanged);
            // 
            // nextMoveButton
            // 
            this.nextMoveButton.Location = new System.Drawing.Point(449, 352);
            this.nextMoveButton.Name = "nextMoveButton";
            this.nextMoveButton.Size = new System.Drawing.Size(87, 23);
            this.nextMoveButton.TabIndex = 3;
            this.nextMoveButton.Text = "Next Turn";
            this.nextMoveButton.UseVisualStyleBackColor = true;
            this.nextMoveButton.Click += new System.EventHandler(this.nextMoveButton_Click);
            // 
            // newGame
            // 
            this.newGame.Location = new System.Drawing.Point(449, 410);
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(87, 26);
            this.newGame.TabIndex = 5;
            this.newGame.Text = "New Board";
            this.newGame.UseVisualStyleBackColor = true;
            this.newGame.Click += new System.EventHandler(this.newGame_Click);
            // 
            // scoreLabel
            // 
            this.scoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.scoreLabel.Location = new System.Drawing.Point(12, 9);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(434, 24);
            this.scoreLabel.TabIndex = 0;
            this.scoreLabel.Text = "Player A    0:0     Player B";
            this.scoreLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(469, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Turns:";
            // 
            // resultButton
            // 
            this.resultButton.Location = new System.Drawing.Point(449, 381);
            this.resultButton.Name = "resultButton";
            this.resultButton.Size = new System.Drawing.Size(87, 23);
            this.resultButton.TabIndex = 4;
            this.resultButton.Text = "Result";
            this.resultButton.UseVisualStyleBackColor = true;
            this.resultButton.Click += new System.EventHandler(this.resultButton_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(548, 451);
            this.Controls.Add(this.resultButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.newGame);
            this.Controls.Add(this.nextMoveButton);
            this.Controls.Add(this.autoplayCheckbox);
            this.Controls.Add(this.messageBox);
            this.Controls.Add(this.turnsBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simulator";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox turnsBox;
        private System.Windows.Forms.TextBox messageBox;
        private System.Windows.Forms.CheckBox autoplayCheckbox;
        private System.Windows.Forms.Button nextMoveButton;
        private System.Windows.Forms.Button newGame;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Label[,] boardLabels = new System.Windows.Forms.Label[gameVariables.n, gameVariables.m];
        private System.Windows.Forms.Label[] boardNamesLabels = new System.Windows.Forms.Label[gameVariables.n + gameVariables.m];
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button resultButton;

    }
}