﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace TelerikSimulator
{
    public partial class mainForm : Form
    {
        private bool showResult;
        public mainForm()
        {
            InitializeComponent();
            InitializeComponents();
        }
        private void WrongOutput(string reason)
        {
            if (reason == "") reason = " No reason shown";
            char otherPlayer = gameVariables.toMove == 'A' ? 'B' : 'A';
            messageBox.Text += "Wrong output from player " + gameVariables.toMove + "! Reason: "+ reason + Environment.NewLine;
            messageBox.Text += "Player " + otherPlayer + " wins!";
            this.messageBox.SelectionStart = messageBox.Text.Length;
            this.messageBox.ScrollToCaret();
            showResult = false;
            DrawState(gameVariables.gameStates.Last());
        }
        private string GetTurnName(Point[] changes, int size)
        {
            string turnName = "";
            turnName += ((char)('A' + changes[0].y)).ToString() + ((char)('a' + changes[0].x)).ToString() + " ";
            if (size > 1) turnName += ((char)('A' + changes[1].y)).ToString() + ((char)('a' + changes[1].x)).ToString() + " ";
            if (size > 2) turnName += ((char)('A' + changes[2].y)).ToString() + ((char)('a' + changes[2].x)).ToString() + " ";
            return turnName;
        }
        private void AddNewTurn(Point[] changes,int size)
        {
            gameVariables.gameStates.Add(new gameState(gameVariables.board));
            if (size > 0)
            {
                turnsBox.Items.Add(turnsBox.Items.Count + ": "+GetTurnName(changes,size));
            }
            else turnsBox.Items.Add("Start");
        }
        public void DrawState(gameState gs)
        {
            if (showResult) return;
            for (int i = 0; i < gameVariables.n; i++)
            {
                for (int j = 0; j < gameVariables.m; j++)
                {
                    if (gs.board[i, j] == '-')
                    {
                        boardLabels[i, j].BackColor = gameVariables.emptyColor;
                        boardLabels[i, j].Text = " ";
                    }
                    if (gs.board[i, j] == 'a')
                    {
                        boardLabels[i, j].BackColor = gameVariables.playerAColorSpecial;
                        boardLabels[i, j].ForeColor = gameVariables.emptyColor;
                        boardLabels[i, j].Text = "A";
                    }
                    if (gs.board[i, j] == 'A')
                    {
                        boardLabels[i, j].BackColor = gameVariables.playerAColorNormal;
                        boardLabels[i, j].ForeColor = gameVariables.fullColor;
                        boardLabels[i, j].Text = "A";
                    }
                    if (gs.board[i, j] == 'b')
                    {
                        boardLabels[i, j].BackColor = gameVariables.playerBColorSpecial;
                        boardLabels[i, j].ForeColor = gameVariables.emptyColor;
                        boardLabels[i, j].Text = "B";
                    }
                    if (gs.board[i, j] == 'B')
                    {
                        boardLabels[i, j].BackColor = gameVariables.playerBColorNormal;
                        boardLabels[i, j].ForeColor = gameVariables.fullColor;
                        boardLabels[i, j].Text = "B";
                    }
                }
                scoreLabel.Text = "Player A    " + gs.playerAPoints + ":" + gs.playerBPoints + "     Player B";
            }
        }
        private bool CheckPoints(Point[] changes,int size)
        {
            if (size == 1) return true;
            if (size == 2)
            {
                if (((Math.Abs(changes[0].x - changes[1].x) == 2) && ((Math.Abs(changes[0].y - changes[1].y) == 2) || (Math.Abs(changes[0].y - changes[1].y) == 0))) || ((Math.Abs(changes[0].y - changes[1].y) == 2) && ((Math.Abs(changes[0].x - changes[1].x) == 2) || (Math.Abs(changes[0].x - changes[1].x) == 0))))
                {
                    if (gameVariables.board[changes[0].x - (changes[0].x - changes[1].x) / 2, changes[0].y - (changes[0].y - changes[1].y) / 2] == gameVariables.toMove) return true;
                    return false;
                }
                if ((Math.Abs(changes[0].x - changes[1].x) <=2) && (Math.Abs(changes[0].y - changes[1].y) <=2)) return true;
                return false;
            }
            if ((Math.Abs(changes[0].x - changes[1].x) <= 1) && (Math.Abs(changes[0].y - changes[1].y) <= 1) && (Math.Abs(changes[1].x - changes[2].x) <= 1) && (Math.Abs(changes[1].y - changes[2].y) <= 1))
            {
                return true;
            }
            else return false;
        }
        private void mainForm_Load(object sender, EventArgs e)
        {
            if (gameVariables.n == 0) this.Close();
            gameVariables.board = new char[gameVariables.n, gameVariables.m];
            gameVariables.toMove = 'A';
            gameVariables.autoplay = new System.Windows.Forms.Timer();
            gameVariables.autoplay.Interval = 1500;
            gameVariables.autoplay.Tick += new EventHandler(autoplay_Tick);
            for (int i = 0; i < gameVariables.n; i++)
            {
                for (int j = 0; j < gameVariables.m; j++)
                {
                    gameVariables.board[i, j] = '-';
                }
            }
            AddNewTurn(new Point[0],0);
            messageBox.Text += "Press \"Next Turn\" for next move, \"Result\" for instant result or press \"Autoplay\"!" + Environment.NewLine;
            messageBox.Text += "Player " + gameVariables.toMove + " to move..." + Environment.NewLine;
        }

        void autoplay_Tick(object sender, EventArgs e)
        {
            gameVariables.autoplay.Stop();
            nextMoveButton.PerformClick();
        }

        private void turnsBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListBox lb = sender as ListBox;
            if (lb.SelectedIndex < 0) return;
            DrawState(gameVariables.gameStates[lb.SelectedIndex]);
        }

        private void nextMoveButton_Click(object sender, EventArgs e)
        {
            //DrawState(gameVariables.gameStates[gameVariables.gameStates.Count-1]);
            if (gameVariables.autoplay.Enabled)
            {
                autoplayCheckbox.Checked = false;
            }
            nextMoveButton.Enabled = false;
            resultButton.Enabled = false;
            //This is where the code for running the app will be
            Process getanswer = new Process();
            if(gameVariables.toMove=='A') getanswer.StartInfo.FileName = gameVariables.playerAFilename;
            else getanswer.StartInfo.FileName = gameVariables.playerBFilename;
            getanswer.StartInfo.RedirectStandardOutput = true;
            getanswer.StartInfo.RedirectStandardInput = true;
            getanswer.StartInfo.UseShellExecute = false;
            getanswer.StartInfo.ErrorDialog = false;
            getanswer.StartInfo.CreateNoWindow = true;
            string input = "";
            input += gameVariables.n + " " + gameVariables.m + Environment.NewLine;
            for (int i = 1; i <= gameVariables.m; i++)
            {
                for (int j = 0; j < gameVariables.n; j++)
                {
                    input += gameVariables.board[j, i - 1];
                }
                input += Environment.NewLine;
            }
            input += gameVariables.toMove.ToString() + Environment.NewLine;
            try
            {
                getanswer.Start();
            }
            catch
            {
                WrongOutput("Wrong executable file!");
                return;
            }
            System.IO.StreamWriter myStreamWrite = getanswer.StandardInput;
            System.IO.StreamReader myStreamReader = getanswer.StandardOutput;
            myStreamWrite.Write(input);
            myStreamWrite.Close();
            getanswer.WaitForExit(1000);
            if (!getanswer.HasExited)
            {
                if (!getanswer.CloseMainWindow()) getanswer.Kill();
                WrongOutput("Time limit exceeded");
                return;
            }
            string readStream = myStreamReader.ReadToEnd();
            string[] lines = readStream.Split('\n');
            if (lines.Length == 0)
            {
                WrongOutput("Empty File");
                return;
            }
            if (lines.Length <= 2)
            {
                if (lines[0] == "error")
                {
                    char otherPlayer = gameVariables.toMove == 'A' ? 'B' : 'A';
                    scoreLabel.Text = "Player " + otherPlayer + " wins!";
                    messageBox.Text += "Player " + gameVariables.toMove + " returned an error: ";
                    if (lines.Length == 2) messageBox.Text += "\"" + lines[1] + "\"" + Environment.NewLine;
                    else messageBox.Text += "No reason shown" + Environment.NewLine;
                    this.messageBox.SelectionStart = messageBox.Text.Length;
                    this.messageBox.ScrollToCaret();
                    return;
                }
                else
                {
                    WrongOutput("Wrong error message shown");
                    return;
                }
            }
            if (lines.Length != gameVariables.m && gameVariables.m + 1 != lines.Length)
            {
                WrongOutput("Wrong number of lines");
                return;
            }
            if (gameVariables.m + 1 == lines.Length && lines[gameVariables.m] != "")
            {
                WrongOutput("Wrong number of lines");
                return;
            }
            int foundChanges = 0;
            Point[] changes = new Point[3];
            for (int i = 0; i < gameVariables.m; i++)
            {
                if (lines[i].Length != gameVariables.n && lines[i].Length != gameVariables.n + 1)
                {
                    WrongOutput("Wrong number of characters on line");
                    return;
                }
                if (lines[i].Length == (gameVariables.n + 1) && lines[i][gameVariables.n] > 32)
                {
                    WrongOutput("Wrong number of characters on line");
                    return;
                }
                for (int j = 0; j < gameVariables.n; j++)
                {
                    if (gameVariables.board[j, i] != lines[i][j])
                    {
                        if (gameVariables.board[j, i] != '-')
                        {
                            WrongOutput("Player has changed a filled field");
                            return;
                        }
                        if (gameVariables.board[j, i] == '-')
                        {
                            if (lines[i][j] == gameVariables.toMove)
                            {
                                if (foundChanges == 3)
                                {
                                    WrongOutput("Player has changed more than 3 cells");
                                    return;
                                }
                                else
                                {
                                    changes[foundChanges++] = new Point(j, i);
                                }
                            }
                            else
                            {
                                WrongOutput("Player has played other player's letter");
                                return;
                            }
                        }
                    }
                }
            }
            if (foundChanges == 0)
            {
                WrongOutput("Player hasn't played a move");
                return;
            }
            if (CheckPoints(changes, foundChanges))
            {
                messageBox.Text += "Player " + gameVariables.toMove + " move accepted: " + GetTurnName(changes, foundChanges) + Environment.NewLine;
                for (int i = 0; i < foundChanges; i++)
                {
                    gameVariables.board[changes[i].x, changes[i].y] = gameVariables.toMove.ToString().ToLower()[0];
                }
                AddNewTurn(changes, foundChanges);
                for (int i = 0; i < foundChanges; i++)
                {
                    gameVariables.board[changes[i].x, changes[i].y] = gameVariables.toMove;
                }
                gameVariables.toMove = gameVariables.toMove == 'A' ? 'B' : 'A';
                turnsBox.SelectedIndex = turnsBox.Items.Count - 1;
                if (gameVariables.gameStates[gameVariables.gameStates.Count - 1].playerAPoints + gameVariables.gameStates[gameVariables.gameStates.Count - 1].playerBPoints == gameVariables.n * gameVariables.m)
                {
                    gameState gs = gameVariables.gameStates[gameVariables.gameStates.Count - 1];
                    if (gs.playerAPoints > gs.playerBPoints) messageBox.Text += "Player A has won!" + Environment.NewLine + "Simulation has ended.";
                    if (gs.playerAPoints < gs.playerBPoints) messageBox.Text += "Player B has won!" + Environment.NewLine + "Simulation has ended.";
                    if (gs.playerAPoints == gs.playerBPoints) messageBox.Text += "The game has ended in a draw!" + Environment.NewLine + "Simulation has ended.";
                    this.messageBox.SelectionStart = messageBox.Text.Length;
                    this.messageBox.ScrollToCaret();
                    showResult = false;
                    DrawState(gs);
                    return;
                }
                messageBox.Text += "Player " + gameVariables.toMove + " to move..." + Environment.NewLine;
                this.messageBox.SelectionStart = messageBox.Text.Length;
                this.messageBox.ScrollToCaret();
                nextMoveButton.Enabled = true;
                resultButton.Enabled = true;
                if (autoplayCheckbox.Checked)
                {
                    gameVariables.autoplay.Start();
                }
                if (showResult)
                {
                    nextMoveButton.PerformClick();
                }
            }
            else
            {
                WrongOutput("Invalid move played");
                return;
            }
        }
        private void newGame_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Trying a new board will delete your current result. Do you wish to continue?", "New Board", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result.ToString() == "Yes")
            {
                Application.Restart();
            }
        }

        private void autoplayCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (gameVariables.autoplay.Enabled)
            {
                gameVariables.autoplay.Stop();
            }
            else
            {
                gameVariables.autoplay.Start();
            }
        }

        private void resultButton_Click(object sender, EventArgs e)
        {
            autoplayCheckbox.Enabled = false;
            showResult = true;
            nextMoveButton.PerformClick();
        }
    }
}
