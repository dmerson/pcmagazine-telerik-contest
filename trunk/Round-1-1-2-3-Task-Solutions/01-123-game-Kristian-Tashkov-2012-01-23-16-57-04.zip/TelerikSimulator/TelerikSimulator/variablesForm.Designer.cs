﻿namespace TelerikSimulator
{
    partial class variablesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.submitButton = new System.Windows.Forms.Button();
            this.mBox = new System.Windows.Forms.TextBox();
            this.nBox = new System.Windows.Forms.TextBox();
            this.titleLable = new System.Windows.Forms.Label();
            this.nLabel = new System.Windows.Forms.Label();
            this.mLabel = new System.Windows.Forms.Label();
            this.playerAFileLabel = new System.Windows.Forms.Label();
            this.playerAFileButton = new System.Windows.Forms.Button();
            this.playerBFileButton = new System.Windows.Forms.Button();
            this.playerBFileLabel = new System.Windows.Forms.Label();
            this.playerFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.errorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(45, 162);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(150, 59);
            this.submitButton.TabIndex = 1;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // mBox
            // 
            this.mBox.BackColor = System.Drawing.Color.Honeydew;
            this.mBox.Location = new System.Drawing.Point(165, 54);
            this.mBox.MaxLength = 2;
            this.mBox.Name = "mBox";
            this.mBox.Size = new System.Drawing.Size(39, 20);
            this.mBox.TabIndex = 2;
            this.mBox.Text = "4";
            this.mBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nBox
            // 
            this.nBox.BackColor = System.Drawing.Color.Honeydew;
            this.nBox.Location = new System.Drawing.Point(64, 54);
            this.nBox.MaxLength = 2;
            this.nBox.Name = "nBox";
            this.nBox.Size = new System.Drawing.Size(39, 20);
            this.nBox.TabIndex = 2;
            this.nBox.Text = "6";
            this.nBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // titleLable
            // 
            this.titleLable.AutoSize = true;
            this.titleLable.Location = new System.Drawing.Point(12, 26);
            this.titleLable.Name = "titleLable";
            this.titleLable.Size = new System.Drawing.Size(159, 13);
            this.titleLable.TabIndex = 0;
            this.titleLable.Text = "Input variables for current game:";
            // 
            // nLabel
            // 
            this.nLabel.AutoSize = true;
            this.nLabel.Location = new System.Drawing.Point(118, 57);
            this.nLabel.Name = "nLabel";
            this.nLabel.Size = new System.Drawing.Size(41, 13);
            this.nLabel.TabIndex = 4;
            this.nLabel.Text = "Height:";
            // 
            // mLabel
            // 
            this.mLabel.AutoSize = true;
            this.mLabel.Location = new System.Drawing.Point(16, 57);
            this.mLabel.Name = "mLabel";
            this.mLabel.Size = new System.Drawing.Size(38, 13);
            this.mLabel.TabIndex = 5;
            this.mLabel.Text = "Width:";
            // 
            // playerAFileLabel
            // 
            this.playerAFileLabel.AutoSize = true;
            this.playerAFileLabel.Location = new System.Drawing.Point(16, 92);
            this.playerAFileLabel.Name = "playerAFileLabel";
            this.playerAFileLabel.Size = new System.Drawing.Size(68, 13);
            this.playerAFileLabel.TabIndex = 6;
            this.playerAFileLabel.Text = "Player A File:";
            // 
            // playerAFileButton
            // 
            this.playerAFileButton.Location = new System.Drawing.Point(153, 87);
            this.playerAFileButton.Name = "playerAFileButton";
            this.playerAFileButton.Size = new System.Drawing.Size(75, 23);
            this.playerAFileButton.TabIndex = 3;
            this.playerAFileButton.Text = "Browse";
            this.playerAFileButton.UseVisualStyleBackColor = true;
            this.playerAFileButton.Click += new System.EventHandler(this.playerAFileButton_Click);
            // 
            // playerBFileButton
            // 
            this.playerBFileButton.Location = new System.Drawing.Point(153, 117);
            this.playerBFileButton.Name = "playerBFileButton";
            this.playerBFileButton.Size = new System.Drawing.Size(75, 23);
            this.playerBFileButton.TabIndex = 4;
            this.playerBFileButton.Text = "Browse";
            this.playerBFileButton.UseVisualStyleBackColor = true;
            this.playerBFileButton.Click += new System.EventHandler(this.playerBFileButton_Click);
            // 
            // playerBFileLabel
            // 
            this.playerBFileLabel.AutoSize = true;
            this.playerBFileLabel.Location = new System.Drawing.Point(16, 122);
            this.playerBFileLabel.Name = "playerBFileLabel";
            this.playerBFileLabel.Size = new System.Drawing.Size(68, 13);
            this.playerBFileLabel.TabIndex = 8;
            this.playerBFileLabel.Text = "Player B File:";
            // 
            // playerFileDialog
            // 
            this.playerFileDialog.DefaultExt = "exe";
            this.playerFileDialog.Filter = "Executable files|*.exe";
            // 
            // errorLabel
            // 
            this.errorLabel.AutoSize = true;
            this.errorLabel.ForeColor = System.Drawing.Color.Red;
            this.errorLabel.Location = new System.Drawing.Point(12, 7);
            this.errorLabel.Name = "errorLabel";
            this.errorLabel.Size = new System.Drawing.Size(0, 13);
            this.errorLabel.TabIndex = 10;
            // 
            // variablesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(240, 253);
            this.Controls.Add(this.errorLabel);
            this.Controls.Add(this.playerBFileButton);
            this.Controls.Add(this.playerBFileLabel);
            this.Controls.Add(this.playerAFileButton);
            this.Controls.Add(this.playerAFileLabel);
            this.Controls.Add(this.mLabel);
            this.Controls.Add(this.nLabel);
            this.Controls.Add(this.titleLable);
            this.Controls.Add(this.nBox);
            this.Controls.Add(this.mBox);
            this.Controls.Add(this.submitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "variablesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox mBox;
        private System.Windows.Forms.TextBox nBox;
        private System.Windows.Forms.Label titleLable;
        private System.Windows.Forms.Label nLabel;
        private System.Windows.Forms.Label mLabel;
        private System.Windows.Forms.Label playerAFileLabel;
        private System.Windows.Forms.Button playerAFileButton;
        private System.Windows.Forms.Button playerBFileButton;
        private System.Windows.Forms.Label playerBFileLabel;
        private System.Windows.Forms.OpenFileDialog playerFileDialog;
        private System.Windows.Forms.Label errorLabel;

    }
}

