﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TelerikSimulator
{
    static class gameVariables
    {
        public static System.Drawing.Color fullColor = System.Drawing.Color.Black;
        public static System.Drawing.Color emptyColor = System.Drawing.Color.Ivory;
        public static System.Drawing.Color playerAColorNormal = System.Drawing.Color.LightBlue;
        public static System.Drawing.Color playerAColorSpecial = System.Drawing.Color.LightSlateGray;
        public static System.Drawing.Color playerBColorNormal = System.Drawing.Color.Bisque;
        public static System.Drawing.Color playerBColorSpecial = System.Drawing.Color.DarkSalmon;
        public static int n, m;
        public static string playerAFilename,playerBFilename;
        public static char toMove;
        public static char[,] board;
        public static List<gameState> gameStates=new List<gameState>();
        public static List<string> turnsNames = new List<string>();
        public static Timer autoplay;
    }
    public class Point
    {
        public int x,y;
        public Point()
        {
            x=-1;
            y=-1;
        }
        public Point(int x,int y)
        {
            this.x=x;
            this.y=y;
        }
    }
    public class gameState
    {
        public int playerAPoints, playerBPoints;
        public char[,] board;
        public gameState(char [,] board)
        {
            this.board=new char[board.GetLength(0),board.GetLength(1)];
            Array.Copy(board, this.board, board.Length);
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] == 'A' || board[i, j] == 'a') playerAPoints++;
                    if (board[i, j] == 'B' || board[i, j] == 'b') playerBPoints++;
                }
            }
        }
    }
    static class mainCode
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            new variablesForm().ShowDialog();
            Application.Run(new mainForm());
        }
    }
}
