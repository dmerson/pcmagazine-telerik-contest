﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace TelerikSimulator
{
    
    public partial class variablesForm : Form
    {
        public variablesForm()
        {
            InitializeComponent();
            this.playerFileDialog.InitialDirectory = System.IO.Directory.GetCurrentDirectory();
        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            int height=0, width=0;
            try
            {
                height = int.Parse(mBox.Text);
                width = int.Parse(nBox.Text);
            }
            catch
            {
                errorLabel.Text = "Invalid entry data";
            }
            if (height < 3 || height > 20) { errorLabel.Text = "Height must be between 3 and 20"; return; }
            if (width < 3 || width > 20) { errorLabel.Text = "Width must be between 3 and 20"; return; }
            if(!System.IO.File.Exists(gameVariables.playerAFilename)) { errorLabel.Text = "Invalid file for Player A!"; return; }
            if(!System.IO.File.Exists(gameVariables.playerBFilename)) { errorLabel.Text = "Invalid file for Player B!"; return; }
            gameVariables.n = int.Parse(nBox.Text);
            gameVariables.m = int.Parse(mBox.Text);
            this.Close();
        }
        private void playerAFileButton_Click(object sender, EventArgs e)
        {
            if (playerFileDialog.ShowDialog() == DialogResult.OK && playerFileDialog.FileName.Split('.').Last()=="exe")
            {
                string[] filename = playerFileDialog.FileName.Split('\\').ToArray();
                gameVariables.playerAFilename = playerFileDialog.FileName;
                if(filename.Last().Length<20) playerAFileLabel.Text = filename.Last();
                else playerAFileLabel.Text = filename.Last().Substring(0,20)+"...";
            }
            else
            {
                errorLabel.Text = "Invalid file for Player A selected!" + playerFileDialog.FileName.Split('.').Last();
            }
        }

        private void playerBFileButton_Click(object sender, EventArgs e)
        {
            if (playerFileDialog.ShowDialog() == DialogResult.OK && playerFileDialog.FileName.Split('.').Last() == "exe")
            {
                string[] filename = playerFileDialog.FileName.Split('\\').ToArray();
                gameVariables.playerBFilename = playerFileDialog.FileName;
                if (filename.Last().Length < 20) playerBFileLabel.Text = filename.Last();
                else playerBFileLabel.Text = filename.Last().Substring(0, 20) + "...";
            }
            else
            {
                errorLabel.Text = "Invalid file for Player B selected!";
            }
        }
    }
}
