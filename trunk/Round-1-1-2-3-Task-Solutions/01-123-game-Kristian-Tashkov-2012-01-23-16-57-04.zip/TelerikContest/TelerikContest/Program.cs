﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TelerikContest
{
    public class Move
    {
        public Point a, b, c;
        public Move()
        {
            this.a = new Point(-1, -1);
            this.b = new Point(-1, -1);
            this.c = new Point(-1, -1);
        }
        public Move(Point a, Point b, Point c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        public void Print()
        {
            if (this.a != new Point(-1, -1) && this.a != new Point(-2, -2)) Console.Write(this.a.x + ":" + this.a.y + " ");
            if (this.b != new Point(-1, -1) && this.b != new Point(-2, -2)) Console.Write(this.b.x + ":" + this.b.y + " ");
            if (this.c != new Point(-1, -1) && this.c != new Point(-2, -2)) Console.Write(this.c.x + ":" + this.c.y + " ");
            Console.WriteLine();
        }
        public int PointsCount()
        {
            int count=1;
            Point invalid=new Point(-1,-1);
            if (this.b != invalid && this.b!=new Point(-2,-2)) count++;
            if (this.c != invalid && this.c != new Point(-2, -2)) count++;
            return count;
        }
        public bool Compare(Move cmpMove)
        {
            //cmpMove.Print();
            //this.Print();
            //Console.ReadKey();
            if (this.a == new Point(-1, -1) || this.a == new Point(-2, -2)|| this.a == cmpMove.a || this.a == cmpMove.b || this.a == cmpMove.c)
                if (this.b == new Point(-1, -1) || this.b == new Point(-2, -2) || this.b == cmpMove.a || this.b == cmpMove.b || this.b == cmpMove.c)
                    if (this.c == new Point(-1, -1) || this.c == new Point(-2, -2) || this.c == cmpMove.a || this.c == cmpMove.b || this.c == cmpMove.c) return true;
            return false;

        }
        public int freeSpacesCount()
        {
            if (this.PointsCount() != 3) return 0;
            int currentPoints=0;
            Point[] points = new Point[3];
            points[0] = this.a;
            points[1] = this.b;
            points[2] = this.c;
            for (int i = 0; i < 3; i++)
            {
                if (points[i].x - 1 >= 0 && points[i].x + 1 < gameVariables.n && gameVariables.board[points[i].x - 1][points[i].y] == '-' && gameVariables.board[points[i].x + 1][points[i].y] == '-') currentPoints++;
                if (points[i].x - 1 >= 0 && points[i].x + 1 < gameVariables.n && points[i].y - 1 >= 0 && points[i].y + 1 < gameVariables.m && gameVariables.board[points[i].x - 1][points[i].y - 1] == '-' && gameVariables.board[points[i].x + 1][points[i].y + 1] == '-') currentPoints++;
                if (points[i].y - 1 >= 0 && points[i].y + 1 < gameVariables.m && gameVariables.board[points[i].x][points[i].y-1] == '-' && gameVariables.board[points[i].x][points[i].y+1] == '-') currentPoints++;
                if (points[i].x - 1 >= 0 && points[i].x + 1 < gameVariables.n && points[i].y - 1 >= 0 && points[i].y + 1 < gameVariables.m && gameVariables.board[points[i].x + 1][points[i].y - 1] == '-' && gameVariables.board[points[i].x - 1][points[i].y + 1] == '-') currentPoints++;
            }
            currentPoints -= 3;
            return currentPoints;
        }
    }
    static class gameVariables
    {
        public static char toMove;
        public static int n,m;
        public static string[] board= new string[30];
        public static Move bestMove;
    }
    public class Point
    {
        public int x,y;
        public Point(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public static bool operator ==(Point a, Point b)
        {
            // If both are null, or both are same instance, return true.
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            // If one is null, but not both, return false.
            if (((object)a == null) || ((object)b == null))
            {
                return false;
            }

            // Return true if the fields match:
            return a.x == b.x && a.y == b.y;
        }

        public static bool operator !=(Point a, Point b)
        {
            return !(a == b);
        }
        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false.
            if (obj == null)
            {
                return false;
            }

            // If parameter cannot be cast to Point return false.
            Point p = obj as Point;
            if ((System.Object)p == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (x == p.x) && (y == p.y);
        }

        public bool Equals(Point p)
        {
            // If parameter is null return false:
            if ((object)p == null)
            {
                return false;
            }

            // Return true if the fields match:
            return (x == p.x) && (y == p.y);
        }

        public override int GetHashCode()
        {
            return x ^ y;
        }
    }
    class Program
    {
        static int diagonalFirstOrder(Move a, Move b)
        {
            int result = (a.c.x - a.a.x) - (b.c.x - b.a.x);
            if (result > 0) return -1;
            if (result == 0) return 0;
            if (result < 0) return 1;
            return 0;
        }
        static public void playMove(string[] board,Move currentMove, char currentToMove)
        {
            char[] line = new char[30];
            line = board[currentMove.a.x].ToCharArray();
            line[currentMove.a.y] = currentToMove;
            board[currentMove.a.x] = new string(line);
            if (isValid(currentMove.b, board))
            {
                line = board[currentMove.b.x].ToCharArray();
                line[currentMove.b.y] = currentToMove;
                board[currentMove.b.x] = new string(line);
            }

            if (isValid(currentMove.c, board))
            {
                line = board[currentMove.c.x].ToCharArray();
                line[currentMove.c.y] = currentToMove;
                board[currentMove.c.x] = new string(line);
            }
        }
        static public bool isValid(Point a,string[] board)
        {
            if (a.x < 0 || a.y < 0 || a.x >= gameVariables.n || a.y >= gameVariables.m || board[a.x][a.y]!='-') return false;
            return true;
        }
        static public Move GetEyeStructure(int x,int y)
        {
            int side=1,yourMoves=0;
            if (y == 0) side = 1;
            else side = -1;
            for (int i = 0; i < gameVariables.m; i++)
            {
                int step=0;
                if (i % 2 == 0) step = 1;
                else step = 0;
                if (i > 0)
                {
                    if (step == 1 && gameVariables.board[x][y + (i - 1) * side] != gameVariables.toMove) break;
                    if (step == 0 && gameVariables.board[x - 3][y + (i - 1) * side] != gameVariables.toMove) break;
                }
                if (gameVariables.board[x - step][y + side * i] == '-' && gameVariables.board[x - 1 - step][y + i * side] == '-' && gameVariables.board[x - 2 - step][y + i * side] == '-') return new Move(new Point(x - step, y + side * i), new Point(x - step - 1, y + side * i), new Point(x - step - 2, y + side * i));
                yourMoves++;
            }
            for (int j = 0; j < gameVariables.m-3; j += 3)
            {
                if (yourMoves>(j/3+1) && gameVariables.board[x - 4][y + side * j] == '-' && gameVariables.board[x - 4][y + side * (j + 1)] == '-' && gameVariables.board[x - 4][y + side * (j + 2)] == '-') return new Move(new Point(x - 4, y + side * j), new Point(x - 4, y + side * (j + 1)), new Point(x - 4, y + side * (j + 2)));
            }
            return new Move(new Point(-1, -1), new Point(-1, -1), new Point(-1, -1));
        }
        static public Point ifNotValid(Point a,string[] board,char toMove)
        {
            if (a.x < 0 || a.y < 0 || a.x >= gameVariables.n || a.y >= gameVariables.m ) return new Point(-1, -1);
            if (board[a.x][a.y] == toMove) return new Point(-1, -1);
            if (board[a.x][a.y] != '-' && board[a.x][a.y]!=toMove) return new Point(-2, -2);
            return a;
        }
        static public char WhoseWinning(string[] board)
        {
            int aScore=0,bScore=0;
            for (int i = 0; i < gameVariables.n; i++)
            {
                for (int j = 0; j < gameVariables.m; j++)
                {
                    if (board[i][j] == 'A') aScore++;
                    if (board[i][j] == 'B') bScore++;
                    if (board[i][j] == '-') return '0';
                }
            }
            if (aScore > bScore) return 'A';
            if (bScore > aScore) return 'B';
            return '-';
        }
        static public void ReadInput()
        {
            string current = Console.ReadLine();
            string[] contents = current.Split(' ');
            if (contents.Length != 2)
            {
                Console.WriteLine("error");
                Environment.Exit(0);
            }
            try
            {
                gameVariables.n = int.Parse(contents[1]);
                gameVariables.m = int.Parse(contents[0]);
            }
            catch
            {
                Console.WriteLine("error");
                Environment.Exit(0);
            }
            if (gameVariables.n < 3 || gameVariables.m < 3 || gameVariables.n > 20 || gameVariables.m > 20)
            {
                Console.WriteLine("error");
                Environment.Exit(0);
            }
            bool FoundEmpty = false;
            int linesRead = 0;
            current=Console.ReadLine();
            while(current!=null)
            {
                if (linesRead != gameVariables.n)
                {
                    if (current.Length == gameVariables.m)
                    {
                        for (int i = 0; i < current.Length; i++)
                            if (current[i] != 'A' && current[i] != 'B' && current[i] != '-')
                            {
                                Console.WriteLine("error");
                                Environment.Exit(0);
                            }
                        if (current.Contains('-')) FoundEmpty = true;
                        gameVariables.board[linesRead++] = current;
                        current = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("error");
                        Environment.Exit(0);
                    }
                }
                else
                {
                    if (current == "A") gameVariables.toMove = 'A';
                    else
                    {
                        if (current == "B") gameVariables.toMove = 'B';
                        else
                        {
                            Console.WriteLine("error");
                            Environment.Exit(0);
                        }
                    }
                    current = Console.ReadLine();
                }
            }
            if (!FoundEmpty || (gameVariables.toMove!='A' && gameVariables.toMove!='B'))
            {
                Console.WriteLine("error");
                Environment.Exit(0);
            }
        }
        static public void ReadInputFile()
        {
            string[] input = File.ReadAllLines(@"game.in");
            int linesRead = 0;
            bool FoundEmpty = false;
            foreach (var line in input)
            {
                if (gameVariables.n == 0 && gameVariables.m == 0)
                {
                    string[] pieces = line.Split(new string[] { " " }, StringSplitOptions.None);
                    if (pieces.Length != 2)
                    {
                        Console.WriteLine("error");
                        Environment.Exit(0);
                    }
                    else
                    {
                        try
                        {
                            gameVariables.n = int.Parse(pieces[1]);
                            gameVariables.m = int.Parse(pieces[0]);
                        }
                        catch
                        {
                            Console.WriteLine("error");
                            Environment.Exit(0);
                        }
                    }
                    if (input.Length != (gameVariables.n + 2))
                    {
                        Console.WriteLine("error");
                        Environment.Exit(0);
                    }
                }
                else
                {
                    if(linesRead!=gameVariables.n)
                    {
                        if (line.Length != (gameVariables.m))
                        {
                            Console.WriteLine("error");
                            Environment.Exit(0);
                        }
                        for (int i = 0; i < line.Length;i++)
                            if(line[i]!='A' && line[i]!='B' && line[i]!='-')
                            {
                                Console.WriteLine("error");
                                Environment.Exit(0);
                            }
                        if (line.Contains('-')) FoundEmpty = true;
                        gameVariables.board[linesRead++] = line.ToString();
                    }
                    else
                    {
                        if(line=="A") gameVariables.toMove='A';
                        else
                        if(line=="B") gameVariables.toMove='B';
                        else
                        {
                             Console.WriteLine("error");
                             Environment.Exit(0);
                        }
                    }
                }
            }
            if (!FoundEmpty)
            {
                Console.WriteLine("error");
                Environment.Exit(0);
            }
        }
        static double FindBestSolution(string[] currentBoard,char currentToMove)
        {
            List <Move> allMoves= new List<Move>();
            List<Move> specialMoves = new List<Move>();
            int[,] boardMoves=new int[gameVariables.n,gameVariables.m];
            boardMoves.Initialize();
            int maxCount = 0;
            int maxFreeSpaces = -1;
            Move maxFreeSpaceMove = new Move();
            int eyesMovesCount = 0;
            int x = 0,y = 0;
            while (x != gameVariables.n)
            {
                if (currentBoard[x][y] == '-')
                {
                    for (int i = 0; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            if (i == 0 && (j == 0 || j==-1)) continue;
                            Move currentMove = new Move(new Point(x, y), ifNotValid(new Point(x + i * 1, y + j * 1), currentBoard, currentToMove), ifNotValid(new Point(x + i * 2, y + j * 2), currentBoard, currentToMove));
                            bool flag = true;
                            foreach (Move thisMove in allMoves)
                            {
                                if (currentMove.Compare(thisMove))
                                {
                                    flag = false;
                                    break;
                                }
                            }
                            if (flag)
                            {
                                if (currentMove.b != new Point(-2, -2) || currentMove.c == new Point(-2, -2) || currentMove.c == new Point(-1, -1))
                                {
                                    if (currentMove.PointsCount() > maxCount)
                                    {
                                        eyesMovesCount = 0;
                                        allMoves.Clear();
                                        maxCount = currentMove.PointsCount();

                                    }
                                    if (currentMove.PointsCount() == maxCount)
                                    {
                                        if (maxCount == 2 && currentMove.b == new Point(-1, -1)) eyesMovesCount++;
                                        if (maxCount==3 && currentMove.freeSpacesCount() > maxFreeSpaces)
                                        {
                                            maxFreeSpaces = currentMove.freeSpacesCount();
                                            maxFreeSpaceMove = currentMove;
                                        }
                                        if (maxCount == 2)
                                        {
                                            boardMoves[currentMove.a.x, currentMove.a.y]++;
                                            if (isValid(currentMove.b, currentBoard)) boardMoves[currentMove.b.x,currentMove.b.y]++;
                                            if (isValid(currentMove.c, currentBoard)) boardMoves[currentMove.c.x, currentMove.c.y]++;
                                        }
                                        allMoves.Add(currentMove);
                                    }
                                }
                                else
                                {
                                    specialMoves.Add(currentMove);
                                }
                            }
                        }
                    }
                }
                y++;
                if (y == gameVariables.m)
                {
                    y=0;
                    x++;
                }
            }
            if (gameVariables.toMove == currentToMove && allMoves.Count>30 && maxCount==3 && maxFreeSpaces>-1)
            {
                if (gameVariables.n > 6 && gameVariables.m > 4)
                {
                    Move eyesStructure = GetEyeStructure(gameVariables.n - 1, 0);
                    if (eyesStructure.PointsCount() == 3)
                    {
                        gameVariables.bestMove = eyesStructure;
                        return 0;
                    }
                    eyesStructure = GetEyeStructure(gameVariables.n - 1, gameVariables.m - 1);
                    if (eyesStructure.PointsCount() == 3)
                    {
                        gameVariables.bestMove = eyesStructure;
                        return 0;
                    }
                }
                gameVariables.bestMove = maxFreeSpaceMove;
                return 0;
            }
            Move bestMoveFound = new Move();
            double minSuccess = 100.0;
            int successCases = 0;
            if (maxCount != 3)
            {
                for (int i = 0; i < specialMoves.Count; i++)
                    allMoves.Add(specialMoves[i]);
            }
            if (allMoves.Count == 0) return -1;
            bestMoveFound = allMoves[0];
            //allMoves.Sort(diagonalFirstOrder);
            if (gameVariables.toMove != currentToMove && gameVariables.bestMove.PointsCount()==3)
            {
                if (maxCount == 1)
                {
                    return -2;
                }
                if (maxCount == 2)
                {
                    if (eyesMovesCount > specialMoves.Count) return 1.1;
                    if (eyesMovesCount < specialMoves.Count) return -1;
                }
            }
            int maxDestroyed = specialMoves.Count;
            foreach(Move currentMove in allMoves)
            {
                if (currentMove.b == new Point(-2, -2) && currentMove.c != new Point(-2, -2) && currentMove.c != new Point(-1, -1)) continue;
                if (currentToMove == gameVariables.toMove)
                {
                    if (maxCount == 1)
                    {
                        int specialMovesCount = 0;
                        for (int i = 0; i < specialMoves.Count; i++)
                        {
                            if (currentMove.a == specialMoves[i].a || currentMove.a == specialMoves[i].b || currentMove.a == specialMoves[i].c) continue;
                            if (currentMove.b != new Point(-1, -1) && currentMove.b != new Point(-2, -2))
                            {
                                if (currentMove.b == specialMoves[i].a || currentMove.b == specialMoves[i].b || currentMove.b == specialMoves[i].c) continue;
                            }
                            if (currentMove.c != new Point(-1, -1) && currentMove.c != new Point(-2, -2))
                            {
                                if (currentMove.c == specialMoves[i].a || currentMove.c == specialMoves[i].b || currentMove.c == specialMoves[i].c) continue;
                            }
                            if (specialMoves[i].PointsCount() == 2) specialMovesCount++;
                        }
                        if (specialMovesCount < maxDestroyed)
                        {
                            maxDestroyed = specialMovesCount;
                            bestMoveFound = currentMove;
                        }
                    }
                    else
                    {
                        playMove(currentBoard, currentMove, currentToMove);
                        char newToMove;
                        if (currentToMove == 'A') newToMove = 'B';
                        else newToMove = 'A';
                        gameVariables.bestMove = currentMove;
                        //currentMove.Print();
                        double currentSuccess = FindBestSolution(currentBoard, newToMove);
                        //Console.WriteLine(currentSuccess);
                        if (currentSuccess < minSuccess || (currentSuccess==minSuccess && currentMove.b!=new Point(-1,-1)))
                        {
                            minSuccess = currentSuccess;
                            bestMoveFound = currentMove;
                        }
                        Array.Copy(gameVariables.board, currentBoard, gameVariables.n);
                    }
                }
                else
                {
                    int sum = 0;
                    int currentEyesMovesCount = 0;
                    int specialMovesCount = 0;
                    for (int i = 0; i < allMoves.Count; i++)
                    {
                        if (currentMove.b == new Point(-1, -1) && currentMove.c != new Point(-2, -2) && currentMove.c != new Point(-1, -1)) { currentEyesMovesCount++; continue; }
                        if (currentMove.a == allMoves[i].a || currentMove.a == allMoves[i].b || currentMove.a == allMoves[i].c) continue;
                        if (currentMove.b != new Point(-1, -1) && currentMove.b != new Point(-2, -2))
                        {
                            if (currentMove.b == allMoves[i].a || currentMove.b == allMoves[i].b || currentMove.b == allMoves[i].c) continue;
                        }
                        if (currentMove.c != new Point(-1, -1) && currentMove.c != new Point(-2, -2))
                        {
                            if (currentMove.c == allMoves[i].a || currentMove.c == allMoves[i].b || currentMove.c == allMoves[i].c) continue;
                        }
                        if (currentMove.b == new Point(-1, -1)) specialMovesCount++;
                        else sum++;
                    }
                    if (maxCount == 2)
                    {
                        if (sum == 1) return -1;
                        if (sum == 0) return 1.1;
                        if (sum % 2 == 0) successCases++;
                    }
                }
                
            }

            if (currentToMove == gameVariables.toMove)
            {
                gameVariables.bestMove = bestMoveFound;
                return minSuccess;
            }
            else
            {
                return (double) successCases / (allMoves.Count-specialMoves.Count);
            }
        }
        static void Main(string[] args)
        {
            ReadInput();
            //while (true)
            {
                string[] tempboard = new string[30];
                Array.Copy(gameVariables.board, tempboard,gameVariables.n);
                gameVariables.bestMove = new Move(new Point(-1, -1), new Point(-1, -1), new Point(-1, -1));
                FindBestSolution(tempboard, gameVariables.toMove);
                playMove(gameVariables.board, gameVariables.bestMove, gameVariables.toMove);
                for (int i = 0; i < gameVariables.n; i++)
                {
                    Console.WriteLine(gameVariables.board[i]);
                }
                //Console.WriteLine();
                if (gameVariables.toMove == 'A') gameVariables.toMove = 'B';
                else gameVariables.toMove = 'A';
                char result = WhoseWinning(gameVariables.board);
                if (result != '0') 
                {
                    //Console.WriteLine(result);
                    Environment.Exit(0);
                }
            }
        }
    }
}
