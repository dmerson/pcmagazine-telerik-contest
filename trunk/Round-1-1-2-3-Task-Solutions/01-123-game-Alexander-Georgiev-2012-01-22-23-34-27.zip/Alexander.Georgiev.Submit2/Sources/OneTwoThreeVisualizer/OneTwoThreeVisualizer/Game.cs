using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

namespace OneTwoThreeVisualizer
{
    public class Game
    {
        private string tempDirectory;
        private string currentDirectory;

        private int[,] board;
        private int numRows, numCols;

        private int currentPlayer;
        private const int PLAYER_ONE = 1;
        private const int PLAYER_TWO = 2;

        private const int MAX_BOARD_SIZE = 20;
        private const int BOARD_CELL_EMPTY = 1;
        private const int BOARD_CELL_PLAYER_ONE_OLD = 2;
        private const int BOARD_CELL_PLAYER_ONE_NEW = 3;
        private const int BOARD_CELL_PLAYER_TWO_OLD = 4;
        private const int BOARD_CELL_PLAYER_TWO_NEW = 5;

        private const string PLAYER_ONE_EXE = "player1.exe";
        private const string PLAYER_TWO_EXE = "player2.exe";
        private static StringBuilder procOutput;

        public void stop()
        {
            if (Directory.Exists(tempDirectory))
                Directory.Delete(tempDirectory, true);
        }

        private static void ProcOutputHandler(object sendingProcess,
                    DataReceivedEventArgs outLine)
        {
            // Collect the sort command output.
            if (!String.IsNullOrEmpty(outLine.Data))
            {
                // Add the text to the collected output.
                procOutput.Append(outLine.Data);
            }
        }
        
        string createInput()
        {
            StringBuilder sb = new StringBuilder("");
            sb.Append(numCols.ToString() + " " + numRows.ToString() + "\r\n");
            for (int row = 0; row < numRows; row++)
            {
                for (int col = 0; col < numCols; col++)
                {
                    char add = '-';
                    if (board[row, col] / 2 == 1)
                        add = 'A';
                    if (board[row, col] / 2 == 2)
                        add = 'B';
                    sb.Append(add);
                }
                sb.Append("\r\n");
            }
            if (currentPlayer == PLAYER_ONE)
                sb.Append("A\r\n");
            else
                sb.Append("B\r\n");
            return sb.ToString();
        }

        void markMovesAsOld()
        {
            for (int row = 0; row < numRows; row++)
            {
                for (int col = 0; col < numCols; col++)
                {
                    if (board[row, col] == BOARD_CELL_PLAYER_ONE_NEW)
                        board[row, col] = BOARD_CELL_PLAYER_ONE_OLD;
                    if (board[row, col] == BOARD_CELL_PLAYER_TWO_NEW)
                        board[row, col] = BOARD_CELL_PLAYER_TWO_OLD;
                }
            }
        }

        private int validateOutput(string output)
        {
            for (int i = 0; i < (int)output.Length; i++)
                if (output[i] != '\r' && output[i] != '\n' &&
                    output[i] != 'A' && output[i] != 'B' && output[i] != '-')
                    return 0;
            int cnt = 0;
            for (int i = 0; i < (int)output.Length; i++)
                if (output[i] == 'A' || output[i] == 'B' || output[i] == '-') cnt++;
            if (cnt != numRows * numCols) return 0;

            int idx = 0;
            for (int row = 0; row < numRows; row++)
            {
                for (int col = 0; col < numCols; col++)
                {
                    if (idx >= (int)output.Length) return 0;
                    if (output[idx] != 'A' && output[idx] != 'B' && output[idx] != '-')
                        return 0;
                    idx++;
                }
                while (idx < (int)output.Length && output[idx] != 'A' && output[idx] != 'B' && output[idx] != '-')
                    idx++;
            }

            idx = 0;
            int[,] cells = new int[numRows * numCols, 2]; int nxt = 0;
            for (int row = 0; row < numRows; row++)
            {
                for (int col = 0; col < numCols; col++)
                {
                    int curCell = BOARD_CELL_EMPTY;
                    if (output[idx] == 'A') curCell = BOARD_CELL_PLAYER_ONE_OLD;
                    if (output[idx] == 'B') curCell = BOARD_CELL_PLAYER_TWO_OLD;
                    if (board[row, col] != curCell)
                    {
                        if (board[row, col] != BOARD_CELL_EMPTY)
                            return 0;
                        if (currentPlayer == PLAYER_ONE && curCell == BOARD_CELL_PLAYER_TWO_OLD)
                            return 0;
                        if (currentPlayer == PLAYER_TWO && curCell == BOARD_CELL_PLAYER_ONE_OLD)
                            return 0;
                        board[row, col] = curCell ^ 1;
                        cells[nxt, 0] = row; cells[nxt, 1] = col; nxt++;
                    }
                    idx++;
                }
                while (idx < (int)output.Length && output[idx] != 'A' && output[idx] != 'B' && output[idx] != '-')
                    idx++;
            }

            if (nxt > 3)
                return 0;
            if (nxt == 2)
            {
                if (Math.Abs(cells[0, 0] - cells[1, 0]) > 2) return 0;
                if (Math.Abs(cells[0, 1] - cells[1, 1]) > 2) return 0;

                if (Math.Abs(cells[0, 0] - cells[1, 0]) > 1 ||
                    Math.Abs(cells[0, 1] - cells[1, 1]) > 1)
                {
                    if (Math.Abs(cells[0, 0] - cells[1, 0]) == 1) return 0;
                    if (Math.Abs(cells[0, 1] - cells[1, 1]) == 1) return 0;
                    int nrow = (cells[0, 0] + cells[1, 0]) / 2;
                    int ncol = (cells[0, 1] + cells[1, 1]) / 2;
                    if (currentPlayer == PLAYER_ONE && board[nrow, ncol] / 2 != 1) return 0;
                    if (currentPlayer == PLAYER_TWO && board[nrow, ncol] / 2 != 2) return 0;
                }
            }
            if (nxt == 3)
            {
                if (Math.Max(cells[0, 0], Math.Max(cells[1, 0], cells[2, 0])) -
                    Math.Min(cells[0, 0], Math.Min(cells[1, 0], cells[2, 0]))
                    > 2) return 0;
                if (Math.Max(cells[0, 1], Math.Max(cells[1, 1], cells[2, 1])) -
                    Math.Min(cells[0, 1], Math.Min(cells[1, 1], cells[2, 1]))
                    > 2) return 0;
                if (cells[0, 0] - cells[1, 0] != cells[1, 0] - cells[2, 0]) return 0;
                if (cells[0, 1] - cells[1, 1] != cells[1, 1] - cells[2, 1]) return 0;
            }
            return 1;
        }

        public string nextMove()
        {
            string path, input;
            procOutput = new StringBuilder("");

            markMovesAsOld();
            input = createInput();
            if (currentPlayer == PLAYER_ONE)
                path = tempDirectory + "\\" + PLAYER_ONE_EXE;
            else
                path = tempDirectory + "\\" + PLAYER_TWO_EXE;

            Process proc = new Process();
            try
            {
//                MessageBox.Show("Trying to start executable: " + path);
                proc.StartInfo.FileName = path;
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.CreateNoWindow = true;
                proc.StartInfo.WorkingDirectory = tempDirectory;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardInput = true;
                proc.OutputDataReceived += new DataReceivedEventHandler(ProcOutputHandler);
                proc.Start();
            }
            catch (Exception ex)
            {
                return "#Could not start the process!" + " " + "Original Error: " + ex.Message;
            }
            
            StreamWriter sw = proc.StandardInput;
            proc.BeginOutputReadLine();
            sw.Write(input);
            sw.Close();

            for (int i = 0; i < 10; i++)
            {
                System.Threading.Thread.Sleep(100);
                if (proc.HasExited) break;
            }

            if (!proc.HasExited)
            {
                proc.Kill();
                proc.Dispose();
                return "Time Limit Exceeded!";
            }
            if (proc.ExitCode != 0)
            {
                return "Exit code was different than zero!";
            }
            proc.Close();

//            MessageBox.Show("Printed: " + procOutput.ToString());
            if (validateOutput(procOutput.ToString()) == 0)
                return "Player printed invalid output!";

            if (currentPlayer == PLAYER_ONE)
                currentPlayer = PLAYER_TWO;
            else
                currentPlayer = PLAYER_ONE;

            return "";
        }

        public int getCell(int row, int col)
        {
            return board[row, col];
        }

        public int getNumRows()
        {
            return numRows;
        }

        public int getNumCols()
        {
            return numCols;
        }

        public bool hasEnded()
        {
            for (int row = 0; row < numRows; row++)
                for (int col = 0; col < numCols; col++)
                    if (board[row, col] == BOARD_CELL_EMPTY) return false;
            return true;
        }

        public int getLastPlayer()
        {
            return currentPlayer;
        }

        public int getScore(int player)
        {
            int ret = 0;
            for (int row = 0; row < numRows; row++)
                for (int col = 0; col < numCols; col++)
                    if (board[row, col] / 2 == player) ret++;
            return ret;
        }

        public void prepareGame(int height, int width,
            string execPath, string player1Path, string player2Path)
        {
            numRows = height;
            numCols = width;
            currentDirectory = Path.GetDirectoryName(execPath);

            currentPlayer = PLAYER_ONE;
            board = new int[numRows, numCols];
            for (int row = 0; row < numRows; row++)
                for (int col = 0; col < numCols; col++)
                    board[row, col] = BOARD_CELL_EMPTY;

            tempDirectory = currentDirectory + "\\" + Path.GetRandomFileName();
            while (Directory.Exists(tempDirectory))
                tempDirectory = currentDirectory + "\\" + Path.GetRandomFileName();

            Directory.CreateDirectory(tempDirectory);
            File.Copy(player1Path, tempDirectory + "\\" + PLAYER_ONE_EXE);
            File.Copy(player2Path, tempDirectory + "\\" + PLAYER_TWO_EXE);
        }
    }
}
