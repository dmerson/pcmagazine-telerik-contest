using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace OneTwoThreeVisualizer
{
    public partial class MainWindow : Form
    {
        private Game game;
        private int[,] board;
        private Bitmap boardBitmap;
        private const int MAX_BOARD_SIZE = 20;
        private const int BOARD_CELL_SIZE = 26;
        private const int BOARD_CELL_INACTIVE = 0;
        private const int BOARD_CELL_EMPTY = 1;
        private const int BOARD_CELL_PLAYER_ONE_OLD = 2;
        private const int BOARD_CELL_PLAYER_ONE_NEW = 3;
        private const int BOARD_CELL_PLAYER_TWO_OLD = 4;
        private const int BOARD_CELL_PLAYER_TWO_NEW = 5;
        private Image[] images;


        private void redrawBoard()
        {
            using (Graphics boardImage = Graphics.FromImage(boardBitmap))
            {
                for (int row = 0; row < MAX_BOARD_SIZE; row++)
                    for (int col = 0; col < MAX_BOARD_SIZE; col++)
                        boardImage.DrawImage(images[board[row, col]],
                            new Rectangle(col * BOARD_CELL_SIZE, row * BOARD_CELL_SIZE, 26, 26));
            }
            boardPictureBox.Refresh();
        }

        public MainWindow()
        {
            InitializeComponent();

            prevMoveButton.Enabled = false;

            openFileDialogP1.Filter = "Executables (*.exe)|*.exe";
            openFileDialogP2.Filter = "Executables (*.exe)|*.exe";
            boardSizeDropDown.Text = "Custom";

            // Init board and images
            boardBitmap = new Bitmap(520, 520);
            boardPictureBox.Image = boardBitmap;

            board = new int[MAX_BOARD_SIZE, MAX_BOARD_SIZE];
            for (int row = 0; row < MAX_BOARD_SIZE; row++)
                for (int col = 0; col < MAX_BOARD_SIZE; col++)
                    board[row, col] = BOARD_CELL_INACTIVE;
            images = new Image[6];
            images[0] = Image.FromFile(@"images\button.white.bmp");
            images[1] = Image.FromFile(@"images\button.black.bmp");
            images[2] = Image.FromFile(@"images\button.blue.bmp");
            images[3] = Image.FromFile(@"images\button.cyan.bmp");
            images[4] = Image.FromFile(@"images\button.red.bmp");
            images[5] = Image.FromFile(@"images\button.orange.bmp");
            redrawBoard();
        }

        private void boardSizeDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (boardSizeDropDown.Text == "SmallBoard")
            {
                boardHeight.Value = 4;
                boardWidth.Value = 6;
                boardSizeDropDown.Text = "SmallBoard";
            }
            if (boardSizeDropDown.Text == "MediumBoard")
            {
                boardHeight.Value = 8;
                boardWidth.Value = 12;
                boardSizeDropDown.Text = "MediumBoard";
            }
            if (boardSizeDropDown.Text == "LargeBoard")
            {
                boardHeight.Value = 20;
                boardWidth.Value = 20;
                boardSizeDropDown.Text = "LargeBoard";
            }

        }

        private void openFileButtonP1_Click(object sender, EventArgs e)
        {
            if (openFileDialogP1.ShowDialog() == DialogResult.OK)
            {
                filePathP1.Text = openFileDialogP1.FileName;
            }
        }

        private void openFileButtonP2_Click(object sender, EventArgs e)
        {
            if (openFileDialogP2.ShowDialog() == DialogResult.OK)
            {
                filePathP2.Text = openFileDialogP2.FileName;
            }
        }

        private void boardHeight_ValueChanged(object sender, EventArgs e)
        {
            boardSizeDropDown.Text = "Custom";
        }

        private void boardPictureBox_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(this.boardBitmap,
                new Rectangle(0, 0, 520, 520), 0, 0, 520, 520, GraphicsUnit.Pixel);
        }

        private void displayMove()
        {
            for (int row = 0; row < MAX_BOARD_SIZE; row++)
                for (int col = 0; col < MAX_BOARD_SIZE; col++)
                    board[row, col] = BOARD_CELL_INACTIVE;

            int firstRow = (MAX_BOARD_SIZE - game.getNumRows()) / 2;
            int firstCol = (MAX_BOARD_SIZE - game.getNumCols()) / 2;
            for (int row = 0; row < game.getNumRows(); row++)
                for (int col = 0; col < game.getNumCols(); col++)
                    board[firstRow + row, firstCol + col] = game.getCell(row, col);
            redrawBoard();
        }

        private void showWinner()
        {
            int score1 = game.getScore(1);
            int score2 = game.getScore(2);
            if (score1 == score2)
                MessageBox.Show("Game ended in a draw.");
            else if (score1 > score2)
                MessageBox.Show("Player one won (" + score1 + ":" + score2 + ")!");
            else
                MessageBox.Show("Player two won (" + score1 + ":" + score2 + ")!");
        }
            

        private void showLoser(string reason)
        {
            int loser = game.getLastPlayer();
            if (loser == 1)
            {
                MessageBox.Show("Player two wins!" + Environment.NewLine + 
                                "Player one's solution was faulty: " + reason);
            }
            else
            {
                MessageBox.Show("Player one wins!" + Environment.NewLine +
                                "Player two's solution was faulty: " + reason);
            }
        }

        private int playNextMove()
        {
            int oldScore1 = game.getScore(1);
            int oldScore2 = game.getScore(2);

            string ret = game.nextMove();
            displayMove();
            if (ret != "")
            {
                if (ret[0] == '#')
                    MessageBox.Show("Error: " + ret.Substring(1));
                else
                    showLoser(ret);

                nextMoveButton.Enabled = false;
                startGameButton.Text = "Start Game";
                game.stop();
                return 0;
            }
            int newScore1 = game.getScore(1);
            int newScore2 = game.getScore(2);
            gameProgress.Increment(newScore1 + newScore2 - oldScore1 - oldScore2);
            scorePlayerOne.Text = newScore1.ToString(); scorePlayerOne.Update();
            scorePlayerTwo.Text = newScore2.ToString(); scorePlayerTwo.Update();
            gameProgress.Refresh();
            if (game.hasEnded())
            {
                showWinner();
                nextMoveButton.Enabled = false;
                playWholeGame.Enabled = true;
                startGameButton.Text = "Start Game";
                gameProgress.Value = 0;
                gameProgress.Update();
                game.stop();
            }
            return 1;
        }

        private void startGameButton_Click(object sender, EventArgs e)
        {
            gameProgress.Value = 0;
            gameProgress.Update();
            scorePlayerOne.Text = "0"; scorePlayerOne.Update();
            scorePlayerTwo.Text = "0"; scorePlayerTwo.Update();
            // Currently not playing
            if (startGameButton.Text == "Start Game")
            {
                if (!File.Exists(filePathP1.Text))
                {
                    System.Windows.Forms.MessageBox.Show("Path to Player One's solution is invalid.");
                    return;
                }
                if (!File.Exists(filePathP2.Text))
                {
                    System.Windows.Forms.MessageBox.Show("Path to Player Two's solution is invalid.");
                    return;
                }
                
                startGameButton.Text = "Stop Game";
                playWholeGame.Enabled = false;
                gameProgress.Maximum = (int)boardHeight.Value * (int)boardWidth.Value;

                game = new Game();
                game.prepareGame((int)boardHeight.Value, (int)boardWidth.Value,
                        Application.ExecutablePath, filePathP1.Text, filePathP2.Text);

                if (playWholeGame.Checked == true)
                {
                    startGameButton.Enabled = false;
                    while (playNextMove() == 1)
                        if (game.hasEnded()) break;
                    startGameButton.Enabled = true;
                }
                else
                {
                    nextMoveButton.Enabled = true;
                    playNextMove();
                }
            }
            // Currently playing
            else
            {
                startGameButton.Text = "Start Game";
                playWholeGame.Enabled = true;
                nextMoveButton.Enabled = false;
                gameProgress.Value = 0;
                game.stop();
            }
        }

        private void nextMoveButton_Click(object sender, EventArgs e)
        {
            playNextMove();
            if (game.hasEnded())
            {
                nextMoveButton.Enabled = false;
                startGameButton.Text = "Start Game";
                gameProgress.Value = 0;
                game.stop();
            }
        }
    }
}