namespace OneTwoThreeVisualizer
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gameProgress = new System.Windows.Forms.ProgressBar();
            this.playerOne = new System.Windows.Forms.OpenFileDialog();
            this.playerTwo = new System.Windows.Forms.OpenFileDialog();
            this.boardHeight = new System.Windows.Forms.NumericUpDown();
            this.labelHeight = new System.Windows.Forms.Label();
            this.labelWidth = new System.Windows.Forms.Label();
            this.boardWidth = new System.Windows.Forms.NumericUpDown();
            this.boardSizeDropDown = new System.Windows.Forms.ComboBox();
            this.openFileDialogP1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileButtonP1 = new System.Windows.Forms.Button();
            this.openFileButtonP2 = new System.Windows.Forms.Button();
            this.filePathP1 = new System.Windows.Forms.TextBox();
            this.filePathP2 = new System.Windows.Forms.TextBox();
            this.startGameButton = new System.Windows.Forms.Button();
            this.nextMoveButton = new System.Windows.Forms.Button();
            this.playWholeGame = new System.Windows.Forms.CheckBox();
            this.OneTwoThreeInfo = new System.Windows.Forms.Label();
            this.openFileDialogP2 = new System.Windows.Forms.OpenFileDialog();
            this.prevMoveButton = new System.Windows.Forms.Button();
            this.boardPictureBox = new System.Windows.Forms.PictureBox();
            this.scorePlayerOneLabel = new System.Windows.Forms.Label();
            this.scorePlayerTwoLabel = new System.Windows.Forms.Label();
            this.scorePlayerOne = new System.Windows.Forms.Label();
            this.scorePlayerTwo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.boardHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boardWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.boardPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // gameProgress
            // 
            this.gameProgress.Location = new System.Drawing.Point(10, 493);
            this.gameProgress.Name = "gameProgress";
            this.gameProgress.Size = new System.Drawing.Size(250, 23);
            this.gameProgress.TabIndex = 0;
            // 
            // playerOne
            // 
            this.playerOne.FileName = "openFileDialog1";
            this.playerOne.Title = "Solution of Player One";
            // 
            // playerTwo
            // 
            this.playerTwo.FileName = "openFileDialog1";
            this.playerTwo.Title = "Solution of Player Two";
            // 
            // boardHeight
            // 
            this.boardHeight.Location = new System.Drawing.Point(222, 186);
            this.boardHeight.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.boardHeight.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.boardHeight.Name = "boardHeight";
            this.boardHeight.Size = new System.Drawing.Size(40, 20);
            this.boardHeight.TabIndex = 2;
            this.boardHeight.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.boardHeight.ValueChanged += new System.EventHandler(this.boardHeight_ValueChanged);
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.Location = new System.Drawing.Point(147, 188);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(69, 13);
            this.labelHeight.TabIndex = 3;
            this.labelHeight.Text = "Board Height";
            // 
            // labelWidth
            // 
            this.labelWidth.AutoSize = true;
            this.labelWidth.Location = new System.Drawing.Point(150, 225);
            this.labelWidth.Name = "labelWidth";
            this.labelWidth.Size = new System.Drawing.Size(66, 13);
            this.labelWidth.TabIndex = 4;
            this.labelWidth.Text = "Board Width";
            // 
            // boardWidth
            // 
            this.boardWidth.Location = new System.Drawing.Point(222, 223);
            this.boardWidth.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.boardWidth.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.boardWidth.Name = "boardWidth";
            this.boardWidth.Size = new System.Drawing.Size(40, 20);
            this.boardWidth.TabIndex = 5;
            this.boardWidth.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // boardSizeDropDown
            // 
            this.boardSizeDropDown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boardSizeDropDown.Items.AddRange(new object[] {
            "Custom",
            "SmallBoard",
            "MediumBoard",
            "LargeBoard"});
            this.boardSizeDropDown.Location = new System.Drawing.Point(12, 201);
            this.boardSizeDropDown.Name = "boardSizeDropDown";
            this.boardSizeDropDown.Size = new System.Drawing.Size(100, 21);
            this.boardSizeDropDown.TabIndex = 7;
            this.boardSizeDropDown.SelectedIndexChanged += new System.EventHandler(this.boardSizeDropDown_SelectedIndexChanged);
            // 
            // openFileDialogP1
            // 
            this.openFileDialogP1.FileName = "invalid";
            this.openFileDialogP1.Title = "PlayerOne";
            // 
            // openFileButtonP1
            // 
            this.openFileButtonP1.Location = new System.Drawing.Point(172, 101);
            this.openFileButtonP1.Name = "openFileButtonP1";
            this.openFileButtonP1.Size = new System.Drawing.Size(90, 30);
            this.openFileButtonP1.TabIndex = 8;
            this.openFileButtonP1.Text = "Browse...";
            this.openFileButtonP1.UseVisualStyleBackColor = true;
            this.openFileButtonP1.Click += new System.EventHandler(this.openFileButtonP1_Click);
            // 
            // openFileButtonP2
            // 
            this.openFileButtonP2.Location = new System.Drawing.Point(172, 137);
            this.openFileButtonP2.Name = "openFileButtonP2";
            this.openFileButtonP2.Size = new System.Drawing.Size(90, 30);
            this.openFileButtonP2.TabIndex = 9;
            this.openFileButtonP2.Text = "Browse...";
            this.openFileButtonP2.UseVisualStyleBackColor = true;
            this.openFileButtonP2.Click += new System.EventHandler(this.openFileButtonP2_Click);
            // 
            // filePathP1
            // 
            this.filePathP1.Location = new System.Drawing.Point(12, 107);
            this.filePathP1.Name = "filePathP1";
            this.filePathP1.Size = new System.Drawing.Size(150, 20);
            this.filePathP1.TabIndex = 10;
            this.filePathP1.Text = "Solution Player One";
            // 
            // filePathP2
            // 
            this.filePathP2.Location = new System.Drawing.Point(12, 143);
            this.filePathP2.Name = "filePathP2";
            this.filePathP2.Size = new System.Drawing.Size(150, 20);
            this.filePathP2.TabIndex = 11;
            this.filePathP2.Text = "Solution Player Two";
            // 
            // startGameButton
            // 
            this.startGameButton.Location = new System.Drawing.Point(67, 293);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(136, 42);
            this.startGameButton.TabIndex = 12;
            this.startGameButton.Text = "Start Game";
            this.startGameButton.UseVisualStyleBackColor = true;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // nextMoveButton
            // 
            this.nextMoveButton.Enabled = false;
            this.nextMoveButton.Location = new System.Drawing.Point(140, 375);
            this.nextMoveButton.Name = "nextMoveButton";
            this.nextMoveButton.Size = new System.Drawing.Size(80, 30);
            this.nextMoveButton.TabIndex = 13;
            this.nextMoveButton.Text = "Next Move";
            this.nextMoveButton.UseVisualStyleBackColor = true;
            this.nextMoveButton.Click += new System.EventHandler(this.nextMoveButton_Click);
            // 
            // playWholeGame
            // 
            this.playWholeGame.AutoSize = true;
            this.playWholeGame.Location = new System.Drawing.Point(85, 341);
            this.playWholeGame.Name = "playWholeGame";
            this.playWholeGame.Size = new System.Drawing.Size(107, 17);
            this.playWholeGame.TabIndex = 14;
            this.playWholeGame.Text = "Play Entire Game";
            this.playWholeGame.UseVisualStyleBackColor = true;
            // 
            // OneTwoThreeInfo
            // 
            this.OneTwoThreeInfo.AutoSize = true;
            this.OneTwoThreeInfo.Location = new System.Drawing.Point(13, 9);
            this.OneTwoThreeInfo.Name = "OneTwoThreeInfo";
            this.OneTwoThreeInfo.Size = new System.Drawing.Size(236, 39);
            this.OneTwoThreeInfo.TabIndex = 15;
            this.OneTwoThreeInfo.Text = "This is visualizer for the game One-Two-Three\r\nDesigned by Alexander Georgiev\r\nSu" +
                "bmission for PC Magazine and Telerik Contest";
            this.OneTwoThreeInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // openFileDialogP2
            // 
            this.openFileDialogP2.FileName = "invalid";
            this.openFileDialogP2.Title = "Player Two";
            // 
            // prevMoveButton
            // 
            this.prevMoveButton.Location = new System.Drawing.Point(54, 375);
            this.prevMoveButton.Name = "prevMoveButton";
            this.prevMoveButton.Size = new System.Drawing.Size(80, 30);
            this.prevMoveButton.TabIndex = 16;
            this.prevMoveButton.Text = "Prev Move";
            this.prevMoveButton.UseVisualStyleBackColor = true;
            // 
            // boardPictureBox
            // 
            this.boardPictureBox.Location = new System.Drawing.Point(269, 4);
            this.boardPictureBox.Name = "boardPictureBox";
            this.boardPictureBox.Size = new System.Drawing.Size(520, 520);
            this.boardPictureBox.TabIndex = 0;
            this.boardPictureBox.TabStop = false;
            // 
            // scorePlayerOneLabel
            // 
            this.scorePlayerOneLabel.AutoSize = true;
            this.scorePlayerOneLabel.Location = new System.Drawing.Point(82, 430);
            this.scorePlayerOneLabel.Name = "scorePlayerOneLabel";
            this.scorePlayerOneLabel.Size = new System.Drawing.Size(93, 13);
            this.scorePlayerOneLabel.TabIndex = 17;
            this.scorePlayerOneLabel.Text = "Score Player One:";
            // 
            // scorePlayerTwoLabel
            // 
            this.scorePlayerTwoLabel.AutoSize = true;
            this.scorePlayerTwoLabel.Location = new System.Drawing.Point(82, 452);
            this.scorePlayerTwoLabel.Name = "scorePlayerTwoLabel";
            this.scorePlayerTwoLabel.Size = new System.Drawing.Size(94, 13);
            this.scorePlayerTwoLabel.TabIndex = 18;
            this.scorePlayerTwoLabel.Text = "Score Player Two:";
            // 
            // scorePlayerOne
            // 
            this.scorePlayerOne.AutoSize = true;
            this.scorePlayerOne.Location = new System.Drawing.Point(182, 430);
            this.scorePlayerOne.Name = "scorePlayerOne";
            this.scorePlayerOne.Size = new System.Drawing.Size(13, 13);
            this.scorePlayerOne.TabIndex = 19;
            this.scorePlayerOne.Text = "0";
            // 
            // scorePlayerTwo
            // 
            this.scorePlayerTwo.AutoSize = true;
            this.scorePlayerTwo.Location = new System.Drawing.Point(182, 452);
            this.scorePlayerTwo.Name = "scorePlayerTwo";
            this.scorePlayerTwo.Size = new System.Drawing.Size(13, 13);
            this.scorePlayerTwo.TabIndex = 20;
            this.scorePlayerTwo.Text = "0";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 528);
            this.Controls.Add(this.scorePlayerTwo);
            this.Controls.Add(this.scorePlayerOne);
            this.Controls.Add(this.scorePlayerTwoLabel);
            this.Controls.Add(this.scorePlayerOneLabel);
            this.Controls.Add(this.boardPictureBox);
            this.Controls.Add(this.prevMoveButton);
            this.Controls.Add(this.OneTwoThreeInfo);
            this.Controls.Add(this.playWholeGame);
            this.Controls.Add(this.nextMoveButton);
            this.Controls.Add(this.startGameButton);
            this.Controls.Add(this.filePathP2);
            this.Controls.Add(this.filePathP1);
            this.Controls.Add(this.openFileButtonP2);
            this.Controls.Add(this.openFileButtonP1);
            this.Controls.Add(this.boardSizeDropDown);
            this.Controls.Add(this.boardWidth);
            this.Controls.Add(this.labelWidth);
            this.Controls.Add(this.labelHeight);
            this.Controls.Add(this.boardHeight);
            this.Controls.Add(this.gameProgress);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 560);
            this.MinimumSize = new System.Drawing.Size(800, 560);
            this.Name = "MainWindow";
            this.Text = "One-Two-Three Visualizer";
            ((System.ComponentModel.ISupportInitialize)(this.boardHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boardWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.boardPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar gameProgress;
        private System.Windows.Forms.OpenFileDialog playerOne;
        private System.Windows.Forms.OpenFileDialog playerTwo;
        private System.Windows.Forms.NumericUpDown boardHeight;
        private System.Windows.Forms.Label labelHeight;
        private System.Windows.Forms.Label labelWidth;
        private System.Windows.Forms.NumericUpDown boardWidth;
        private System.Windows.Forms.ComboBox boardSizeDropDown;
        private System.Windows.Forms.OpenFileDialog openFileDialogP1;
        private System.Windows.Forms.Button openFileButtonP1;
        private System.Windows.Forms.Button openFileButtonP2;
        private System.Windows.Forms.TextBox filePathP1;
        private System.Windows.Forms.TextBox filePathP2;
        private System.Windows.Forms.Button startGameButton;
        private System.Windows.Forms.Button nextMoveButton;
        private System.Windows.Forms.CheckBox playWholeGame;
        private System.Windows.Forms.Label OneTwoThreeInfo;
        private System.Windows.Forms.OpenFileDialog openFileDialogP2;
        private System.Windows.Forms.Button prevMoveButton;
        private System.Windows.Forms.PictureBox boardPictureBox;
        private System.Windows.Forms.Label scorePlayerOneLabel;
        private System.Windows.Forms.Label scorePlayerTwoLabel;
        private System.Windows.Forms.Label scorePlayerOne;
        private System.Windows.Forms.Label scorePlayerTwo;
    }
}

