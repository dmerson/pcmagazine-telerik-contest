/*
ID: espr1t
LANG: C++
TASK: One-Two-Three
KEYWORDS: Long, Game, NP
CONTEST: PC Magazine and Telerik
*/

#include <cstdio>
#include <cctype>
#include <vector>
#include <algorithm>
using namespace std;

#define MAX 32
#define BOARD_MIN_SIZE 3
#define BOARD_MAX_SIZE 20

#define DEBUG 0
#define NEW_LINE_SEQ "\r\n"

#define MAX_BUFFER_SIZE 1048576

int n, m;
char curPlayer;
char board[MAX][MAX];
char answer[MAX][MAX];
FILE* in; FILE* out;

void randomMove()
{
	vector < pair <int, int> > cells;
	static int dir[8][2] = { {-1, -1}, {-1, 0}, {-1, +1}, {0, +1},
							 {+1, -1}, {+1, 0}, {+1, +1}, {0, -1} };

	for (int row = 0; row < n; row++)
		for (int col = 0; col < m; col++)
			if (board[row][col] == '-') cells.push_back(make_pair(row, col));
	random_shuffle(cells.begin(), cells.end());

	int flag = 1;
	for (int len = 3; len >= 1; len--)
	{
		int frow = -1, fcol = -1, fdir = -1;
		for (int i = 0; i < (int)cells.size(); i++)
		{
			int row = cells[i].first;
			int col = cells[i].second;
			vector <int> d;
			for (int c = 0; c < 8; c++)
				d.push_back(c);
			random_shuffle(d.begin(), d.end());

			for (int c = 0; c < 8; c++)
			{
				flag = 1;
				int cnt = 0;
				for (int k = 0; k < len; k++)
				{
					int nrow = row + dir[d[c]][0] * k; if (nrow < 0 || nrow >= n) {flag = 0; break;}
					int ncol = col + dir[d[c]][1] * k; if (ncol < 0 || ncol >= m) {flag = 0; break;}
					if (board[nrow][ncol] != '-' && board[nrow][ncol] != curPlayer) {flag = 0; break;}
					if (board[nrow][ncol] == curPlayer) cnt++;
				}
				if (flag && cnt == 0)
				{
					memcpy(answer, board, sizeof(answer));
					for (int k = 0; k < len; k++)
					{
						int nrow = row + dir[d[c]][0] * k;
						int ncol = col + dir[d[c]][1] * k;
						answer[nrow][ncol] = curPlayer;
					}
					break;
				}
				if (flag && cnt == 1) {frow = row; fcol = col; fdir = d[c];}
				flag = 0;
			}
			if (flag) break;
		}
		if (flag) break;
		if (frow != -1 && fcol != -1 && fdir != -1)
		{
			memcpy(answer, board, sizeof(answer));
			for (int k = 0; k < len; k++)
			{
				int nrow = frow + dir[fdir][0] * k;
				int ncol = fcol + dir[fdir][1] * k;
				answer[nrow][ncol] = curPlayer;
			}
			flag = 1; break;
		}
	}
}

int eval()
{
	for (int row = n - 1; row >= 0; row -= 5)
	{
		// Vertical
		for (int col = 0; col < m; col++)
		{
			int erow = row;
			if (!(col & 1)) erow--;
			if (erow < 2) continue;
			if (board[erow][col] == '-' && board[erow - 1][col] == '-' && board[erow - 2][col] == '-')
			{
				memcpy(answer, board, sizeof(answer));
				answer[erow - 0][col] = curPlayer;
				answer[erow - 1][col] = curPlayer;
				answer[erow - 2][col] = curPlayer;
				return 1;
			}
		}
		// Horizontal
		for (int col = 0; col < m; col += 3)
		{
			int erow = row - 4;
			if (erow < 0) continue;
			if (col + 2 >= m) continue;
			if (board[erow][col] == '-' && board[erow][col + 1] == '-' && board[erow][col + 2] == '-')
			{
				memcpy(answer, board, sizeof(answer));
				answer[erow][col + 0] = curPlayer;
				answer[erow][col + 1] = curPlayer;
				answer[erow][col + 2] = curPlayer;
				return 1;
			}
		}
	}
	return 0;
}

void printOutput()
{
	for (int i = 0; i < n; i++)
		fprintf(out, "%s%s", answer[i], NEW_LINE_SEQ);
}

void parseInput()
{
	static char buff[MAX_BUFFER_SIZE];
	fgets(buff, MAX_BUFFER_SIZE, in);
	
	if (sscanf(buff, "%d %d", &m, &n) != 2)
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "First line does not contain integer parameters M and N.%s", NEW_LINE_SEQ);
		exit(0);
	}

	int len = (int)strlen(buff), idx = 0;
	while (idx < len && !(buff[idx] >= '0' && buff[idx] <= '9'))
		buff[idx++] = ' ';
	while (idx < len &&  (buff[idx] >= '0' && buff[idx] <= '9'))
		buff[idx++] = ' ';
	
	if (buff[idx] != ' ' || !(buff[idx + 1] >= '0' && buff[idx + 1] <= '9'))
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "Parameters M and N are not separated by exactly one space.%s", NEW_LINE_SEQ);
		exit(0);
	}
	idx++;
	while (idx < len &&  (buff[idx] >= '0' && buff[idx] <= '9'))
		buff[idx++] = ' ';
	for (int i = 0; i < len; i++) if (!isspace(buff[i]))
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "First line contains characters other than arguments M and N.%s", NEW_LINE_SEQ);
		exit(0);
	}
	
	if (m < BOARD_MIN_SIZE || m > BOARD_MAX_SIZE)
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "Number of columns is out of bounds (it is %d, but should be between %d and %d).%s",
				m, BOARD_MIN_SIZE, BOARD_MAX_SIZE, NEW_LINE_SEQ);
		exit(0);
	}
	if (n < BOARD_MIN_SIZE || n > BOARD_MAX_SIZE)
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "Number of rows is out of bounds (it is %d, but should be between %d and %d).%s",
				n, BOARD_MIN_SIZE, BOARD_MAX_SIZE, NEW_LINE_SEQ);
		exit(0);
	}
	
	for (int i = 0; i < n; i++)
	{
		fgets(buff, MAX_BUFFER_SIZE, in);
		buff[MAX_BUFFER_SIZE - 1] = 0;
		len = (int)strlen(buff);
		for (int c = 0; c < m; c++)
		{
			if (buff[c] != '-' && buff[c] != 'A' && buff[c] != 'B')
			{
				fprintf(out, "error%s", NEW_LINE_SEQ);
				fprintf(out, "Board row %d contains invalid character sequence.%s", i + 1, NEW_LINE_SEQ);
				exit(0);
			}
		}
		for (int c = m; c < len; c++) if (!isspace(buff[c]))
		{
			fprintf(out, "error%s", NEW_LINE_SEQ);
			fprintf(out, "Board row %d contains additional characters.%s", i + 1, NEW_LINE_SEQ);
			exit(0);
		}
		for (int c = 0; c < m; c++)
			board[i][c] = buff[c];
	}
	int cntEmpty = 0;
	for (int row = 0; row < n; row++)
		for (int col = 0; col < m; col++)
			if (board[row][col] == '-') cntEmpty++;
	if (cntEmpty == 0)
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "All cells of the board are already used.%s", NEW_LINE_SEQ);
		exit(0);
	}
	fgets(buff, MAX_BUFFER_SIZE, in);
	curPlayer = buff[0];
	if (buff[0] != 'A' && buff[0] != 'B')
	{
		fprintf(out, "error%s", NEW_LINE_SEQ);
		fprintf(out, "Last line of input is invalid (should be single character 'A' or 'B').%s", NEW_LINE_SEQ);
		exit(0);
	}
	for (int i = 1; i < MAX_BUFFER_SIZE; i++)
	{
		if (buff[i] == 0 || buff[i] == EOF) break;
		if (!isspace(buff[i]))
		{
			fprintf(out, "error%s", NEW_LINE_SEQ);
			fprintf(out, "Last line of input is invalid (contains additional characters).%s", NEW_LINE_SEQ);
			exit(0);
		}
	}
}

void init()
{
	srand(42);
	in = stdin; out = stdout;
	if (DEBUG)
	{
		in = fopen("OneTwoThree.in", "rt");
		out = fopen("OneTwoThree.out", "wt");
	}
}

int main(void)
{
	init();
	parseInput();
	if (!eval())
		randomMove();
	printOutput();
	return 0;
}
