﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace One23GameCore
{
    public class PlayingBoard : INotifyPropertyChanged
    {
        private Cell[,] board = new Cell[, ] {};
        private int width;
        private int height;
        private const int MAX_SIZE = 20;
        private const int MIN_SIZE = 3;

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string property)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        public void InitializeBoard(int m, int n)
        {
            this.Width = m;
            this.Height = n;
            this.board = new Cell[this.height, this.width];

            for(int i = 0; i < this.height; i ++)
            {
                for(int j = 0; j < this.width; j ++)
                {
                    this.board[i, j] = new Cell(j, i, CellState.Free);
                }
            }
        }

        public void Clear()
        {
            this.InitializeBoard(this.width, this.height);
            NotifyPropertyChanged("BoardList");
        }

        public Cell this[int i, int j]
        {
            get { return this.board[i, j]; }
        }

        public override string ToString()
        {
            StringBuilder output = new StringBuilder();

            for(int i = 0; i < this.height; i ++)
            {
                for(int j = 0; j < this.width; j ++)
                {
                    switch (board[i, j].State)
                    {
                        case CellState.A:
                            output.Append("A");
                            break;

                        case CellState.B:
                            output.Append("B");
                            break;

                        case CellState.Free:
                            output.Append("-");
                            break;
                    }
                }

                output.Append("\n");
            }

            return output.ToString();
        }

        public List<Cell> BoardList
        {
            get { return this.board.Cast<Cell>().ToList(); }
        }

        public int Width
        {
            get { return this.width; }
            private set
            {
                if (value < MIN_SIZE || value > MAX_SIZE)
                {
                    throw new ArgumentOutOfRangeException("N", string.Format(
                        "N should be in the interval [{0}; {1}]", MIN_SIZE, MAX_SIZE));
                }

                this.width = value;
                NotifyPropertyChanged("Width");
            }
        }

        public int Height
        {
            get { return this.height; }
            private set
            {
                if (value < MIN_SIZE || value > MAX_SIZE)
                {
                    throw new ArgumentOutOfRangeException("M", string.Format(
                        "M should be in the interval [{0}; {1}]", MIN_SIZE, MAX_SIZE));
                }

                this.height = value;
                NotifyPropertyChanged("Height");
            }
        }

        public bool IsBoardFull
        {
            get
            {
                foreach (Cell cell in this.board)
                {
                    if(cell.State == CellState.Free)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        public bool IsBoardEmpty
        {
            get
            {
                foreach (Cell cell in this.board)
                {
                    if (cell.State != CellState.Free)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        public int Length
        {
            get { return this.board.Length; }
        }

        public Cell[, ] Board
        {
            get { return this.board; }
        }
    }
}
