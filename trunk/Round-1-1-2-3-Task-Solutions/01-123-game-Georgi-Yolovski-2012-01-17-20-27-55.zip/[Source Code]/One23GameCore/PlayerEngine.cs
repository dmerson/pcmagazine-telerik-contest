﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Management.Instrumentation;
using System.Reflection;
using System.Linq;
using System.Text;

namespace One23GameCore
{
    public enum PlayerLetter
    {
        A,
        B
    }

    public abstract class PlayerEngine : INotifyPropertyChanged
    {
        protected readonly PlayingBoard playingBoard;
        private int wins;
        private int score;
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string property)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        protected PlayerEngine(string name, PlayerLetter letter, PlayingBoard playingBoard)
        {
            this.PlayerName = name;
            this.PlayerLetter = letter;
            this.playingBoard = playingBoard;
            this.score = 0;
            this.wins = 0;
        }

        public static PlayerEngine LoadEngine(string fileName, string name, PlayerLetter letter, PlayingBoard board)
        {
            Assembly assembly = Assembly.LoadFrom(fileName);

            foreach (Type t in assembly.GetTypes())
            {
                ConstructorInfo cInfo = t.GetConstructor(new Type[] {typeof(string), 
                    typeof(PlayerLetter), typeof(PlayingBoard)});
                if (cInfo != null)
                {
                    return (PlayerEngine) cInfo.Invoke(new object[] {name, letter, board});
                }
            }

            throw new InstanceNotFoundException("No PlayerEngine was found in this assembly");
        }

        public virtual Cell[] MakeBestMove()
        {
            return null;
        }

        public string PlayerName { get; set; }
        public PlayerLetter PlayerLetter { get; set; }
        public int Wins 
        { 
            get
            {
                return this.wins;
            } 
            set
            {
            this.wins = value; 
            NotifyPropertyChanged("Wins"); 
            } 
        }

        public int Score 
        { 
            get 
            { 
                return this.score; 
            } 
            set
            {
                this.score = value;
                NotifyPropertyChanged("Score");
            } 
        }
    }
}
