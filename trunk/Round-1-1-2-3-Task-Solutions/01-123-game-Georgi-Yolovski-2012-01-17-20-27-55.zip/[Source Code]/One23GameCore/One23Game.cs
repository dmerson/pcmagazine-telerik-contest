﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace One23GameCore
{
    public class One23Game : INotifyPropertyChanged
    {
        private PlayingBoard playingBoard;
        private PlayerEngine playerA;
        private PlayerEngine playerB;
        private PlayerEngine currentPlayer;

        public One23Game()
        {
            this.playingBoard = new PlayingBoard();
            this.CurrentPlayer = this.PlayerA;
            this.IsGameOver = false;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        public void ParseInput(string input)
        {
            List<string> lines = input.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries).ToList();

            string size = lines[0];
            int width = 0;
            if (!int.TryParse(size.Split(' ').First(), out width))
            {
                throw new ArgumentException("Invalid M", "M");
            }

            int height = 0;
            if (!int.TryParse(size.Split(' ').Last(), out height))
            {
                throw new ArgumentException("Invalid N", "N");
            }

            if (this.playingBoard.Length == 0)
            {
                this.playingBoard.InitializeBoard(width, height);
            }

            if (lines.Count != this.playingBoard.Height + 2)
            {
                throw new ArgumentException("Invalid input", "input");
            }

            lines.RemoveAt(0);

            string nextPlayerLetter = lines.Last();
            if (nextPlayerLetter == "A")
            {
                this.CurrentPlayer = PlayerB;
            }
            else if (nextPlayerLetter == "B")
            {
                this.CurrentPlayer = PlayerA;
            }
            else
            {
                throw new ArgumentOutOfRangeException("Invalid player", "player");
            }

            List<Cell> moves = new List<Cell>();
            for (int i = 0; i < lines.Count - 1; i++)
            {
                if (lines[i].Length != this.playingBoard.Width)
                {
                    throw new ArgumentException("Invalid playingBoard row", "row");
                }

                for (int j = 0; j < lines[i].Length; j++)
                {
                    if (Array.IndexOf(new char[] { 'A', 'B', '-' }, lines[i][j]) < 0)
                    {
                        throw new ArgumentOutOfRangeException("Invalid cell value", "cell");
                    }

                    switch (lines[i][j])
                    {
                        case 'A':
                            if(this.playingBoard[i, j].State == CellState.B)
                            {
                                GameOver(true);
                                throw new InvalidMoveException("This cell is not free");
                            }

                            if (this.playingBoard[i, j].State == CellState.Free)
                            {
                                moves.Add(new Cell(j, i, CellState.A));
                            }
                            break;

                        case 'B':
                            if(this.playingBoard[i, j].State == CellState.A)
                            {
                                GameOver(true);
                                throw new InvalidMoveException("This cell is not free");
                            }

                            if (this.playingBoard[i, j].State == CellState.Free)
                            {
                                moves.Add(new Cell(j, i, CellState.B));
                            }
                            break;

                        case '-':
                            if(this.playingBoard[i, j].State != CellState.Free)
                            {
                                GameOver(true);
                                throw new InvalidMoveException("This cell is already taken by a player");
                            }
                            break;
                    }
                }
            }

            this.PerformMove(moves.ToArray());
        }

        public void PerformMove(params Cell[] input)
        {
            this.CurrentPlayer = (this.CurrentPlayer == this.PlayerA) ? this.PlayerB : this.PlayerA;

            if (input.Length > 3)
            {
                GameOver(true);
                throw new InvalidMoveException("The move should affect no more than 3 cells");
            }

            foreach (Cell cell in input)
            {

                if (this.playingBoard[cell.Y, cell.X].State != CellState.Free)
                {
                    GameOver(true);
                    throw new InvalidMoveException("This cell is not free");
                }

                if (cell.X > this.playingBoard.Width - 1)
                {
                    GameOver(true);
                    throw new InvalidMoveException("This cell is out of the playing board");
                }

                if (cell.Y > this.playingBoard.Height - 1)
                {
                    GameOver(true);
                    throw new InvalidMoveException("This cell is out of the playing board");
                }

                this.playingBoard[cell.Y, cell.X].State = cell.State;

                this.playingBoard.NotifyPropertyChanged("Board");
                this.playingBoard.NotifyPropertyChanged("BoardList");
                if (this.playingBoard.IsBoardFull)
                {
                    GameOver();
                }
            }

        }

        private void GameOver(bool disqualified = false)
        {
            this.IsGameOver = true;

            if (disqualified)
            {
                if (this.CurrentPlayer == this.PlayerA)
                {
                    this.PlayerB.Score += this.playingBoard.Height*this.playingBoard.Width;
                    this.Winner = this.PlayerB;
                }
                else
                {
                    this.PlayerA.Score += this.playingBoard.Height*this.playingBoard.Width;
                    this.Winner = this.PlayerA;
                }

                this.IsDraw = false;
            }
            else
            {
                int playerAScore = 0;
                int playerBScore = 0;
                foreach (Cell cell in this.playingBoard.Board)
                {
                    if(cell.State == CellState.A)
                    {
                        playerAScore++;
                    }
                    else
                    {
                        playerBScore++;
                    }
                }

                this.PlayerA.Score += playerAScore;
                this.PlayerB.Score += playerBScore;

                if(playerAScore == playerBScore)
                {
                    this.IsDraw = true;
                }
                else
                {
                    this.Winner = (playerAScore > playerBScore) ? this.PlayerA : this.PlayerB;
                    IsDraw = false;
                }
            }

            if(this.Winner == this.PlayerA)
            {
                this.PlayerA.Wins++;
            }
            else if(this.Winner == this.PlayerB)
            {
                this.PlayerB.Wins++;
            }

            this.IsGameOver = true;
        }

        public void StartNewGame()
        {
            this.playingBoard.Clear();
            this.Winner = null;
            this.IsGameOver = false;
        }

        public PlayingBoard PlayingBoard
        {
            get { return this.playingBoard; }
        }

        public PlayerEngine PlayerA
        {
            get { return this.playerA; }
            set { this.playerA = value; NotifyPropertyChanged("PlayerA"); }
        }

        public PlayerEngine PlayerB
        {
            get { return this.playerB; }
            set { this.playerB = value; NotifyPropertyChanged("PlayerB"); }
        }
        public PlayerEngine CurrentPlayer 
        { 
            get
            {
                if(this.currentPlayer == null)
                {
                    return this.PlayerA;
                }

                return this.currentPlayer;
            }
            set
            {
                this.currentPlayer = value;
            }
        }
        public PlayerEngine Winner { get; private set; }
        public bool IsGameOver { get; private set; }
        public bool IsDraw { get; private set; }
    }
}
