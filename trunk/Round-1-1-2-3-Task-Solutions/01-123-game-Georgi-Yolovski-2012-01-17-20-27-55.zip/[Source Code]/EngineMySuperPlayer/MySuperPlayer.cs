﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Threading;
using System.Timers;
using One23GameCore;

namespace EngineMySuperPlayer
{
    public class MySuperPlayer : PlayerEngine
    {
        public MySuperPlayer(string name, PlayerLetter letter, PlayingBoard playingBoard)
            : base(name, letter, playingBoard)
        {
            
        }
        
        public override Cell[] MakeBestMove()
        {
            List<Cell> move = new List<Cell>();
            List<List<Cell>> possibleMoves = new List<List<Cell>>();
            CellState letter = (this.PlayerLetter == PlayerLetter.A)
                ? CellState.A : CellState.B;

            DispatcherTimer t = new DispatcherTimer();
            t.Interval = new TimeSpan(0, 0, 1);
            t.Tick += new EventHandler(t_Tick);
            t.Start();
            for (int i = 0; i < this.playingBoard.Height; i++)
            {
                for (int j = 0; j < this.playingBoard.Width; j++)
                {
                    if (IsCellFree(j, i) && IsCellFree(j + 1, i + 1))
                    {
                        move.Clear();
                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j + 1, i + 1, letter));

                        if (IsCellFree(j + 2, i + 2))
                        {
                            //  B
                            //    B
                            //      B

                            move.Add(new Cell(j + 2, i + 2, letter));
                        }

                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellFree(j - 1, i + 1))
                    {
                        move.Clear();
                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j - 1, i + 1, letter));

                        if (IsCellFree(j - 2, i + 2))
                        {
                            //      B
                            //    B
                            //  B

                            move.Add(new Cell(j - 2, i + 2, letter));
                        }

                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellFree(j + 1, i))
                    {
                        move.Clear();
                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j + 1, i, letter));

                        if (IsCellFree(j + 2, i))
                        {
                            //  BBB
                            //
                            //

                            move.Add(new Cell(j + 2, i, letter));
                        }

                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellFree(j, i + 1))
                    {
                        move.Clear();
                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j, i + 1, letter));

                        if (IsCellFree(j, i + 2))
                        {
                            //  B
                            //  B
                            //  B

                            move.Add(new Cell(j, i + 2, letter));
                        }

                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellStateSame(j + 1, i) && IsCellFree(j + 2, i))
                    {
                        move.Clear();
                        //  B [B] B

                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j + 2, i, letter));
                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellStateSame(j, i + 1) && IsCellFree(j, i + 2))
                    {
                        move.Clear();
                        //  B 
                        // [B]
                        //  B

                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j, i + 2, letter));
                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellStateSame(j + 1, i + 1) &&
                        IsCellFree(j + 2, i + 2))
                    {
                        move.Clear();
                        //  B
                        //    [B]
                        //        B

                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j + 2, i + 2, letter));
                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i) && IsCellStateSame(j - 1, i - 1) &&
                        IsCellFree(j - 2, i - 2))
                    {
                        move.Clear();
                        //        B
                        //    [B]
                        //  B

                        move.Add(new Cell(j, i, letter));
                        move.Add(new Cell(j - 2, i - 2, letter));
                        possibleMoves.Add(new List<Cell>(move));
                    }

                    if (IsCellFree(j, i))
                    {
                        move.Clear();
                        move.Add(new Cell(j, i, letter));
                        possibleMoves.Add(new List<Cell>(move));
                    }
                }
            }

            possibleMoves.Sort(new Comparison<List<Cell>>((List<Cell> a, List<Cell> b) =>
                                                              {
                                                                  return a.Count.CompareTo(b.Count);
                                                              }));
            int maxMoveLength = possibleMoves.Last().Count;
            List<List<Cell>> bestMoves = (from m in possibleMoves
                                    where m.Count == maxMoveLength
                                    select m).ToList();
            Random r = new Random();
            int index = r.Next(bestMoves.Count - 1);
            t.IsEnabled = false;
            return bestMoves[index].ToArray();
        }

        void t_Tick(object sender, EventArgs e)
        {
            throw new InvalidMoveException("Move timeout");
        }

        private bool IsCellFree(int x, int y)
        {
            if(x < this.playingBoard.Width && x >= 0 
               && y < this.playingBoard.Height && y >= 0)
            {
                if(this.playingBoard[y, x].State == CellState.Free)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;
        }

        private bool IsCellStateSame(int x,int y)
        {
            if (x < this.playingBoard.Width && x >= 0
               && y < this.playingBoard.Height && y >= 0)
            {
                CellState letter = (this.PlayerLetter == PlayerLetter.A)
                ? CellState.A : CellState.B;

                if (this.playingBoard[y, x].State == letter)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;
        }
    }
}
