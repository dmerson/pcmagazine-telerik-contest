﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using One23GameCore;

namespace One23GameSimulator
{
    class StateToFillConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, Object parameter,
            CultureInfo culture)
        {
            CellState state = (CellState)value;
            switch (state)
            {
                case CellState.Free:
                    return new SolidColorBrush(Colors.DarkGray);

                case CellState.A:
                    return new SolidColorBrush(Colors.Firebrick);

                case CellState.B:
                    return new SolidColorBrush(Colors.Navy);
            }

            return "";
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            CultureInfo culture)
        {
            return DependencyProperty.UnsetValue;
        }
    }
}
