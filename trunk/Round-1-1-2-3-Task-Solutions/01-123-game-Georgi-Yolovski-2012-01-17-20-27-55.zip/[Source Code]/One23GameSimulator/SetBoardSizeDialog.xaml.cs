﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace One23GameSimulator
{
    /// <summary>
    /// Interaction logic for SetBoardSizeDialog.xaml
    /// </summary>
    public partial class SetBoardSizeDialog : Window
    {
        private int rows;
        private int columns;

        public SetBoardSizeDialog()
        {
            InitializeComponent();

            this.rows = 0;
            this.columns = 0;
        }

        public int Rows
        {
            get { return this.rows; }
            private set { this.rows = value; }
        }

        public int Columns
        {
            get { return this.columns; }
            private set { this.columns = value; }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void brnOK_Click(object sender, RoutedEventArgs e)
        {
            string inputRows = txtRows.Text;
            int resultRows = 0;

            if(String.IsNullOrEmpty(inputRows))
            {
                MessageBox.Show("You should specify the number of rows");
            }
            else if(!Int32.TryParse(inputRows, out resultRows))
            {
                MessageBox.Show("Invalid row count value");
            }
            else if(resultRows < 3 | resultRows > 20)
            {
                MessageBox.Show("The row count should be between 3 and 20");
            }
            else
            {
                this.Rows = resultRows;
            }

            string inputCols = txtCols.Text;
            int resultCols = 0;

            if (String.IsNullOrEmpty(inputCols))
            {
                MessageBox.Show("You should specify the number of columns");
            }
            else if (!Int32.TryParse(inputCols, out resultCols))
            {
                MessageBox.Show("Invalid column count value");
            }
            else if (resultCols < 3 | resultCols > 20)
            {
                MessageBox.Show("The column count should be between 3 and 20");
            }
            else
            {
                this.Columns = resultCols;
            }

            if(this.Rows != 0 && this.Columns != 0)
            {
                this.DialogResult = true;
                this.Close();
            }
        }
    }
}
