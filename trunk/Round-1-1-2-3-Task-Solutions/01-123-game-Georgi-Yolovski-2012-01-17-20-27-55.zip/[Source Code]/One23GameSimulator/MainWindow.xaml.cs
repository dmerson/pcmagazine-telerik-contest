﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using EngineMySuperPlayer;
using One23Game;
using One23GameCore;
using Binding = System.Windows.Forms.Binding;
using MessageBox = System.Windows.MessageBox;

namespace One23GameSimulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private One23GameCore.One23Game game;

        public MainWindow()
        {
            InitializeComponent();

            game = new One23GameCore.One23Game();
            game.PlayingBoard.InitializeBoard(4, 3);
            game.CurrentPlayer = game.PlayerA;
            this.DataContext = game.PlayingBoard;
        }

        private void btnPerformNextMove_Click(object sender, RoutedEventArgs e)
        {
            game.PerformMove(game.CurrentPlayer.MakeBestMove());

            if(game.IsGameOver)
            {
                this.btnPerformNextMove.IsEnabled = false;

                if(game.IsDraw)
                {
                    this.lblWinner.Content = "Draw";
                }
                else
                {
                    this.lblWinner.Content = game.Winner.PlayerName;
                }
            }
        }

        private void btnNewGame_Click(object sender, RoutedEventArgs e)
        {
            game.StartNewGame();
            this.lblWinner.Content = "";
            if (this.game.PlayerA != null && this.game.PlayerB != null)
            {
                this.btnPerformNextMove.IsEnabled = true;
            }
        }

        private void loadPlayer(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = ".NET Assembly (*.dll)|*.dll";
                if(openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    if(sender == this.btnLoadPlayerA)
                    {
                        this.game.PlayerA = PlayerEngine.LoadEngine(openFileDialog.FileName,
                            "Player A", PlayerLetter.A, game.PlayingBoard);

                        this.lblLoadedA.Visibility = Visibility.Visible;
                        this.lblScoreA.DataContext = game.PlayerA;
                        this.lblWinsA.DataContext = game.PlayerA;
                    }
                    else if(sender == this.btnLoadPlayerB)
                    {
                        this.game.PlayerB = PlayerEngine.LoadEngine(openFileDialog.FileName,
                            "Player B", PlayerLetter.B, game.PlayingBoard);

                        this.lblLoadedB.Visibility = Visibility.Visible;
                        this.lblScoreB.DataContext = game.PlayerB;
                        this.lblWinsB.DataContext = game.PlayerB;
                    }
                }

                if(this.game.PlayerA != null && this.game.PlayerB != null)
                {
                    this.btnPerformNextMove.IsEnabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBoardSize_Click(object sender, RoutedEventArgs e)
        {
            SetBoardSizeDialog dialog = new SetBoardSizeDialog();
            if(dialog.ShowDialog() == true)
            {
                this.game.PlayingBoard.InitializeBoard(dialog.Columns,
                    dialog.Rows);
                this.game.StartNewGame();
            }
        }
    }
}
