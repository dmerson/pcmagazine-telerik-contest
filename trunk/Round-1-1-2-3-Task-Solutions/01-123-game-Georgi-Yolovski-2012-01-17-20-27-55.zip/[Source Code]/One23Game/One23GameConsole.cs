﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using One23GameCore;
using EngineMySuperPlayer;

namespace One23Game
{
    class One23GameConsole
    {
        static void Main(string[] args)
        {
            One23GameCore.One23Game game = new One23GameCore.One23Game();
            game.PlayerB = new MySuperPlayer("Player B", PlayerLetter.B, game.PlayingBoard);
            game.PlayerA = new MySuperPlayer("Player A", PlayerLetter.A, game.PlayingBoard);

            while (!game.IsGameOver)
            {
                try
                {
                    Console.WriteLine("Enter your input:");
                    string line = "";
                    StringBuilder sb = new StringBuilder();
                    while (line != "A" && line != "B")
                    {
                        line = Console.ReadLine();
                        sb.AppendLine(line);
                    }
                    
                    game.ParseInput(sb.ToString());
                    Console.WriteLine("The board now:");
                    Console.WriteLine(game.PlayingBoard.ToString());
                    
                    game.PerformMove(game.CurrentPlayer.MakeBestMove());
                    Console.WriteLine("Performing move...");
                    Console.WriteLine("The board now:");
                    Console.WriteLine(game.PlayingBoard.ToString());
                }
                catch (Exception ex)
                {
                    Console.WriteLine("error");
                    Console.WriteLine(ex.Message);
                }
            }

            Console.WriteLine("End of game!");
            Console.WriteLine("The board:");
            Console.WriteLine(game.PlayingBoard.ToString());
            Console.WriteLine("Results:");
            Console.WriteLine("{0}: {1}", game.PlayerA.PlayerName, game.PlayerA.Score);
            Console.WriteLine("{0}: {1}", game.PlayerB.PlayerName, game.PlayerB.Score);

            if(game.IsDraw)
            {
                Console.WriteLine("It's a draw!");
            }
            else
            {
                Console.WriteLine("The winner is {0}", game.Winner.PlayerName);
            }
        }
    }
}
