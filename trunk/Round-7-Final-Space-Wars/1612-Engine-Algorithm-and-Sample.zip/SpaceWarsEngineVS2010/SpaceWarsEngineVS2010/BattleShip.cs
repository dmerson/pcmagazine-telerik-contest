﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    public class BattleShip : MatrixObject
    {
        //These are from the ASCII table
        //const char RIGHT_VISUAL = (char)16;
        //const char LEFT_VISUAL = (char)17;
        //const char UP_VISUAL = (char)30;
        //const char DOWN_VISUAL = (char)31;
        //const char UNKNOWN_VISUAL = '?';
        const char RIGHT_VISUAL = 'r';
        const char LEFT_VISUAL = 'l';
        const char UP_VISUAL = 'u';
        const char DOWN_VISUAL = 'd';
        const char UNKNOWN_VISUAL = '?';

        const int MAX_ROW_SPEED = 1;
        const int MAX_COL_SPEED = 1;

        int rowSpeed;
        int colSpeed;

        int rowDirection;
        int colDirection;

        Direction direction;

        new public const string TYPE_NAME = "battleship";

        char visual;

        public BattleShip(WorldData world, int row = 0, int col = 0, int directionRow = 0, int directionCol = 1)
            : base(world, row, col)
        {
            this.rowDirection = directionRow;
            this.colDirection = directionCol;
            this.UpdateDirection();
            this.UpdateVisualByDirection();
        }

        public BattleShip(WorldData world, string name, int row, int col, Direction direction)
            : base(world, row, col, name)
        {
            this.direction = direction;
            this.UpdateDirectionComponents();
            this.UpdateVisualByDirection();
        }

        public override char GetVisual()
        {
            return this.visual;
        }

        private void UpdateVisualByDirection()
        {
            switch (this.direction)
            {
                case Direction.Left:
                    this.visual = LEFT_VISUAL;
                    break;
                case Direction.Right:
                    this.visual = RIGHT_VISUAL;
                    break;
                case Direction.Up:
                    this.visual = UP_VISUAL;
                    break;
                case Direction.Down:
                    this.visual = DOWN_VISUAL;
                    break;
                default:
                    this.visual = UNKNOWN_VISUAL;
                    break;
            }
        }

        private void UpdateSpeed()
        {
            if (this.rowSpeed > MAX_ROW_SPEED)
            {
                this.rowSpeed = MAX_ROW_SPEED;
            }
            if (this.rowSpeed < -MAX_ROW_SPEED)
            {
                this.rowSpeed = -MAX_ROW_SPEED;
            }
            if (this.colSpeed > MAX_COL_SPEED)
            {
                this.colSpeed = MAX_COL_SPEED;
            }
            if (this.colSpeed < -MAX_COL_SPEED)
            {
                this.colSpeed = -MAX_COL_SPEED;
            }
        }

        public override void UpdateLocation(long totalTurnsCount)
        {
            if (Utils.IsOdd(totalTurnsCount))
            {
                this.Row += rowSpeed;
                this.Col += colSpeed;

                if (!this.IsInWorld())
                {
                    this.Kill();
                    this.world.AddToLog(String.Format("{0} left the world and died", this.Name));
                    this.world.ReportDeath(this.Name);
                    //Console.WriteLine(this.world.GetLogString());
                    //Console.ReadLine();
                }
            }
        }

        private void UpdateDirectionComponents()
        {
            switch (this.direction)
            {
                case Direction.Left:
                    this.rowDirection = 0;
                    this.colDirection = -1;
                    break;
                case Direction.Right:
                    this.rowDirection = 0;
                    this.colDirection = 1;
                    break;
                case Direction.Up:
                    this.rowDirection = -1;
                    this.colDirection = 0;
                    break;
                case Direction.Down:
                    this.rowDirection = 1;
                    this.colDirection = 0;
                    break;
                default:
                    break;
            }
        }

        private void UpdateDirection()
        {
            if (rowDirection == 0)
            {
                if (colDirection == -1)
                {
                    this.direction = Direction.Left;
                }
                else
                {
                    this.direction = Direction.Right;
                }
            }
            else
            {
                if (rowDirection == 1)
                {
                    this.direction = Direction.Down;
                }
                else
                {
                    this.direction = Direction.Up;
                }
            }
        }

        public override void Update(long totalTurnsCount)
        {
            this.UpdateSpeed();
            this.UpdateLocation(totalTurnsCount);
            this.UpdateDirection();
            this.UpdateVisualByDirection();
        }

        public void TurnRight()
        {
            //calculating the perpendicular vector of (moveRow, moveCol) in the counter-clockwise direction
            Utils.Swap(ref this.rowDirection, ref this.colDirection);
            this.colDirection = -this.colDirection;
            this.UpdateDirection();
        }

        public void TurnLeft()
        {
            //calculating the perpendicular vector of (moveRow, moveCol) in the clockwise direction
            Utils.Swap(ref this.rowDirection, ref this.colDirection);
            this.rowDirection = -this.rowDirection;
            this.UpdateDirection();
        }

        public void ApplyDirectionThrust()
        {
            this.rowSpeed += this.rowDirection;
            this.colSpeed += this.colDirection;
        }

        private void ApplyMissileCounterThrust()
        {
            this.rowSpeed -= this.rowDirection;
            this.colSpeed -= this.colDirection;
        }

        public Missile FireMissile()
        {
            Missile firedMissile;
            this.ApplyMissileCounterThrust();
            
            firedMissile = new Missile(this.world, this, this.Row + this.rowDirection, this.Col + this.colDirection, this.direction);

            return firedMissile;
        }

        public override string GetObjectTypeName()
        {
            return BattleShip.TYPE_NAME;
        }
    }
}
