﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SpaceWarsEngine
{
    class SpaceWarsEngine
    {
        const int WORLD_MATRIX_ROWS_COUNT = 40;
        const int WORLD_MATRIX_COLS_COUNT = 50;

        const int ALGORITHM_TIME_LIMIT = 100;

        const string COMMAND_TURN_LEFT_STRING = "L";
        const string COMMAND_TURN_RIGHT_STRING = "R";
        const string COMMAND_APPLY_THRUST_STRING = "E";
        const string COMMAND_FIRE_MISSILE_STRING = "S";
        const string COMMAND_NONE = "N";

        const string FILENAME_TO_READ_ALGORITHM_OUTPUT_FROM = "output.txt";
        const string FILENAME_TO_PRINT_ALGORITHM_INPUT_TO = "input.txt";

        static string playerOneAlgorithmFolderName = "";
        static string playerTwoAlgorithmFolderName = "";
        static bool loadAlgorithms = false;
        static bool visualizeOnConsole = false;
        static int sleepAfterVisualizeMillisecondsCount = 0;

        const string SETTINGS_FILENAME = "settings.txt";
        static string statsFilename = "";
        static string logFilename = "";
        
        static LinkedList<MatrixObject> matrixObjects;
        static List<MatrixObject> enqueuedToAdd = new List<MatrixObject>();
        static WorldData visualWorld;
        static long halfTurnsCount = 0;
        static long realTurnsCount = 0;

        static AlgorithmExecutor playerOne = null;
        static AlgorithmExecutor playerTwo = null;

        static BattleShip playerOneShip = null;
        static BattleShip playerTwoShip = null;

        const char PLAYER_ONE_CARGO_SHIP_VISUAL = '1';
        const char PLAYER_TWO_CARGO_SHIP_VISUAL = '2';

        static List<CargoShip> playerOneCargoShips = null;
        static List<CargoShip> playerTwoCargoShips = null;
        static readonly MatrixCoordinates[] upperLeftCargoShipsCoords = new MatrixCoordinates[]{
            new MatrixCoordinates(1, 1), new MatrixCoordinates(1, 3), new MatrixCoordinates(1, 5),
            new MatrixCoordinates(3, 1), new MatrixCoordinates(3, 3), new MatrixCoordinates(3, 5),
            new MatrixCoordinates(5, 1), new MatrixCoordinates(5, 3), new MatrixCoordinates(5, 5),
        };

        static readonly MatrixCoordinates playerOneShipCoords = new MatrixCoordinates(7, 7);
        static readonly MatrixCoordinates playerTwoShipCoords = Utils.GetSymetricMatrixCoords(playerOneShipCoords, WORLD_MATRIX_ROWS_COUNT, WORLD_MATRIX_COLS_COUNT);

        private static void LoadSettings()
        {
            string[] settingsLines = System.IO.File.ReadAllLines(SETTINGS_FILENAME);
            playerOneAlgorithmFolderName = settingsLines[0];
            playerTwoAlgorithmFolderName = settingsLines[1];
            if (settingsLines[2] == "visualizeOnConsoleTrue")
            {
                visualizeOnConsole = true;
            }
            else
            {
                visualizeOnConsole = false;
            }

            if (settingsLines[3] == "loadAlgorithmsTrue")
            {
                loadAlgorithms = true;
            }
            else
            {
                loadAlgorithms = false;
            }

            sleepAfterVisualizeMillisecondsCount = int.Parse(settingsLines[4]);

            statsFilename = playerOneAlgorithmFolderName + "-vs-" + playerTwoAlgorithmFolderName + ".stat";
            logFilename = playerOneAlgorithmFolderName + "-vs-" + playerTwoAlgorithmFolderName + ".log";
        }

        private static void InitializeCargoShips()
        {
            playerOneCargoShips = new List<CargoShip>();
            playerTwoCargoShips = new List<CargoShip>();

            foreach (var coords in upperLeftCargoShipsCoords)
            {
                playerOneCargoShips.Add(new CargoShip(visualWorld, playerOneShip,
                    coords,
                    "Cargo ship of player " + playerOneShip.Name, PLAYER_ONE_CARGO_SHIP_VISUAL));

                playerTwoCargoShips.Add(new CargoShip(visualWorld, playerTwoShip,
                    Utils.GetSymetricMatrixCoords(coords, visualWorld.MatrixRows, visualWorld.MatrixCols),
                    "Cargo ship of player " + playerTwoShip.Name, PLAYER_TWO_CARGO_SHIP_VISUAL));
            }

            foreach (var cargoShip in playerOneCargoShips)
            {
                SpaceWarsEngine.AddObject(cargoShip);
            }

            foreach (var cargoShip in playerTwoCargoShips)
            {
                SpaceWarsEngine.AddObject(cargoShip);
            }
        }

        private static void InitializeBattleShips()
        {
            playerOneShip = new BattleShip(visualWorld, playerOneAlgorithmFolderName, playerOneShipCoords.Row, playerOneShipCoords.Col, Direction.Right);
            playerTwoShip = new BattleShip(visualWorld, playerTwoAlgorithmFolderName, playerTwoShipCoords.Row, playerTwoShipCoords.Col, Direction.Left);
        }

        static void InitializeAlgorithms()
        {
            SpaceWarsEngine.playerOne = new AlgorithmExecutor(playerOneAlgorithmFolderName);
            SpaceWarsEngine.playerTwo = new AlgorithmExecutor(playerTwoAlgorithmFolderName);
        }

        public static void Initialize()
        {
            SpaceWarsEngine.LoadSettings();
            
            visualWorld = new WorldData(WORLD_MATRIX_ROWS_COUNT, WORLD_MATRIX_COLS_COUNT, new string[] { playerOneAlgorithmFolderName, playerTwoAlgorithmFolderName});
            matrixObjects = new LinkedList<MatrixObject>();

            if (loadAlgorithms)
            {
                SpaceWarsEngine.InitializeAlgorithms();
            }
            SpaceWarsEngine.InitializeBattleShips();
            SpaceWarsEngine.InitializeCargoShips();

            SpaceWarsEngine.AddObject(playerOneShip);
            SpaceWarsEngine.AddObject(playerTwoShip);

            Random rand = new Random();
            for (int i = 0; i < 200; i++)
            {
                SpaceWarsEngine.EnqueueObject(new MatrixObject(visualWorld, rand.Next(10, WORLD_MATRIX_ROWS_COUNT - 10), rand.Next(10, WORLD_MATRIX_COLS_COUNT - 10)));
            }
        }

        static void KillObject(MatrixObject obj)
        {
            obj.Kill();
        }

        static void EnqueueObject(MatrixObject obj)
        {
            SpaceWarsEngine.enqueuedToAdd.Add(obj);
        }

        static void AddObject(MatrixObject obj)
        {
            SpaceWarsEngine.matrixObjects.AddLast(obj);
        }

        static void AddEnqueuedObjects()
        {
            foreach (var obj in enqueuedToAdd)
            {
                SpaceWarsEngine.matrixObjects.AddLast(obj);
            }
            SpaceWarsEngine.enqueuedToAdd.Clear();
        }

        static void RemoveKilled()
        {
            List<LinkedListNode<MatrixObject>> toRemove = new List<LinkedListNode<MatrixObject>>();
            LinkedListNode<MatrixObject> currentNode = matrixObjects.First;
            while (currentNode != null)
            {
                if (!currentNode.Value.IsAlive())
                {
                    toRemove.Add(currentNode);
                }
                currentNode = currentNode.Next;
            }

            foreach (var nodeToRemove in toRemove)
            {
                matrixObjects.Remove(nodeToRemove);
            }
        }

        static bool IsGameOver()
        {
            bool bothPlayersDead = (!playerOneShip.IsAlive()) && (!playerTwoShip.IsAlive());
            if (bothPlayersDead)
            {
                return true;
            }
            else
            {
                if (playerOneShip.IsAlive() && (!playerTwoShip.IsAlive()))
                {
                    foreach (var ship in playerTwoCargoShips)
                    {
                        if (ship.IsAlive())
                        {
                            return false;
                        }
                    }
                    return true;
                }
                else if ((!playerOneShip.IsAlive()) && playerTwoShip.IsAlive())
                {
                    foreach (var ship in playerOneCargoShips)
                    {
                        if (ship.IsAlive())
                        {
                            return false;
                        }
                    }
                    return true;

                }
            }

            return false;
        }

        static void GameLoop()
        {
            while (!IsGameOver())
            {
                halfTurnsCount++;
                realTurnsCount = halfTurnsCount / 2;

                HandleOutput(); //i.e. display

                if (Utils.IsOdd(halfTurnsCount))
                {
                    HandleInput();
                }

                UpdateObjects();

                AddEnqueuedObjects();

                HandleCollisions();

                SpaceWarsEngine.RemoveKilled();

                //debug
                //var stat = SpaceWarsEngine.visualWorld.GetPlayerStatCopy(playerOneAlgorithmFolderName);
                ////Console.WriteLine(stat.PlayerName + " " + stat.Kills + " " + stat.Deaths);
                //stat = SpaceWarsEngine.visualWorld.GetPlayerStatCopy(playerTwoAlgorithmFolderName);
                ////Console.WriteLine(stat.PlayerName + " " + stat.Kills + " " + stat.Deaths);
                //end debug
            }
        }

        public static void CreateLogAndStatsFiles()
        {
            PlayerStat playerOneStat = SpaceWarsEngine.visualWorld.GetPlayerStatCopy(playerOneAlgorithmFolderName),
                playerTwoStat = SpaceWarsEngine.visualWorld.GetPlayerStatCopy(playerTwoAlgorithmFolderName);

            System.IO.File.WriteAllText(statsFilename,
                playerOneStat.PlayerName + " " + (playerOneStat.Kills - playerOneStat.Deaths) + "\r\n" +
                playerTwoStat.PlayerName + " " + (playerTwoStat.Kills - playerTwoStat.Deaths) + "\r\n"
                );

            System.IO.File.WriteAllText(logFilename, SpaceWarsEngine.visualWorld.GetLogString());
        }

        private static void HandleOutput()
        {
            if (visualizeOnConsole)
            {
                HandleOutputConsole();
            }
            if (loadAlgorithms)
            {
                HandleOutputToAlgorithms();
            }
        }

        private static void HandleOutputToAlgorithms()
        {
            StringBuilder outputForPlayerOne = new StringBuilder();
            StringBuilder outputForPlayerTwo = new StringBuilder();

            outputForPlayerOne.Append(
                realTurnsCount + "\r\n" + 
                playerOneShip.Row + " " + playerOneShip.Col + "\r\n" +
                PLAYER_ONE_CARGO_SHIP_VISUAL + "\r\n"
                );
            outputForPlayerTwo.Append(
                realTurnsCount + "\r\n" +
                playerTwoShip.Row + " " + playerTwoShip.Col + "\r\n" +
                PLAYER_TWO_CARGO_SHIP_VISUAL + "\r\n"
                );

            SpaceWarsEngine.visualWorld.Clear();
            SpaceWarsEngine.visualWorld.Render(SpaceWarsEngine.matrixObjects);

            string printText = SpaceWarsEngine.visualWorld.GetPrintText();
            outputForPlayerOne.Append(printText);
            outputForPlayerTwo.Append(printText);

            string outputFilenameForPlayerOne = playerOneAlgorithmFolderName + "/" + FILENAME_TO_PRINT_ALGORITHM_INPUT_TO;
            string outputFilenameForPlayerTwo = playerTwoAlgorithmFolderName + "/" + FILENAME_TO_PRINT_ALGORITHM_INPUT_TO;

            System.IO.File.WriteAllText(outputFilenameForPlayerOne, outputForPlayerOne.ToString());
            System.IO.File.WriteAllText(outputFilenameForPlayerTwo, outputForPlayerTwo.ToString());
        }

        private static void HandleOutputConsole()
        {
            SpaceWarsEngine.visualWorld.Clear();
            SpaceWarsEngine.visualWorld.Render(SpaceWarsEngine.matrixObjects);
            System.Console.Clear();
            SpaceWarsEngine.visualWorld.Print();
            if (sleepAfterVisualizeMillisecondsCount != 0)
            {
                Thread.Sleep(sleepAfterVisualizeMillisecondsCount);
            }
        }

        private static void HandleCollisions()
        {
            var allCollisions = CollisionDetection.GetCollisions(matrixObjects);

            foreach (var collisionPair in allCollisions)
            {
                SpaceWarsEngine.AddObject(new Explosion(visualWorld, collisionPair.ObjectA.Row, collisionPair.ObjectA.Col));
                SpaceWarsEngine.AddObject(new Explosion(visualWorld, collisionPair.ObjectB.Row, collisionPair.ObjectB.Col));
                KillObject(collisionPair.ObjectA);
                KillObject(collisionPair.ObjectB);

                HandleCollisionsLoggingAndStats(collisionPair);
            }
        }

        private static void HandleCollisionsLoggingAndStats(CollisionPair<MatrixObject> collisionPair)
        {
            string objATypeName = collisionPair.ObjectA.GetObjectTypeName();
            string objBTypeName = collisionPair.ObjectB.GetObjectTypeName();
            if (!SpaceWarsEngine.HandleCollisionsLoggingAndStatsForBattleShips(collisionPair, objATypeName, objBTypeName))
            {
                SpaceWarsEngine.HandleCollisionLoggingAndStatsForMissiles(collisionPair, objATypeName, objBTypeName);
            }

        }

        /// <summary>
        /// Handles Missile on CargoShip collision
        /// </summary>
        /// <param name="collisionPair"></param>
        /// <param name="objATypeName"></param>
        /// <param name="objBTypeName"></param>
        /// <returns>Returns true if collision was handled</returns>
        private static bool HandleCollisionLoggingAndStatsForMissiles(CollisionPair<MatrixObject> collisionPair, string objATypeName, string objBTypeName)
        {
            //string logString = "";
            bool collisionHandled = false;

            if (objATypeName == Missile.TYPE_NAME)
            {
                if (objBTypeName == CargoShip.TYPE_NAME)
                {
                    if (collisionPair.ObjectA.Owner.Name == collisionPair.ObjectB.Owner.Name)
                    {
                        SpaceWarsEngine.visualWorld.ReportFriendlyFire(collisionPair.ObjectA.Owner.Name);
                        collisionHandled = true;
                    }
                    else
                    {
                        SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectA.Owner.Name, ""));
                        collisionHandled = true;
                    }
                }
            }

            else if (objBTypeName == Missile.TYPE_NAME)
            {
                if (objATypeName == CargoShip.TYPE_NAME)
                {
                    if (collisionPair.ObjectB.Owner.Name == collisionPair.ObjectA.Owner.Name)
                    {
                        SpaceWarsEngine.visualWorld.ReportFriendlyFire(collisionPair.ObjectB.Owner.Name);
                        collisionHandled = true;
                    }
                    else
                    {
                        SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectB.Owner.Name, ""));
                        collisionHandled = true;
                    }
                }
            }

            return collisionHandled;
        }

        /// <summary>
        /// Handles collision if BattleShip on BattleShip, BattleShip on Missile, BattleShip on Object(asteroid) and BattleShip on CargoShip collision
        /// </summary>
        /// <param name="collisionPair"></param>
        /// <param name="objATypeName"></param>
        /// <param name="objBTypeName"></param>
        /// <returns>Returns true if the collision was handled</returns>
        private static bool HandleCollisionsLoggingAndStatsForBattleShips(CollisionPair<MatrixObject> collisionPair, string objATypeName, string objBTypeName)
        {
            string logString = "";
            bool collisionHandled = false;

            if (objATypeName == BattleShip.TYPE_NAME)
            {
                if (objBTypeName == Missile.TYPE_NAME)
                {
                    logString = String.Format("{0} kills {1}", collisionPair.ObjectB.Owner.Name, collisionPair.ObjectA.Name);
                    SpaceWarsEngine.visualWorld.AddToLog(logString);
                    SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectB.Owner.Name, collisionPair.ObjectA.Name));
                    collisionHandled = true;
                }

                else
                {
                    if (objBTypeName == CargoShip.TYPE_NAME)
                    {
                        if (collisionPair.ObjectA.Name == collisionPair.ObjectB.Owner.Name)
                        {
                            SpaceWarsEngine.visualWorld.ReportFriendlyFire(collisionPair.ObjectA.Name);
                            SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectA.Name);
                            collisionHandled = true;
                        }
                        else
                        {
                            SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectA.Name, ""));
                            SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectA.Name);
                            collisionHandled = true;
                        }
                    }
                    else
                    {
                        logString = String.Format("{0} kills self", collisionPair.ObjectA.Name);
                        SpaceWarsEngine.visualWorld.AddToLog(logString);
                        SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectA.Name);
                        collisionHandled = true;
                    }
                }
            }

            if (objBTypeName == BattleShip.TYPE_NAME)
            {
                if (objATypeName == Missile.TYPE_NAME)
                {
                    logString = String.Format("{0} kills {1}", collisionPair.ObjectA.Owner.Name, collisionPair.ObjectB.Name);
                    SpaceWarsEngine.visualWorld.AddToLog(logString);
                    SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectA.Owner.Name, collisionPair.ObjectB.Name));
                    collisionHandled = true;
                }
                else
                {
                    if (objATypeName == CargoShip.TYPE_NAME)
                    {
                        if (collisionPair.ObjectB.Name == collisionPair.ObjectA.Owner.Name)
                        {
                            SpaceWarsEngine.visualWorld.ReportFriendlyFire(collisionPair.ObjectB.Name);
                            SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectB.Name);
                            collisionHandled = true;
                        }
                        else
                        {
                            SpaceWarsEngine.visualWorld.ReportKill(new KillReport(collisionPair.ObjectB.Name, ""));
                            SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectB.Name);
                            collisionHandled = true;
                        }
                    }
                    else
                    {
                        logString = String.Format("{0} kills self", collisionPair.ObjectB.Name);
                        SpaceWarsEngine.visualWorld.AddToLog(logString);
                        SpaceWarsEngine.visualWorld.ReportDeath(collisionPair.ObjectB.Name);
                        collisionHandled = true;
                    }
                }
            }

            //if (logString.Length > 0)
            //{
            //    //Console.WriteLine(SpaceWarsEngine.visualWorld.GetLogString());
            //    Console.ReadLine();
            //}

            return collisionHandled;
        }

        private static void UpdateObjects()
        {
            foreach (var obj in matrixObjects)
            {
                obj.Update(halfTurnsCount);
            }
        }

        private static void HandleInput()
        {
            if (loadAlgorithms)
            {
                HandleInputFromAlgorithms();
            }
            else
            {
                HandleInputFromConsole();
            }
        }

        private static void HandleInputFromAlgorithms()
        {
            if (playerOneShip.IsAlive())
            {
                playerOne.StartWaitAndKill(ALGORITHM_TIME_LIMIT);
            }
            if (playerTwoShip.IsAlive())
            {
                playerTwo.StartWaitAndKill(ALGORITHM_TIME_LIMIT);
            }

            string playerOneAlgorithmInput = COMMAND_NONE;
            string playerTwoAlgorithmInput = COMMAND_NONE;

            string playerOneAlgorithmInputFile = playerOneAlgorithmFolderName + "/" + FILENAME_TO_READ_ALGORITHM_OUTPUT_FROM;
            string playerTwoAlgorithmInputFile = playerTwoAlgorithmFolderName + "/" + FILENAME_TO_READ_ALGORITHM_OUTPUT_FROM;

            if (playerOneShip.IsAlive())
            {
                playerOneAlgorithmInput = SpaceWarsEngine.GetAlgorithmCommand(playerOneAlgorithmInputFile);
            }
            if (playerTwoShip.IsAlive())
            {
                playerTwoAlgorithmInput = SpaceWarsEngine.GetAlgorithmCommand(playerTwoAlgorithmInputFile);
            }

            switch (playerOneAlgorithmInput)
            {
                case COMMAND_TURN_LEFT_STRING:
                    playerOneShip.TurnLeft();
                    break;
                case COMMAND_TURN_RIGHT_STRING:
                    playerOneShip.TurnRight();
                    break;
                case COMMAND_APPLY_THRUST_STRING:
                    playerOneShip.ApplyDirectionThrust();
                    break;
                case COMMAND_FIRE_MISSILE_STRING:
                    SpaceWarsEngine.EnqueueObject(playerOneShip.FireMissile());
                    break;
                default:
                    break;
            }

            switch (playerTwoAlgorithmInput)
            {
                case COMMAND_TURN_LEFT_STRING:
                    playerTwoShip.TurnLeft();
                    break;
                case COMMAND_TURN_RIGHT_STRING:
                    playerTwoShip.TurnRight();
                    break;
                case COMMAND_APPLY_THRUST_STRING:
                    playerTwoShip.ApplyDirectionThrust();
                    break;
                case COMMAND_FIRE_MISSILE_STRING:
                    SpaceWarsEngine.EnqueueObject(playerTwoShip.FireMissile());
                    break;
                default:
                    break;
            }
        }

        private static string GetAlgorithmCommand(string playerOneAlgorithmInputFile)
        {
            if (System.IO.File.Exists(playerOneAlgorithmInputFile))
            {
                return System.IO.File.ReadAllText(playerOneAlgorithmInputFile).Substring(0, 1);
            }

            return "N";
        }

        private static void HandleInputFromConsole()
        {
            if (Console.KeyAvailable)
            {
                ConsoleKeyInfo keyPressed = Console.ReadKey();
                if (playerOneShip.IsAlive())
                {
                    if (keyPressed.KeyChar == 'a')
                    {
                        playerOneShip.TurnLeft();
                    }
                    if (keyPressed.KeyChar == 'd')
                    {
                        playerOneShip.TurnRight();
                    }
                    if (keyPressed.KeyChar == 'w')
                    {
                        playerOneShip.ApplyDirectionThrust();
                    }
                    if (keyPressed.Key == ConsoleKey.Spacebar)
                    {
                        SpaceWarsEngine.EnqueueObject(playerOneShip.FireMissile());
                    }
                }
                if (keyPressed.KeyChar == 'p')
                {
                    foreach (var ship in playerTwoCargoShips)
                    {
                        ship.Kill();
                    }
                }
                if (keyPressed.KeyChar == 'o')
                {
                    foreach (var ship in playerOneCargoShips)
                    {
                        ship.Kill();
                    }
                }

            }
        }

        static void Main(string[] args)
        {
            SpaceWarsEngine.Initialize();
            SpaceWarsEngine.GameLoop();
            SpaceWarsEngine.CreateLogAndStatsFiles();
        }
    }
}
