﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlgorithmExecutorTester
{
    class AlgorithmExecutorTester
    {
        static void Main(string[] args)
        {
            AlgorithmExecutor alg = new AlgorithmExecutor("TestExe");
            
            alg.StartAlgorithm();
            alg.SendInput("asd\n");
            alg.SendInput("asd\n");

            List<string> algOutput = new List<string>();
            alg.GetOutput((object) algOutput);

            foreach (string line in algOutput)
            {
                //Console.WriteLine(line);
            }
            alg.KillAlgorithm();
        }
    }
}
