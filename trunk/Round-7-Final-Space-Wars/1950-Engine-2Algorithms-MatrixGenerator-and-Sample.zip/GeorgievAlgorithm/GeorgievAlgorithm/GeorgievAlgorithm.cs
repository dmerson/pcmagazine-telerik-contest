﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeorgievAlgorithm
{
    class GeorgievAlgorithm
    {
        const int WORLD_MATRIX_ROWS_COUNT = 40;
        const int WORLD_MATRIX_COLS_COUNT = 50;

        static void Main(string[] args)
        {
            string[] inputLines = System.IO.File.ReadAllLines("input.txt");

            int turnNumber = int.Parse(inputLines[0]);

            string[] rowAndColStrings = inputLines[1].Split(' ');
            int shipRow = int.Parse(rowAndColStrings[0]);
            int shipCol = int.Parse(rowAndColStrings[1]);

            char friendlyCargoSymbol = inputLines[2][0];
            char enemyCargoSymbol;
            if (friendlyCargoSymbol == '1')
            {
                enemyCargoSymbol = '2';
            }
            else
            {
                enemyCargoSymbol = '1';
            }

            bool enemyCargoOnSameCol = false;
            char neededDirection = ' ';
            for (int matrixRow = 0; matrixRow < WORLD_MATRIX_ROWS_COUNT; matrixRow++)
            {
                if (inputLines[3 + matrixRow][shipCol] == enemyCargoSymbol)
                {
                    enemyCargoOnSameCol = true;
                    if (matrixRow > shipRow)
                    {
                        neededDirection = 'd';
                    }
                    else
                    {
                        neededDirection = 'u';
                    }
                    break;
                }
            }

            bool isMoving = !System.IO.File.Exists("stopped");

            if (enemyCargoOnSameCol)
            {
                char currentDirection = inputLines[3 + shipRow][shipCol];
                if (neededDirection == currentDirection)
                {
                    System.IO.File.WriteAllText("output.txt", "S");
                    System.IO.File.Delete("stopped");
                }
                else
                {
                    if (isMoving)
                    {
                        System.IO.File.WriteAllText("output.txt", "S");
                        System.IO.File.Create("stopped");
                    }
                    else
                    {
                        System.IO.File.WriteAllText("output.txt", "L");
                    }
                }
            }

            else
            {
                System.IO.File.WriteAllText("output.txt", "E");
            }
        }
    }
}
