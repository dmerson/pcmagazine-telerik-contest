﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceWarsEngine
{
    public class MatrixCoordinates
    {
        public int Row { get; protected set; }
        public int Col { get; protected set; }

        public MatrixCoordinates(int row = 0, int col = 0)
        {
            this.Row = row;
            this.Col = col;
        }
    }

    public class MatrixObject
    {
        public const char MATRIX_OBJECT_VISUAL = '#';
        private int row;
        public int Row 
        {
            get
            {
                return this.row;
            }

            protected set
            {
                this.PrevRow = this.Row;
                this.row = value;
            }
        }
        private int col;
        public int Col 
        {
            get
            {
                return this.col;
            }

            protected set
            {
                this.PrevCol = this.Col;
                this.col = value;
            }
        }

        public int PrevRow { get; protected set; }
        public int PrevCol { get; protected set; }

        public bool HasCollided { get; set; }

        public string Name { get; private set; }

        protected WorldData world;
        protected bool isAlive;

        public const string TYPE_NAME = "object";

        public MatrixObject Owner { get; protected set; }

        public MatrixObject(WorldData world, int row = 0, int col = 0, string name = "")
        {
            this.Row = row;
            this.Col = col;
            this.world = world;
            this.isAlive = true;
            this.PrevRow = this.Row;
            this.PrevCol = this.Col;
            this.Name = name;
        }

        public virtual char GetVisual()
        {
            return MatrixObject.MATRIX_OBJECT_VISUAL;
        }

        public bool IsInWorld()
        {
            return ((this.Row >= 0) && (this.Row < this.world.MatrixRows)) &&
                ((this.Col >= 0) && (this.Col < this.world.MatrixCols));
        }

        private void ReturnToPreviousCoordinates()
        {
            this.Row = this.PrevRow;
            this.Col = this.PrevCol;

            //there are no previous coordinates, so we make them the same as the current
            this.PrevRow = this.Row;
            this.PrevCol = this.Col;
        }


        /// <summary>
        /// Checks if the object is in the bounds of the world (matrix) and returns it to its previous location if not (which is asumed to be in the world)
        /// </summary>
        /// <returns>True means the object was out of the world and it was returned. False means the object was in the world and was kept its position wasn't changed</returns>
        public bool ReturnToWorld()
        {
            if (!this.IsInWorld())
            {
                this.ReturnToPreviousCoordinates();
                return true;
            }
            return false;
        }

        public virtual void Kill()
        {
            this.isAlive = false;
        }


        public virtual void Update(long totalHalfTurnsCount)
        {

        }

        public virtual string GetObjectTypeName()
        {
            return MatrixObject.TYPE_NAME;
        }

        public virtual bool CollidesWithSameType()
        {
            return true;
        }

        public virtual void UpdateLocation(long totalTurnsCount)
        {
        }

        public virtual bool CanCollide()
        {
            return true;
        }

        public override int GetHashCode()
        {
            return (this.row * 7 + this.col) * this.Name.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            MatrixObject other = obj as MatrixObject;
            return this.row == other.row && this.col == other.col && this.Name == other.Name; 
        }

        public bool IsAlive()
        {
            return this.isAlive;
        }
    }
}
