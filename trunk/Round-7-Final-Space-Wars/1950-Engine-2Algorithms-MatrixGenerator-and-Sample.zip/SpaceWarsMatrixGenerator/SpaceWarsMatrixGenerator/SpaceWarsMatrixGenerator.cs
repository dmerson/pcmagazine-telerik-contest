﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceWarsMatrixGenerator
{
    public class MatrixCoordinates
    {
        public int Row { get; protected set; }
        public int Col { get; protected set; }

        public MatrixCoordinates(int row = 0, int col = 0)
        {
            this.Row = row;
            this.Col = col;
        }
    }

    class SpaceWarsMatrixGenerator
    {
        const int MATRIX_ROWS = 40;
        const int MATRIX_COLS = 50;

        const int LAST_NON_GENERATABLE_UPPER_LEFT_ROW = 12;
        const int LAST_NON_GENERATABLE_UPPER_LEFT_COL = 12;

        static Random rand = new Random();

        public static MatrixCoordinates GetSymmetricMatrixCoords(MatrixCoordinates coords, int matrixRows, int matrixCols)
        {
            return new MatrixCoordinates(matrixRows - coords.Row - 1, matrixCols - coords.Col - 1);
        }

        static void MarkNonGeneratableCells(bool[,] occupiedCellsMatrix)
        {
            for (int row = 0; row < LAST_NON_GENERATABLE_UPPER_LEFT_ROW; row++)
            {
                for (int col = 0; col < LAST_NON_GENERATABLE_UPPER_LEFT_COL; col++)
                {
                    MatrixCoordinates coordsToMark = new MatrixCoordinates(row, col),
                        symmetricCoordsToMark = GetSymmetricMatrixCoords(coordsToMark, occupiedCellsMatrix.GetLength(0), occupiedCellsMatrix.GetLength(1));
                    occupiedCellsMatrix[row, col] = true;
                    occupiedCellsMatrix[symmetricCoordsToMark.Row, symmetricCoordsToMark.Col] = true;
                }
            }
        }

        static void PrintMatrix(bool[,] matrix)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write(matrix[row, col] ? "1" : "0");
                }
                Console.WriteLine();
            }
        }

        static void PrintMatrix(char[,] matrix)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write(matrix[row, col]);
                }
                Console.Write('.');
                Console.WriteLine();
            }
        }

        static void TryPlaceInRandomCells(char symbol, int count, char[,] matrix, bool[,] occupiedCellsMatrix)
        {
            for (int i = 0; i < count; i++)
            {
                MatrixCoordinates randomCell = new MatrixCoordinates(rand.Next(0, MATRIX_ROWS), rand.Next(0, MATRIX_COLS));

                if (!occupiedCellsMatrix[randomCell.Row, randomCell.Col])
                {
                    occupiedCellsMatrix[randomCell.Row, randomCell.Col] = true;
                    matrix[randomCell.Row, randomCell.Col] = symbol;
                }

                MatrixCoordinates symmetricRandomCell = GetSymmetricMatrixCoords(randomCell, matrix.GetLength(0), matrix.GetLength(1));
                if (!occupiedCellsMatrix[symmetricRandomCell.Row, symmetricRandomCell.Col])
                {
                    occupiedCellsMatrix[symmetricRandomCell.Row, symmetricRandomCell.Col] = true;
                    matrix[symmetricRandomCell.Row, symmetricRandomCell.Col] = symbol;
                }
            }

        }

        static void Main(string[] args)
        {
            char[,] matrix = new char[MATRIX_ROWS, MATRIX_COLS];
            bool[,] occupiedCellsMatrix = new bool[MATRIX_ROWS, MATRIX_COLS];

            Console.WriteLine("Asteroids to generate count:");
            int asteroidsToGenerateCount = int.Parse(Console.ReadLine());

            MarkNonGeneratableCells(occupiedCellsMatrix);
            TryPlaceInRandomCells('#', asteroidsToGenerateCount, matrix, occupiedCellsMatrix);
            //PrintMatrix(occupiedCellsMatrix);
            PrintMatrix(matrix);
        }
    }
}
