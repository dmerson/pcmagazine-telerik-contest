﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SpaceWarsSimulator
{
    /// <summary>
    /// Interaction logic for GameField.xaml
    /// </summary>
    public partial class GameField : Window
    {
        public GameField()
        {
            InitializeComponent();
        }
        public GameField(string MapPath, string EnginePathA, string EnginePathB)
        {
            InitializeComponent();
            System.IO.StreamReader file = new System.IO.StreamReader(MapPath);
            string text = file.ReadLine();
            text = file.ReadLine();
            int PlayerNumber = int.Parse(file.ReadLine());
            text = file.ReadLine();
            int line = 0;
            for (int j = 0; j < 40; j++)
            {
                for (int i = 0; i < 50; i++)
                {
                    if (text[i] == ' ')
                    {
                        continue;
                    }
                    if (text[i] == '#')
                    {
                        Meteor newMeteor = new Meteor();
                        newMeteor.Height = 15;
                        newMeteor.Width = 15;
                        Canvas.SetLeft(newMeteor, i * 15);
                        Canvas.SetTop(newMeteor, line * 15);
                        gameBoard1.Field.Children.Add(newMeteor);
                        continue;
                    }
                    if (text[i] == 'o')
                    {
                        Rocket newRocket = new Rocket();
                        newRocket.Height = 15;
                        newRocket.Width = 15;
                        Canvas.SetLeft(newRocket, i * 15);
                        Canvas.SetTop(newRocket, line * 15);
                        //line++;
                        gameBoard1.Field.Children.Add(newRocket);
                        continue;
                    }
                    if (text[i] == '*')
                    {
                        Explosion newExplosion = new Explosion();
                        newExplosion.Height = 15;
                        newExplosion.Width = 15;
                        Canvas.SetLeft(newExplosion, i * 15);
                        Canvas.SetTop(newExplosion, line * 15);
                        //line++;
                        gameBoard1.Field.Children.Add(newExplosion);
                        continue;
                    }
                    if (text[i] == 'u')
                    {
                        FighterShip newFShip = new FighterShip();
                        if (PlayerNumber != 1)
                        {
                            newFShip.IsBlue = false;
                            newFShip.Ship.Fill = new SolidColorBrush(Colors.Red);
                        }
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        //line++;
                        gameBoard1.Field.Children.Add(newFShip);
                        continue;
                    }
                    if (text[i] == 'r')
                    {
                        FighterShip newFShip = new FighterShip();
                        if (PlayerNumber != 1)
                        {
                            newFShip.IsBlue = false;
                            newFShip.Ship.Fill = new SolidColorBrush(Colors.Red);
                        }
                        
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        //newFShip.RenderTransform = new RotateTransform(90, i * 15, line * 15);
                        //line++;
                        gameBoard1.Field.Children.Add(newFShip);
                        continue;
                    }
                    if (text[i] == 'd')
                    {
                        FighterShip newFShip = new FighterShip();
                        if (PlayerNumber != 1)
                        {
                            newFShip.IsBlue = false;
                            newFShip.Ship.Fill = new SolidColorBrush(Colors.Red);
                        }
                        
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        newFShip.Rotate(180);
                        //line++;
                        gameBoard1.Field.Children.Add(newFShip);
                        continue;
                    }
                    if (text[i] == 'l')
                    {
                        FighterShip newFShip = new FighterShip();
                        if (PlayerNumber != 1)
                        {
                            newFShip.IsBlue = false;
                            newFShip.Ship.Fill = new SolidColorBrush(Colors.Red);
                        }
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        //newFShip.RenderTransform = new RotateTransform(270, i * 15 + 7.5, line * 15 + 7.5);
                        //line++;
                        gameBoard1.Field.Children.Add(newFShip);
                        continue;
                    }
                    if (text[i] == '1')
                    {
                        CargoShip newFShip = new CargoShip();
                        //newFShip.RenderTransform = new RotateTransform(270, i * 15 + 7.5, line * 15 + 7.5);
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        //line++;
                        gameBoard1.Field.Children.Add(newFShip);
                        continue;
                    }
                    if (text[i] == '2')
                    {
                        CargoShip newFShip = new CargoShip();
                        newFShip.IsBlue = false;
                        newFShip.Ship.Fill = new SolidColorBrush(Colors.Red);
                        //newFShip.Height = 15;
                        //newFShip.Width = 15;
                        Canvas.SetLeft(newFShip, i * 15);
                        Canvas.SetTop(newFShip, line * 15);
                        gameBoard1.Field.Children.Add(newFShip);
                        //line++;
                        continue;
                    }
                }
                line++;
                text = file.ReadLine();
            }
            file.Close();
        }
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
