﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace SpaceWarsSimulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            engineSelector1.playerLabel.Content = "Player 1";
            engineSelector2.playerLabel.Content = "Player 2";

        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            for (int i = App.Current.Windows.Count - 1; i >= 0; i--)
            {
                if (App.Current.Windows[i] == this)
                {
                    continue;
                }
                App.Current.Windows[i].Close();
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (MapBox1.Text!=null && engineSelector1.BrowseBox.Text!=null && engineSelector1.BrowseBox.Text!=null)
            {
                GameField newField = new GameField(MapBox1.Text, engineSelector1.BrowseBox.Text, engineSelector2.BrowseBox.Text);
                newField.Show();
            }
            else
            {
                MessageBox.Show("Unable to start game!");
            }
            
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Map"; // Default file name
            dlg.DefaultExt = ".txt"; // Default file extension
            dlg.Filter = "Engine (.txt)|*.txt"; // Filter files by extension
            dlg.CheckFileExists = true;

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;
                MapBox1.Text = filename;
            }
        }
    }
}
