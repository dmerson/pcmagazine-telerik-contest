﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SpaceWarsSimulator
{
    /// <summary>
    /// Interaction logic for GameBoard.xaml
    /// </summary>
    public partial class GameBoard : UserControl
    {
        public GameBoard()
        {
            InitializeComponent();


            double CELL_SIZE = 15;
            for (int i = 0; i < 40; i++)
            {
                for (int j = 0; j < 50; j++)
                {
                    Image newCell = new Image();
                    BitmapImage bi = new BitmapImage(new Uri("Images/Cell_Empty.png", UriKind.Relative));
                    newCell.Source = bi;
                    newCell.Width = CELL_SIZE;
                    newCell.Height = CELL_SIZE;
                    Canvas.SetLeft(newCell, CELL_SIZE * j);
                    Canvas.SetTop(newCell, CELL_SIZE * i);
                    Field.Children.Add(newCell);
                }
            }
        }
    }
}
