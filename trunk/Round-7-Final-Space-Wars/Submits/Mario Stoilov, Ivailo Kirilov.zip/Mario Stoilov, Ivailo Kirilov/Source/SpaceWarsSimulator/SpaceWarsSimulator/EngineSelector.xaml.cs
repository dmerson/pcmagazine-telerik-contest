﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace SpaceWarsSimulator
{
    /// <summary>
    /// Interaction logic for EngineSelector.xaml
    /// </summary>
    public partial class EngineSelector : UserControl
    {
        public EngineSelector()
        {
            InitializeComponent();
        }

        private void autoMoveRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            secondsSlider.IsEnabled = true;
        }

        private void autoMoveRadioButton_Unchecked(object sender, RoutedEventArgs e)
        {
            secondsSlider.IsEnabled = false;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Engine"; // Default file name
            dlg.DefaultExt = ".exe"; // Default file extension
            dlg.Filter = "Engine (.exe)|*.exe"; // Filter files by extension
            dlg.CheckFileExists = true;

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;
                BrowseBox.Text = filename;
            }
        }
    }
}
