﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;

namespace StarWars
{

    class Program
    {
        static int lastV, lastH;
        static bool foundSolution = false;
        static int Player1Cargos, Player2Cargos;
        static char[] moves = { 'L', 'R', 'E', 'S', 'N' };
        static int FirstMove = 0;
        static int closestShipR, closestShipC;
        static int R, C, T, dir;
        static bool player;
        static int oppositionR, oppositionC, oppositionDir;
        static int[,] matrix = new int[40, 50];
        static int[,] dist = new int[40, 50];
        static int[, ,] cargoShip = new int[2, 9, 2];
        static bool[, , , ,] used = new bool[40, 50, 4, 3, 3];
        static int[] rowChange = { 0, -1, 1 };
        static int[] columnChange = { 0, 1, -1 };

        static void Init()
        {
            for (int i = 1; i <= 5; i += 2)
            {
                for (int j = 1; j <= 5; j += 2)
                {
                    if (matrix[i, j] == '1')
                    {
                        cargoShip[0, Player1Cargos, 0] = i;
                        cargoShip[0, Player1Cargos++, 1] = j;
                    }
                }
            }
            for (int i = 38; i >= 34; i -= 2)
            {
                for (int j = 48; j >= 44; j -= 2)
                {
                    if (matrix[i, j] == '2')
                    {
                        cargoShip[1, Player2Cargos, 0] = i;
                        cargoShip[1, Player2Cargos++, 1] = j;
                    }
                }
            }
        }

        static int FindClosestCargoShip(int r, int c)
        {
            int closestCargoShip = -1;
            int bestDist = 2001;
            int currDist;
            if (player)
            {
                for (int i = 0; i < Player1Cargos; i++)
                {
                    currDist = Math.Abs(r - cargoShip[0, i, 0]) + Math.Abs(c - cargoShip[0, i, 1]);
                    if (bestDist > currDist)
                    {
                        bestDist = currDist;
                        closestCargoShip = i;
                    }
                }
            }
            else
            {
                for (int i = 0; i < Player2Cargos; i++)
                {
                    currDist = Math.Abs(r - cargoShip[1, i, 0]) + Math.Abs(c - cargoShip[1, i, 1]);
                    if (bestDist > currDist)
                    {
                        bestDist = currDist;
                        closestCargoShip = i;
                    }
                }
            }
            return closestCargoShip;
        }

        static bool CheckPosition(int r, int c, out int direction)
        {
            int asciiNum = (int)(matrix[r, c]);
            if (asciiNum == 114)
            {
                direction = 0;
                return true;
            }
            if (asciiNum == 108)
            {
                direction = 1;
                return true;
            }
            if (asciiNum == 117)
            {
                direction = 2;
                return true;
            }
            if (asciiNum == 100)
            {
                direction = 3;
                return true;
            }
            direction = -1;
            return false;
        }
        static void FindOpposition()
        {
            for (int i = 0; i < 40; i++)
            {
                for (int j = 0; j < 50; j++)
                {
                    if (R == i && C == j)
                    {
                        continue;
                    }
                    if (CheckPosition(i, j, out oppositionDir))
                    {
                        oppositionR = i;
                        oppositionC = j;
                        return;
                    }
                }
            }
        }

        static bool CheckIfClosestIsVisible(int r, int c, int closest)
        {
            bool isRowOrColumnClear = true;
            if (player)
            {
                if (cargoShip[0, closest, 0] == r)
                {
                    int minC = Math.Min(c, cargoShip[0, closest, 1]), maxC = Math.Max(c, cargoShip[0, closest, 1]);
                    for (int i = minC + 1; i < maxC; i++)
                    {
                        if (matrix[r, i] != ' ')
                        {
                            isRowOrColumnClear = false;
                        }
                    }
                }
                if (cargoShip[0, closest, 1] == c)
                {
                    int minR = Math.Min(r, cargoShip[0, closest, 0]), maxR = Math.Max(r, cargoShip[0, closest, 0]);
                    for (int i = minR + 1; i < maxR; i++)
                    {
                        if (matrix[i, c] != ' ')
                        {
                            isRowOrColumnClear = false;
                        }
                    }
                }
            }
            else
            {
                if (cargoShip[1, closest, 0] == r)
                {
                    int minC = Math.Min(c, cargoShip[1, closest, 1]), maxC = Math.Max(c, cargoShip[1, closest, 1]);
                    for (int i = minC + 1; i < maxC; i++)
                    {
                        if (matrix[r, i] != ' ')
                        {
                            isRowOrColumnClear = false;
                        }
                    }
                }
                if (cargoShip[1, closest, 1] == c)
                {
                    int minR = Math.Min(r, cargoShip[1, closest, 0]), maxR = Math.Max(r, cargoShip[1, closest, 0]);
                    for (int i = minR + 1; i < maxR; i++)
                    {
                        if (matrix[i, c] != ' ')
                        {
                            isRowOrColumnClear = false;
                        }
                    }
                }
            }
            if (isRowOrColumnClear)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static bool IsSameDirection(int r, int c, int dir, int closest)
        {
            if (player)
            {
                if (dir == 0 && c < cargoShip[0, closest, 1])
                {
                    return true;
                }
                if (dir == 1 && c > cargoShip[0, closest, 1])
                {
                    return true;
                }
                if (dir == 2 && r > cargoShip[0, closest, 0])
                {
                    return true;
                }
                if (dir == 3 && r < cargoShip[0, closest, 0])
                {
                    return true;
                }
                return false;
            }
            else
            {
                if (dir == 0 && c < cargoShip[1, closest, 1])
                {
                    return true;
                }
                if (dir == 1 && c > cargoShip[1, closest, 1])
                {
                    return true;
                }
                if (dir == 2 && r > cargoShip[1, closest, 0])
                {
                    return true;
                }
                if (dir == 3 && r < cargoShip[1, closest, 0])
                {
                    return true;
                }
                return false;
            }
        }
        static void DepthFirstSearch(int r, int c, int dir, int h, int v, int level, int cargos)
        {
            if (foundSolution)
            {
                return;
            }
            if (cargos == 0)
            {
                string output = moves[FirstMove].ToString();
                System.IO.StreamWriter file = new System.IO.StreamWriter("output.txt", false);
                file.WriteLine(output);
                file.Close();
                string usedSpots = "";

                System.IO.File.WriteAllText("history.txt", T + " " + lastH + " " + lastV);
                foundSolution = true;
            }
            if (r < 0 || r >= 40 || c < 0 || c >= 50 || (matrix[r, c] != ' ' && matrix[r, c] != 'r') || used[r, c, dir, h, v])
            {
                return;
            }
            used[r, c, dir, h, v] = true;
            int closest = FindClosestCargoShip(r, c);
            
            int newH = h, newV = v, newCargos = cargos;
            //shoot
            if (IsSameDirection(r, c, dir, closest) && CheckIfClosestIsVisible(r, c, closest))
            {
                newCargos--;
            }
            if (dir == 0)
            {
                if (h == 0 || h == 2)
                {
                    newH = 2;
                }
                else
                {
                    newH = 0;
                }
            }
            else if (dir == 1)
            {
                if (h == 0 || h == 1)
                {
                    newH = 1;
                }
                else
                {
                    newH = 0;
                }
            }
            else if (dir == 2)
            {
                if (v == 0 || v == 2)
                {
                    newV = 2;
                }
                else
                {
                    newV = 0;
                }
            }
            else
            {
                if (v == 0 || v == 1)
                {
                    newV = 1;
                }
                else
                {
                    newV = 0;
                }
            }
            int nextR = r + rowChange[newV], nextC = c + columnChange[newH];
            if (level == 0)
            {
                FirstMove = 3;
                lastV = newV;
                lastH = newH;
            }
            DepthFirstSearch(nextR, nextC, dir, newH, newV, level + 1, newCargos);

            //accelerate
            if (dir == 0)
            {
                if (h == 0 || h == 1)
                {
                    newH = 1;
                }
                else
                {
                    newH = 0;
                }
            }
            else if (dir == 1)
            {
                if (h == 0 || h == 2)
                {
                    newH = 2;
                }
                else
                {
                    newH = 0;
                }
            }
            else if (dir == 2)
            {
                if (v == 0 || v == 1)
                {
                    newV = 1;
                }
                else
                {
                    newV = 0;
                }
            }
            else
            {
                if (v == 0 || v == 2)
                {
                    newV = 2;
                }
                else
                {
                    newV = 0;
                }
            }
            nextR = r + rowChange[newV];
            nextC = c + columnChange[newH];
            if (level == 0)
            {
                FirstMove = 2;
                lastV = newV;
                lastH = newH;
            }
            DepthFirstSearch(nextR, nextC, dir, newH, newV, level + 1, cargos);
            
            //left rotation
            nextR = r + rowChange[v];
            nextC = c + columnChange[h];
            int newDir = dir;
            if (dir == 0)
            {
                newDir = 2;
            }
            else if (dir == 1)
            {
                newDir = 3;
            }
            else if (dir == 2)
            {
                newDir = 1;
            }
            else
            {
                newDir = 0;
            }
            if (level == 0)
            {
                FirstMove = 0;
                lastV = v;
                lastH = h;
            }
            DepthFirstSearch(nextR, nextC, newDir, h, v, level + 1, cargos);
 
            //right rotation
            nextR = r + rowChange[v];
            nextC = c + columnChange[h];
            if (dir == 0)
            {
                newDir = 3;
            }
            else if (dir == 1)
            {
                newDir = 2;
            }
            else if (dir == 2)
            {
                newDir = 0;
            }
            else
            {
                newDir = 1;
            }
            if (level == 0)
            {
                FirstMove = 1;
                lastH = h;
                lastV = v;
            }
            DepthFirstSearch(nextR, nextC, newDir, h, v, level + 1, cargos);

            nextR = r + rowChange[v];
            nextC = c + columnChange[h];
            if (level == 0)
            {
                FirstMove = 4;
            }
            DepthFirstSearch(nextR, nextC, dir, h, v, level + 1, cargos);
        }

        static void Main(string[] args)
        {
            int counter = 0;
            string line;
            System.IO.StreamReader file = new System.IO.StreamReader("input.txt");
            while((line = file.ReadLine()) != null)
            {
                if (counter < 3)
	            {
		            if (counter == 0)
                    {
                        T = int.Parse(line);
                    }
                    else if (counter == 1)
                    {
                        string[] newline = line.Split(' ');
                        R = int.Parse(newline[0]);
                        C = int.Parse(newline[1]);
                    }
                    else
                    {
                        player = int.Parse(line) == 1;
                    }
                }
                else
                {
                    for (int j = 0; j < 50; j++)
                    {
                        matrix[counter - 3, j] = line[j];
                    }
                }
                counter++;
            }
            file.Close();

            CheckPosition(R, C, out dir);
            FindOpposition();
            Init();

            int h = 0, v = 0, t = 0;
            if (File.Exists("history.txt"))
            {
                string history = File.ReadAllText("history.txt");
                h = history[2];
                v = history[4];
                t = history[0];
            }
            else
            {
                v = 0;
                h = 0;
            }

            if (t > T)
            {
                v = 0;
                h = 0;
            }

            if (player)
            {
                DepthFirstSearch(R, C, dir, 0, 0, 0, Player2Cargos);
            }
            else
            {
                DepthFirstSearch(R, C, dir, 0, 0, 0, Player1Cargos);
            }
        }
    }
}
