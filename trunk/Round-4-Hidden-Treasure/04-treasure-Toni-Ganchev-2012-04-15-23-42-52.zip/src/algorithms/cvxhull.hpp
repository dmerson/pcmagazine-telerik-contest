#ifndef ALGORITHMS_HPP
#	define ALGORITHMS_HPP

#include <iostream>
#include <vector>
#include <exception>

namespace cvxhull {

template <class PointType>
struct point_traits {
	typedef PointType point_type;
};

template <class T>
long long cross(const T& p0, const T& p1, const T& p2) {
	long long rx1 = point_traits<T>::x(p1) - point_traits<T>::x(p0);
	long long ry1 = point_traits<T>::y(p1) - point_traits<T>::y(p0);
	long long rx2 = point_traits<T>::x(p2) - point_traits<T>::x(p0);
	long long ry2 = point_traits<T>::y(p2) - point_traits<T>::y(p0);
	return rx1 * ry2 - rx2 * ry1;
}

template <class T>
bool lhs_on_the_left_of_rhs(const T& lhs, const T& rhs) {
	if (point_traits<T>::x(lhs) < point_traits<T>::x(rhs)) {
		return true;
	} else if (point_traits<T>::x(lhs) > point_traits<T>::x(rhs)) {
		return false;
	} else {
		return point_traits<T>::y(lhs) < point_traits<T>::y(rhs);
	}
}

template <class PointIter, class PointType>
std::vector<PointType> convex_hull_monotone(
		PointIter cpts_begin, PointIter cpts_end, bool include_colinear_points) {
	std::vector<PointType> points(cpts_begin, cpts_end);
	auto n = points.size();
	std::vector<PointType> hp(n * 2);
	
	std::sort(points.begin(), points.end(), lhs_on_the_left_of_rhs<PointType>);
 
	auto comp = include_colinear_points ? -1ll : 0ll;

	auto k = 0;
	// Build lower hull
	for (auto i = 0u; i < n; i++) {
		while (k >= 2 && cross(hp[k - 2], hp[k - 1], points[i]) <= comp) {
			k--;
		}
		hp[k++] = points[i];
	}
 
	// Build upper hull
	for (int i = n-2, t = k+1; i >= 0; i--) {
		while (k >= t && cross(hp[k - 2], hp[k - 1], points[i]) <= comp) {
			k--;
		}
		hp[k++] = points[i];
	}
 
	hp.resize(k - 1);

	return hp;
}

} // namespace cvxhull

#endif // ALGORITHMS_HPP
