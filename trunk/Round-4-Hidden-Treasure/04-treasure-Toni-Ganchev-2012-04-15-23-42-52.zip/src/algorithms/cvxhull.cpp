#include <algorithm>

#include "cvxhull.hpp"

namespace cvxhull {
}
