#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <algorithm>
#include <iterator>
#include <cmath>

#include <cvxhull.hpp>

using namespace cvxhull;

typedef int coord_t;

struct point {
	coord_t x;
	coord_t y;
};

template <>
struct point_traits<point> {
	typedef point point_type;
	typedef coord_t coord_type;

	static const coord_t& x(const point& pt) { return pt.x; }
	static const coord_t& y(const point& pt) { return pt.y; }
};

class map_load_error : public std::exception { };

std::istream& operator >>(std::istream& in, point& pt) {
	in >> pt.x >> pt.y;
	return in;
}

std::ostream& operator <<(std::ostream& out, const point& pt) {
	out << pt.x << ' ' << pt.y;
	return out;
}

std::istream& operator >>(std::istream& in, std::vector<point>& points) {
	size_t pointsz;
	in >> pointsz;

	if (pointsz < 3 || pointsz > 100000) {
		throw map_load_error();
	}

	for (size_t i = 0; i < pointsz; i++) {
		if (!in) {
			throw map_load_error();
		}
		point pt;
		in >> pt;
		if (pt.x < -1000000 || pt.x > 1000000 || pt.y < -1000000 || pt.y > 1000000) {
			throw map_load_error();
		}
		points.push_back(pt);
	}

	return in;
}

bool operator ==(const point& lhs, const point& rhs) {
	return lhs.x == rhs.x && lhs.y == rhs.y;
}

bool operator !=(const point& lhs, const point& rhs) {
	return lhs.x != rhs.x || lhs.y != rhs.y;
}

int main() {
	std::ifstream input("map.in");
	std::ofstream output("map.out");

	std::vector<point> points;
	try {
		input >> points;
	} catch (map_load_error&) {
		output << "ERR\n";
		return 1;
	}

	if (points.empty()) {
		output << "NO\n";
		return 0;
	}

	while (points.size() > 1) {
		std::vector<point> ring =
			convex_hull_monotone<std::vector<point>::const_iterator, point>(
				points.cbegin(), points.cend(), false);
		std::vector<point> ring_test =
			convex_hull_monotone<std::vector<point>::const_iterator, point>(
				points.cbegin(), points.cend(), true);
		if (ring_test.size() > ring.size()) {
			output << "NO\n";
			return 0;
		}

		/*std::cout << "Peeled ring, size " << ring.size() << ": ";
		std::copy(
			ring.cbegin(), ring.cend(),
			std::ostream_iterator<point>(std::cout, ", "));
		std::cout << "\n";*/

		for (auto it = ring.cbegin(); it != ring.cend(); ++it) {
			auto fit = std::find(points.cbegin(), points.cend(), *it);
			if (fit != points.cend()) {
				points.erase(fit);
			}
		}
	}

	//std::cout << "Ready!\n";
	if (points.size() == 1) {
		output << *points.cbegin() << "\n";
	} else {
		output << "NO\n";
	}

	//std::cin.get();
	return 0;
}
