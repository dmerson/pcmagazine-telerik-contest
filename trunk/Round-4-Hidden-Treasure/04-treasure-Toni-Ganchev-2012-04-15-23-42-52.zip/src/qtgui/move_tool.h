#ifndef MOVE_TOOL_H
#	define MOVE_TOOL_H

#include "tool.h"

class map;
class canvas;

class move_tool : public tool {
public:
	move_tool(canvas** c, map& m) : canvas_(c), map_(m) { }

	virtual void activate() {
		(*canvas_)->setCursor(QCursor(Qt::));
	}

	virtual void zoom(const QPoint& pt) {
	}

	virtual void mouse_press(QMouseEvent* event) {
		mouse_prev_pos_ = event->pos();
	}

	virtual void mouse_move(QMouseEvent* event) {
		if (event->buttons().testFlag(Qt::LeftButton)) {
			(*canvas_)->move_selection(event->pos() - mouse_prev_pos_);
			mouse_prev_pos_ = event->pos();
		}
	}

	virtual void mouse_release(QMouseEvent* event) {
	}

private:
	map& map_;
	canvas** canvas_;
	QPoint mouse_prev_pos_;
};

#endif // MOVE_TOOL_H
