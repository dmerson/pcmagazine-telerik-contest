/****************************************************************************
** Meta object code from reading C++ file 'main_jam.h'
**
** Created: Sun Apr 15 20:59:48 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../main_jam.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'main_jam.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_main_jam[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x08,
      27,    9,    9,    9, 0x08,
      43,    9,   38,    9, 0x08,
      54,    9,   38,    9, 0x08,
      72,    9,    9,    9, 0x08,
      79,    9,    9,    9, 0x08,
      96,    9,    9,    9, 0x08,
     116,    9,    9,    9, 0x08,
     140,    9,    9,    9, 0x08,
     146,    9,    9,    9, 0x08,
     160,  153,    9,    9, 0x08,
     185,    9,    9,    9, 0x08,
     205,  202,    9,    9, 0x08,
     234,  202,    9,    9, 0x08,
     283,  262,    9,    9, 0x08,
     318,    9,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_main_jam[] = {
    "main_jam\0\0create_new_map()\0open_map()\0"
    "bool\0save_map()\0save_map_as_new()\0"
    "quit()\0enter_add_mode()\0enter_select_mode()\0"
    "remove_selected_nodes()\0run()\0stop()\0"
    "result\0save_result(const char*)\0"
    "save_no_result()\0pt\0save_treasure_result(QPoint)\0"
    "show_canvas_coords(QPointF)\0"
    "selected_nodes_count\0"
    "update_remove_availability(size_t)\0"
    "mark_dirty()\0"
};

void main_jam::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        main_jam *_t = static_cast<main_jam *>(_o);
        switch (_id) {
        case 0: _t->create_new_map(); break;
        case 1: _t->open_map(); break;
        case 2: { bool _r = _t->save_map();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 3: { bool _r = _t->save_map_as_new();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: _t->quit(); break;
        case 5: _t->enter_add_mode(); break;
        case 6: _t->enter_select_mode(); break;
        case 7: _t->remove_selected_nodes(); break;
        case 8: _t->run(); break;
        case 9: _t->stop(); break;
        case 10: _t->save_result((*reinterpret_cast< const char*(*)>(_a[1]))); break;
        case 11: _t->save_no_result(); break;
        case 12: _t->save_treasure_result((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 13: _t->show_canvas_coords((*reinterpret_cast< const QPointF(*)>(_a[1]))); break;
        case 14: _t->update_remove_availability((*reinterpret_cast< size_t(*)>(_a[1]))); break;
        case 15: _t->mark_dirty(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData main_jam::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject main_jam::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_main_jam,
      qt_meta_data_main_jam, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &main_jam::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *main_jam::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *main_jam::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_main_jam))
        return static_cast<void*>(const_cast< main_jam*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int main_jam::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
