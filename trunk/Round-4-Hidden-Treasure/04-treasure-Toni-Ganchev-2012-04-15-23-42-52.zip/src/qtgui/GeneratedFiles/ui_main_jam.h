/********************************************************************************
** Form generated from reading UI file 'main_jam.ui'
**
** Created: Sun Apr 15 19:16:24 2012
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_JAM_H
#define UI_MAIN_JAM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_main_jamClass
{
public:
    QAction *action_open;
    QAction *action_save;
    QAction *action_save_as;
    QAction *action_new;
    QAction *action_exit;
    QAction *action_selection_mode;
    QAction *action_addition_mode;
    QAction *action_remove;
    QAction *action_run;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QMenu *menu_Tools;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *main_jamClass)
    {
        if (main_jamClass->objectName().isEmpty())
            main_jamClass->setObjectName(QString::fromUtf8("main_jamClass"));
        main_jamClass->resize(1102, 882);
        action_open = new QAction(main_jamClass);
        action_open->setObjectName(QString::fromUtf8("action_open"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/main_jam/Resources/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_open->setIcon(icon);
        action_save = new QAction(main_jamClass);
        action_save->setObjectName(QString::fromUtf8("action_save"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/main_jam/Resources/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_save->setIcon(icon1);
        action_save_as = new QAction(main_jamClass);
        action_save_as->setObjectName(QString::fromUtf8("action_save_as"));
        action_save_as->setIcon(icon1);
        action_new = new QAction(main_jamClass);
        action_new->setObjectName(QString::fromUtf8("action_new"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/main_jam/Resources/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_new->setIcon(icon2);
        action_exit = new QAction(main_jamClass);
        action_exit->setObjectName(QString::fromUtf8("action_exit"));
        action_selection_mode = new QAction(main_jamClass);
        action_selection_mode->setObjectName(QString::fromUtf8("action_selection_mode"));
        action_selection_mode->setCheckable(true);
        action_selection_mode->setChecked(true);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/main_jam/Resources/select.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_selection_mode->setIcon(icon3);
        action_addition_mode = new QAction(main_jamClass);
        action_addition_mode->setObjectName(QString::fromUtf8("action_addition_mode"));
        action_addition_mode->setCheckable(true);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/main_jam/Resources/add.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_addition_mode->setIcon(icon4);
        action_remove = new QAction(main_jamClass);
        action_remove->setObjectName(QString::fromUtf8("action_remove"));
        action_remove->setEnabled(false);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/main_jam/Resources/remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_remove->setIcon(icon5);
        action_run = new QAction(main_jamClass);
        action_run->setObjectName(QString::fromUtf8("action_run"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/main_jam/Resources/run.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_run->setIcon(icon6);
        centralWidget = new QWidget(main_jamClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        main_jamClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(main_jamClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1102, 26));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menu_Tools = new QMenu(menuBar);
        menu_Tools->setObjectName(QString::fromUtf8("menu_Tools"));
        main_jamClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(main_jamClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        mainToolBar->setIconSize(QSize(16, 16));
        main_jamClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(main_jamClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        main_jamClass->setStatusBar(statusBar);

        menuBar->addAction(menu_File->menuAction());
        menuBar->addAction(menu_Tools->menuAction());
        menu_File->addAction(action_new);
        menu_File->addAction(action_open);
        menu_File->addAction(action_save);
        menu_File->addAction(action_save_as);
        menu_File->addSeparator();
        menu_File->addAction(action_exit);
        menu_Tools->addAction(action_selection_mode);
        menu_Tools->addAction(action_addition_mode);
        menu_Tools->addSeparator();
        menu_Tools->addAction(action_remove);
        menu_Tools->addSeparator();
        mainToolBar->addAction(action_new);
        mainToolBar->addAction(action_open);
        mainToolBar->addAction(action_save);
        mainToolBar->addSeparator();
        mainToolBar->addAction(action_selection_mode);
        mainToolBar->addAction(action_addition_mode);
        mainToolBar->addSeparator();
        mainToolBar->addAction(action_remove);
        mainToolBar->addSeparator();
        mainToolBar->addAction(action_run);

        retranslateUi(main_jamClass);

        QMetaObject::connectSlotsByName(main_jamClass);
    } // setupUi

    void retranslateUi(QMainWindow *main_jamClass)
    {
        main_jamClass->setWindowTitle(QApplication::translate("main_jamClass", "main_jam", 0, QApplication::UnicodeUTF8));
        action_open->setText(QApplication::translate("main_jamClass", "&Open...", 0, QApplication::UnicodeUTF8));
        action_open->setShortcut(QApplication::translate("main_jamClass", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        action_save->setText(QApplication::translate("main_jamClass", "&Save", 0, QApplication::UnicodeUTF8));
        action_save->setShortcut(QApplication::translate("main_jamClass", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        action_save_as->setText(QApplication::translate("main_jamClass", "Save &as...", 0, QApplication::UnicodeUTF8));
        action_new->setText(QApplication::translate("main_jamClass", "&New", 0, QApplication::UnicodeUTF8));
        action_new->setShortcut(QApplication::translate("main_jamClass", "Ctrl+N", 0, QApplication::UnicodeUTF8));
        action_exit->setText(QApplication::translate("main_jamClass", "E&xit", 0, QApplication::UnicodeUTF8));
        action_selection_mode->setText(QApplication::translate("main_jamClass", "&Select", 0, QApplication::UnicodeUTF8));
        action_selection_mode->setShortcut(QApplication::translate("main_jamClass", "S", 0, QApplication::UnicodeUTF8));
        action_addition_mode->setText(QApplication::translate("main_jamClass", "&Add", 0, QApplication::UnicodeUTF8));
        action_addition_mode->setShortcut(QApplication::translate("main_jamClass", "A", 0, QApplication::UnicodeUTF8));
        action_remove->setText(QApplication::translate("main_jamClass", "&Remove", 0, QApplication::UnicodeUTF8));
        action_remove->setShortcut(QApplication::translate("main_jamClass", "Del", 0, QApplication::UnicodeUTF8));
        action_run->setText(QApplication::translate("main_jamClass", "&Run", 0, QApplication::UnicodeUTF8));
        action_run->setShortcut(QApplication::translate("main_jamClass", "F5", 0, QApplication::UnicodeUTF8));
        menu_File->setTitle(QApplication::translate("main_jamClass", "&File", 0, QApplication::UnicodeUTF8));
        menu_Tools->setTitle(QApplication::translate("main_jamClass", "&Tools", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class main_jamClass: public Ui_main_jamClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_JAM_H
