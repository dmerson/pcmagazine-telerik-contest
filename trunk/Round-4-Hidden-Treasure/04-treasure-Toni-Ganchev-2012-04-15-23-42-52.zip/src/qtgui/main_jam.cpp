#include "main_jam.h"

#include <fstream>
#include <sstream>
#include <algorithm>

#include <QtGui/QMessageBox>
#include <QtGui/QFileDialog>

#include <cvxhull.hpp>

template <>
struct cvxhull::point_traits<QPoint> {
	typedef int coord_type;
	typedef QPoint point_type;

	static const int x(const QPoint& pt) { return pt.x(); }
	static const int y(const QPoint& pt) { return pt.y(); }
};

main_jam::main_jam(QWidget *parent, Qt::WFlags flags)
	: QMainWindow(parent, flags)
	, is_map_dirty_(false)
	, is_map_titled_(false)
	, map_name_(tr("Untitled"))
	, selection_tool_(&canvas_, map_)
	, addition_tool_(&canvas_, map_)
	, is_running_(false)
{
	ui.setupUi(this);

	canvas_ = new canvas(map_, this);
	setCentralWidget(canvas_);

	tool_actions_ = new QActionGroup(this);
	tool_actions_->setExclusive(true);
	tool_actions_->addAction(ui.action_selection_mode);
	tool_actions_->addAction(ui.action_addition_mode);

	QObject::connect(ui.action_new, SIGNAL(triggered()),
		this, SLOT(create_new_map()));
	QObject::connect(ui.action_open, SIGNAL(triggered()),
		this, SLOT(open_map()));
	QObject::connect(ui.action_save, SIGNAL(triggered()),
		this, SLOT(save_map()));
	QObject::connect(ui.action_save_as, SIGNAL(triggered()),
		this, SLOT(save_map_as_new()));

	QObject::connect(ui.action_exit, SIGNAL(triggered()), this, SLOT(quit()));

	QObject::connect(ui.action_selection_mode, SIGNAL(triggered()),
		this, SLOT(enter_select_mode()));
	QObject::connect(ui.action_addition_mode, SIGNAL(triggered()),
		this, SLOT(enter_add_mode()));

	QObject::connect(ui.action_remove, SIGNAL(triggered()),
		this, SLOT(remove_selected_nodes()));

	QObject::connect(ui.action_run, SIGNAL(triggered()), this, SLOT(run()));

	QObject::connect(canvas_, SIGNAL(coords_changed(const QPointF&)),
		this, SLOT(show_canvas_coords(const QPointF&)));
	QObject::connect(canvas_, SIGNAL(selection_changed(size_t)),
		this, SLOT(update_remove_availability(size_t)));
	QObject::connect(canvas_, SIGNAL(map_changed()), this, SLOT(mark_dirty()));

	canvas_->change_tool(selection_tool_);

	reset_view();
}

main_jam::~main_jam() {
}

void main_jam::closeEvent(QCloseEvent* event) {
	static const char confirmation_message[] =
		"The changes made to %s have not been saved.\n\nDo you want to save the changes before proceeding?";
	
	event->ignore();

	bool should_save = false;

	if (is_map_dirty_) {
		QString message = tr(confirmation_message).replace("%s", map_name_);
		auto result = QMessageBox::question(this, tr("Save Changes"), message,
			QMessageBox::Save, QMessageBox::Discard, QMessageBox::Cancel);
		if (result == QMessageBox::Save) {
			should_save = true;
		} else if (result == QMessageBox::Cancel) {
			return;
		}
	}

	if (should_save && !save_map()) {
		return;
	}

	event->accept();
}

void main_jam::create_new_map() {
	static const char confirmation_message[] =
		"The changes made to %s have not been saved.\n\nDo you want to save the changes before proceeding?";
	
	bool should_save = false;

	if (is_map_dirty_) {
		QString message = tr(confirmation_message).replace("%s", map_name_);
		auto result = QMessageBox::question(this, tr("Save Changes"), message,
			QMessageBox::Save, QMessageBox::Discard, QMessageBox::Cancel);
		if (result == QMessageBox::Save) {
			should_save = true;
		} else if (result == QMessageBox::Cancel) {
			return;
		}
	}

	if (should_save && !save_map()) {
		return;
	}

	is_map_dirty_ = false;
	is_map_titled_ = false;
	map_name_ = tr("Untitled");
	map_.clear();
	is_map_dirty_ = false;
	is_map_titled_ = false;
		
	reset_view();
}

void main_jam::reset_view() {
	ui.action_remove->setEnabled(false);
	setWindowTitle(QString::fromUtf8("%s - Treasure Hunt").replace("%s", map_name_));
	canvas_->reset();
}

void main_jam::open_map() {
	static const char confirmation_message[] =
		"The changes made to %s have not been saved.\n\nDo you want to save the changes before proceeding?";
	bool should_save = false;
	if (is_map_dirty_) {
		QString message = tr(confirmation_message).replace("%s", map_name_);
		auto result = QMessageBox::question(this, tr("Save Changes"), message,
			QMessageBox::Save, QMessageBox::Discard, QMessageBox::Cancel);
		if (result == QMessageBox::Save) {
			should_save = true;
		} else if (result == QMessageBox::Cancel) {
			return;
		}
	}

	if (should_save && !save_map()) {
		return;
	}

	QFileDialog dialog;
	dialog.setFileMode(QFileDialog::ExistingFile);
	dialog.setAcceptMode(QFileDialog::AcceptOpen);
	if (dialog.exec() && !dialog.selectedFiles().empty()) {
		QString selected_file = dialog.selectedFiles()[0];
		try {
			map_.load_from(selected_file.toStdString().c_str());
		} catch (map_load_error& e) {
			std::stringstream ss;
			ss << "The specified map could not be read.\n\n" << e.what();
			QMessageBox::critical(this, tr("Open File"), tr(ss.str().c_str()));
			return;
		}
		
		map_name_ = selected_file;
		is_map_dirty_ = false;
		is_map_titled_ = true;
		reset_view();
	}
}

bool main_jam::save_map_to(const QString& file) {
	try {
		map_.save_to(file.toStdString().c_str());
	} catch (...) {
		return false;
	}
	is_map_titled_ = true;
	is_map_dirty_ = false;
	ui.action_remove->setEnabled(false);
	map_name_ = file;
	setWindowTitle(QString::fromUtf8("%s - Treasure Hunt").replace("%s", map_name_));
	return true;
}

bool main_jam::save_map() {
	if (is_map_titled_) {
		return save_map_to(map_name_);
	} else {
		return save_map_as_new();
	}
}

bool main_jam::save_map_as_new() {
	QFileDialog dialog;
	dialog.setFileMode(QFileDialog::AnyFile);
	dialog.setAcceptMode(QFileDialog::AcceptSave);
	if (dialog.exec() && !dialog.selectedFiles().empty()) {
		QString selected_file = dialog.selectedFiles()[0];
		return save_map_to(selected_file);
	} else {
		return false;
	}	
}	

void main_jam::quit() {
	QCoreApplication::quit();
}

void main_jam::enter_add_mode() {
	canvas_->change_tool(addition_tool_);
}

void main_jam::enter_select_mode() {
	canvas_->change_tool(selection_tool_);
}

void main_jam::remove_selected_nodes() {
	canvas_->remove_selected_nodes();
}

void main_jam::run() {
	if (is_running_) {
		stop();
	} else {
		ui.action_run->setText(tr("Stop"));
		is_running_ = true;

		canvas_->clear_rings();
		canvas_->remove_treasure();

		map::ring_type nodes;
		for (auto it = map_.nodes_begin(); it != map_.nodes_end(); ++it) {
			nodes.push_back(it->coords());
		}

		while (nodes.size() > 1) {
			auto ring = cvxhull::convex_hull_monotone<decltype(nodes.cbegin()), QPoint>(
				nodes.cbegin(), nodes.cend(), false);
			auto ring_test = cvxhull::convex_hull_monotone<decltype(nodes.cbegin()), QPoint>(
				nodes.cbegin(), nodes.cend(), true);
			if (ring_test.size() > ring.size()) {
				nodes.clear();
				break;
			}

			canvas_->add_ring(ring);
		
			for (auto it = ring.cbegin(); it != ring.cend(); ++it) {
				auto fit = std::find(nodes.cbegin(), nodes.cend(), *it);
				if (fit != nodes.cend()) {
					nodes.erase(fit);
				}
			}
		}
		
		if (nodes.empty()) {
			if (QMessageBox::information(this,
					tr("Treasure Hunt"), tr("There is no treasure on the map."),
					QMessageBox::Ok, QMessageBox::Save) == QMessageBox::Save) {
				save_no_result();
			}
		} else {
			const QPoint& pt = nodes.front();
			canvas_->mark_treasure(pt);

			std::stringstream ss;
			ss << "Treasure found at " << pt.x() << " : " << pt.y();
			if (QMessageBox::information(this,
					tr("Treasure Hunt"), tr(ss.str().c_str()),
					QMessageBox::Ok, QMessageBox::Save) == QMessageBox::Save) {
				save_treasure_result(pt);
			}
		}

		stop();
	}
}

void main_jam::stop() {
	ui.action_run->setText(tr("Run"));
	is_running_ = false;
}

void main_jam::save_result(const char* result) {
	QFileDialog dialog;
	dialog.setFileMode(QFileDialog::AnyFile);
	dialog.setAcceptMode(QFileDialog::AcceptSave);
	if (dialog.exec() && !dialog.selectedFiles().empty()) {
		QString selected_file = dialog.selectedFiles()[0];
		std::ofstream out(selected_file.toStdString());
		out << result;
	}
}

void main_jam::save_no_result() {
	save_result("NO\n");
}

void main_jam::save_treasure_result(const QPoint& pt) {
	std::stringstream ss;
	ss << pt.x() << " " << pt.y() << "\n";
	save_result(ss.str().c_str());
}

void main_jam::show_canvas_coords(const QPointF& pt) {
	std::stringstream ss;
	ss << "Pos: " << pt.x() << " : " << pt.y();
	ui.statusBar->showMessage(tr(ss.str().c_str()));
}

void main_jam::update_remove_availability(size_t selected_nodes_count) {
	ui.action_remove->setEnabled(selected_nodes_count > 0);
}

void main_jam::mark_dirty() {
	is_map_dirty_ = true;
	setWindowTitle(QString::fromUtf8("*%s - Treasure Hunt").replace("%s", map_name_));
}
