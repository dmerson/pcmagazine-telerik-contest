#include "canvas.h"

const QPen canvas::coords_pen_(QPen(QBrush(QColor::fromRgb(127, 127, 127)), 1, Qt::DotLine));
const QPen canvas::point_pen_(Qt::SolidLine);
const QPen canvas::selected_point_pen_(QColor::fromRgb(255, 0, 0));
const QPen canvas::bounding_box_pen_(Qt::DotLine);
const QPen canvas::ring_pen_(QColor::fromRgb(0, 127, 0));
const QPen canvas::selection_box_pen_(Qt::DashLine);
const QPen canvas::boundary_pen_(QColor::fromRgb(127, 127, 127));
const QPen canvas::add_cursor_pen_(Qt::SolidLine);

const QBrush canvas::main_brush_(QColor::fromRgb(255, 255, 255));
const QBrush canvas::boundary_brush_(QColor::fromRgb(127, 127, 127), Qt::BDiagPattern);
const QBrush canvas::treasure_brush_(QColor::fromRgb(255, 127, 0));