#ifndef SELECTION_TOOL_H
#	define SELECTION_TOOL_H

#include "tool.h"

class map;
class canvas;

class selection_tool : public tool {
public:
	selection_tool(canvas** c, map& m) : canvas_(c), map_(m) { }

	virtual void activate() {
		(*canvas_)->setCursor(QCursor(Qt::CrossCursor));
	}

	virtual void zoom(const QPoint& pt) {
	}

	virtual void mouse_press(QMouseEvent* event) {
		mouse_prev_pos_ = event->pos();
	}

	virtual void mouse_move(QMouseEvent* event) {
		if (event->buttons().testFlag(Qt::LeftButton)) {
			(*canvas_)->change_selection_rect(
				QRect(mouse_prev_pos_, event->pos()));
		}
	}

	virtual void mouse_release(QMouseEvent* event) {
		(*canvas_)->apply_selection();
	}

private:
	map& map_;
	canvas** canvas_;
	QPoint mouse_prev_pos_;
};

#endif // SELECTION_TOOL_H
