#ifndef TOOL_H
#	define TOOL_H

class QMouseEvent;

class tool {
public:
	virtual void activate() { }
	virtual void deactivate() { }
	virtual void zoom(const QPoint& pt) { }
	virtual void mouse_move(QMouseEvent* event) { }
	virtual void mouse_press(QMouseEvent* event) { }
	virtual void mouse_release(QMouseEvent* event) { }
};

#endif // TOOL_H
