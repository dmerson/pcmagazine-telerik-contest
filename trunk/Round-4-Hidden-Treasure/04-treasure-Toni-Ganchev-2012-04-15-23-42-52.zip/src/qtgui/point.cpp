#include "point.h"

bool operator ==(const point& lhs, const point& rhs) {
	return lhs.coords() == rhs.coords();
}

bool operator !=(const point& lhs, const point& rhs) {
	return lhs.coords() != rhs.coords();
}