
#ifndef CANVAS_H
#	define CANVAS_H

#include <cmath>

#include <QtGui/QWidget>
#include <QtGui/QPainter>
#include <QtGui/qevent.h>

#include <cvxhull.hpp>

#include "map.h"
#include "tool.h"

class canvas : public QWidget
{
	Q_OBJECT

public:
	canvas(map& m, QWidget *parent = 0, Qt::WFlags flags = 0)
			: QWidget(parent, flags)
			, map_(m)
			, zoom_(10.0)
			, x_offset_(10.0)
			, y_offset_(100.0)
			, current_tool_(0)
			, selection_rect_shown_(false)
			, add_pos_shown_(false) {
		setMouseTracking(true);
	}

	~canvas() { }

	void reset() {
		zoom_ = 10.0;
		x_offset_ = 0;
		y_offset_ = 0;
		auto bounding_box_center = to_screen(map_.bounding_box().center());
		auto screen_center = rect().center();
		auto new_origin = screen_center - bounding_box_center;
		x_offset_ = new_origin.x();
		y_offset_ = new_origin.y();
		update();
	}

	void change_tool(tool& tool) {
		if (current_tool_) {
			current_tool_->deactivate();
		}
		current_tool_ = &tool;
		current_tool_->activate();
	}

	void change_selection_rect(const QRect& rect) {
		selection_rect_shown_ = true;
		selection_rect_ = rect;
		update();
	}

	void apply_selection() {
		auto selected_count = map_.select(to_world(selection_rect_));
		selection_rect_shown_ = false;
		update();
		emit selection_changed(selected_count);
	}

	void remove_selected_nodes() {
		if (map_.remove_selected_nodes()) {
			emit map_changed();
		}
		update();
		emit selection_changed(0u);
	}

	bool can_add_node(const QPoint& pt) {
		return map_.can_add_node(to_world_rounded(pt));
	}

	void add_node(const QPoint& pt) {
		if (map_.add_node(to_world_rounded(pt))) {
			emit map_changed();
		}
		update();
	}

	void add_ring(const map::ring_type& ring) {
		map_.add_ring(ring);
		update();
	}

	void clear_rings() {
		map_.clear_rings();
		update();
	}

	void mark_treasure(const QPoint& pt) {
		map_.mark_treasure(pt);
		update();
	}

	void remove_treasure() {
		map_.remove_treasure();
		update();
	}

	void change_add_position(const QPoint& pt) {
		add_pos_ = to_screen(to_world_rounded(pt));
		add_pos_shown_ = true;
		update();
	}

	void clear_add_position() {
		add_pos_shown_ = false;
	}

signals:
	void coords_changed(const QPointF& pt);
	void selection_changed(size_t selected_nodes_count);
	void map_changed();

protected:
	void paintEvent(QPaintEvent* event) {
		QPainter painter(this);

		painter.setRenderHint(QPainter::Antialiasing);

		// screen objects...
		draw_background(painter);
		draw_selection(painter);
		draw_coords(painter);
		draw_add_cursor(painter);

		painter.translate(x_offset_, y_offset_);
		painter.scale(zoom_, -zoom_);

		// world objects...
		draw_bounding_box(painter);
		draw_rings(painter);
		draw_nodes(painter);
	}

	void wheelEvent(QWheelEvent* event) {
		auto new_zoom = 0.0;
		if (event->delta() < 0) {
			// zoom out...
			new_zoom = zoom_ / 2;
		} else {
			// zoom in...
			if (zoom_ > 100) {
				return;
			}
			new_zoom = zoom_ * 2;
		}

		auto zoom_center = to_world(event->pos());
		auto zoom_ratio = new_zoom / zoom_;
		auto new_pos = zoom_center - zoom_center * zoom_ratio;
		auto new_screen_orig = to_screen(new_pos);
		x_offset_ = new_screen_orig.x();
		y_offset_ = new_screen_orig.y();

		zoom_ = new_zoom;

		current_tool_->zoom(event->pos());
		update();
		emit coords_changed(to_world(event->pos()));
	}

	void mousePressEvent(QMouseEvent* event) {
		if (event->buttons().testFlag(Qt::RightButton)) {
			cursor_prev_ = cursor();
			setCursor(QCursor(Qt::ClosedHandCursor));
			mouse_prev_pos_ = event->pos();
		} else if (current_tool_) {
			current_tool_->mouse_press(event);
		}
	}

	void mouseReleaseEvent(QMouseEvent* event) {
		if (event->button() == Qt::RightButton) {
			mouse_prev_pos_ = event->pos();
			setCursor(cursor_prev_);
		} else if (current_tool_) {
			current_tool_->mouse_release(event);
		}
	}

	void mouseMoveEvent(QMouseEvent* event) {
		if (event->buttons().testFlag(Qt::RightButton)) {
			auto new_pos = event->pos();
			x_offset_ += (new_pos.x() - mouse_prev_pos_.x());
			y_offset_ += (new_pos.y() - mouse_prev_pos_.y());
			mouse_prev_pos_ = new_pos;
			update();
			clear_add_position();
		} else if (current_tool_) {
			current_tool_->mouse_move(event);
		}

		emit coords_changed(to_world(event->pos()));
	}

private:
	static const QPen coords_pen_;
	static const QPen point_pen_;
	static const QPen selected_point_pen_;
	static const QPen bounding_box_pen_;
	static const QPen ring_pen_;
	static const QPen selection_box_pen_;
	static const QPen boundary_pen_;
	static const QPen add_cursor_pen_;
	static const QBrush main_brush_;
	static const QBrush boundary_brush_;
	static const QBrush treasure_brush_;

	map& map_;
	double x_offset_;
	double y_offset_;
	double zoom_;
	QPoint mouse_prev_pos_;
	tool* current_tool_;
	QCursor cursor_prev_;
	QRect selection_rect_;
	bool selection_rect_shown_;
	QPoint add_pos_;
	bool add_pos_shown_;

	void draw_background(QPainter& painter) {
		QRect world_limits = to_screen(map::world_limits);
		QRect screen_limits = rect();
		if (!world_limits.contains(screen_limits)) {
			painter.fillRect(screen_limits, boundary_brush_);
		}
		painter.fillRect(world_limits, main_brush_);
		painter.drawRect(world_limits);
	}

	void draw_selection(QPainter& painter) {
		painter.setPen(selection_box_pen_);
		if (selection_rect_shown_) {
			painter.drawRect(selection_rect_);
		}
	}

	void draw_coords(QPainter& painter) {
		painter.setPen(coords_pen_);
		QSize sz = size();
		painter.drawLine(0, y_offset_, sz.width(), y_offset_);
		painter.drawLine(x_offset_, 0, x_offset_, sz.height());
	}

	void draw_add_cursor(QPainter& painter) {
		if (!add_pos_shown_) {
			return;
		}
		painter.setPen(add_cursor_pen_);
		auto x = add_pos_.x();
		auto y = add_pos_.y();
		painter.drawLine(x - 10, y, x + 10, y);
		painter.drawLine(x, y - 10, x, y + 10);
	}

	void draw_bounding_box(QPainter& painter) {
		painter.setPen(bounding_box_pen_);
		painter.drawLine(
			map_.bounding_box().topLeft(), map_.bounding_box().topRight());
		painter.drawLine(
			map_.bounding_box().topLeft(), map_.bounding_box().bottomLeft());
		painter.drawLine(
			map_.bounding_box().topRight(), map_.bounding_box().bottomRight());
		painter.drawLine(
			map_.bounding_box().bottomLeft(),
			map_.bounding_box().bottomRight());
	}

	void draw_nodes(QPainter& painter) {
		auto screen_area = to_world(rect());
		for (auto it = map_.nodes_begin(); it != map_.nodes_end(); ++it) {
			if (screen_area.contains(it->coords())) {
				if (map_.treasure_found() && map_.treasure() == it->coords()) {
					painter.setBrush(treasure_brush_);
				} else {
					painter.setBrush(Qt::NoBrush);
				}

				if (it->selected()) {
					painter.setPen(selected_point_pen_);
				} else {
					painter.setPen(point_pen_);
				}
				auto r = 2.0 / zoom_;
				painter.drawEllipse(QPointF(it->coords().x(), it->coords().y()), r, r);
			}
		}
	}

	void draw_rings(QPainter& painter) {
		painter.setPen(ring_pen_);
		for (auto it = map_.rings_begin(); it != map_.rings_end(); ++it) {
			auto previt = it->cend() - 1;
			for (auto jt = it->cbegin(); jt != it->cend(); jt++) {
				painter.drawLine(*previt, *jt);
				previt = jt;
			}
		}
	}

	QPointF to_world(const QPoint& pt) const {
		auto x = (pt.x() - x_offset_) / zoom_;
		auto y = (y_offset_ - pt.y()) / zoom_;
		return QPointF(x, y);
	}

	QPoint to_world_rounded(const QPoint& pt) const {
		auto ptf = to_world(pt);
		return QPoint(round(ptf.x()), round(ptf.y()));
	}

	QRectF to_world(const QRect& r) const {
		return QRectF(to_world(r.topLeft()), to_world(r.bottomRight()));
	}

	QPoint to_screen(const QPointF& pt) const {
		auto x = round(x_offset_ + pt.x() * zoom_);
		auto y = round(y_offset_ - pt.y() * zoom_);
		return QPoint(x, y);
	}

	QRect to_screen(const QRectF& pt) const {
		return QRect(to_screen(pt.topLeft()), to_screen(pt.bottomRight()));
	}

	static double round(double v) {
		auto f = std::floor(v);
		auto c = std::ceil(v);
		return (v - f < c - v) ? f : c;
	}
};

#endif // CANVAS_H
