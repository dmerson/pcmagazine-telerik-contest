#include "main_jam.h"
#include <QtGui/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	main_jam w;
	w.show();
	return a.exec();
}
