#ifndef ADDITION_TOOL_H
#	define ADDITION_TOOL_H

#include <sstream>
#include <QtGui/qmessagebox>

#include "tool.h"

class map;
class QMouseEvent;

class addition_tool : public tool {
public:
	addition_tool(canvas** c, map& m)
		: canvas_(c)
		, map_(m)
	{ }

	virtual void activate() {
	}

	virtual void deactivate() {
		(*canvas_)->clear_add_position();
	}

	virtual void zoom(const QPoint& pt) {
		update_cursor(pt);
	}

	virtual void mouse_press(QMouseEvent* event) {
	}

	virtual void mouse_move(QMouseEvent* event) {
		update_cursor(event->pos());
		
	}

	virtual void mouse_release(QMouseEvent* event) {
		if (map_.nodes_end() - map_.nodes_begin() >= map::max_node_count) {
			std::stringstream ss;
			ss << "The map already contains the maximum allowed "
				<< map::max_node_count
				<< " nodes. You cannot add any more nodes.";
			QMessageBox::warning(
				*canvas_, "Add Node", ss.str().c_str());
		} else {
			(*canvas_)->add_node(event->pos());
		}
	}

private:
	map& map_;
	canvas** canvas_;

	void update_cursor(const QPoint& pt) {
		auto c = *canvas_;
		if (c->can_add_node(pt)) {
			c->setCursor(QCursor(Qt::ArrowCursor));
			c->change_add_position(pt);
		} else {
			c->setCursor(QCursor(Qt::ForbiddenCursor));
			c->clear_add_position();
		}
	}
};

#endif // ADDITION_TOOL_H
