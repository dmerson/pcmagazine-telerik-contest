#include "map.h"

const QRect map::world_limits(-1000000, -1000000, 2000001, 2000001);
const size_t map::max_node_count = 100000u;

std::istream& operator >>(std::istream& in, QPoint& pt) {
	int x, y;
	in >> x >> y;
	pt = QPoint(x, y);
	return in;
}
