#ifndef POINT_H
#	define POINT_H

#include <Qt/qpoint.h>

class point {
public:
	const QPoint& coords() const { return coords_; }

	void select(bool sel) { selected_ = sel; };
	bool selected() const { return selected_; }

	point& operator =(const point& pt) {
		coords_ = pt.coords_;
		selected_ = pt.selected_;
		return *this;
	}

	point() : selected_(false) { }
	explicit point(const QPoint& pos) : coords_(pos), selected_(false) { }
	point(const point& pt) : coords_(pt.coords_), selected_(pt.selected_) { }
private:
	QPoint coords_;
	bool selected_;
};

bool operator ==(const point& lhs, const point& rhs);
bool operator !=(const point& lhs, const point& rhs);

#endif // POINT_H
