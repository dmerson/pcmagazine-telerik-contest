#ifndef MAIN_JAM_H
#define MAIN_JAM_H

#include <QtGui/QMainWindow>
#include <QtGui/qpainter.h>
#include "ui_main_jam.h"
#include "canvas.h"
#include "map.h"
#include "selection_tool.h"
#include "addition_tool.h"
#include <cvxhull.hpp>

class main_jam : public QMainWindow
{
	Q_OBJECT

public:
	main_jam(QWidget *parent = 0, Qt::WFlags flags = 0);
	~main_jam();

private slots:
	void create_new_map();
	void open_map();
	bool save_map();
	bool save_map_as_new();
	void quit();
	void enter_add_mode();
	void enter_select_mode();
	void remove_selected_nodes();
	void run();
	void stop();
	void save_result(const char* result);
	void save_no_result();
	void save_treasure_result(const QPoint& pt);

	void show_canvas_coords(const QPointF& pt);
	void update_remove_availability(size_t selected_nodes_count);
	void mark_dirty();

protected:
	void closeEvent(QCloseEvent* event);
private:
	Ui::main_jamClass ui;

	QActionGroup* tool_actions_;
	canvas* canvas_;

	bool is_map_dirty_;
	bool is_map_titled_;
	QString map_name_;

	map map_;

	selection_tool selection_tool_;
	addition_tool addition_tool_;

	bool is_running_;

	void reset_view();
	bool save_map_to(const QString& file);
};

#endif // MAIN_JAM_H
