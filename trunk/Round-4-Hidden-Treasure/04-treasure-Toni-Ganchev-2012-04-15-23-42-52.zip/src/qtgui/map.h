#ifndef MAP_H
#	define MAP_H

#include <fstream>
#include <vector>
#include <algorithm>
#include <Qt/qpoint.h>
#include <Qt/qrect.h>

#include "point.h"

class map_load_error : public std::exception {
public:
	map_load_error(const char* message) : std::exception(message) { }
};

std::istream& operator >>(std::istream& in, QPoint& pt);

class map {
public:
	typedef std::vector<point>::const_iterator node_const_iterator;
	typedef std::vector<QPoint> ring_type;
	typedef std::vector<ring_type>::const_iterator ring_const_iterator;

	static const QRect world_limits;
	static const size_t max_node_count;

	void load_from(const char* file) {
		std::ifstream in(file);
	
		size_t pointsz;
		in >> pointsz;

		if (pointsz > max_node_count) {
			throw map_load_error("Nodes in the map file exceed the maximum allowed number of nodes per map.");
		}

		std::vector<point> temp(pointsz);
		for (size_t i = 0; i < pointsz; i++) {
			if (!in) {
				throw map_load_error("Unexpected end of file reached.");
			}
			QPoint pt;
			in >> pt;

			if (!world_limits.contains(pt)) {
				throw map_load_error("There is a node outside of the allowed world boundaries.");
			}

			temp[i] = point(pt);
		}

		clear();
		nodes_.resize(temp.size());
		std::copy(temp.cbegin(), temp.cend(), nodes_.begin());
		calc_bounding_box();
	}

	void save_to(const char* file) {
		std::ofstream out(file);
		out << nodes_.size() << "\n";
		for (auto it = nodes_.cbegin(); it != nodes_.cend(); ++it) {
			out << it->coords().x() << " " << it->coords().y() << " ";
		}
	}

	void clear() {
		nodes_.clear();
		clear_rings();
		remove_treasure();
		calc_bounding_box();
	}

	bool empty() const { return nodes_.empty(); }

	node_const_iterator nodes_begin() const { return nodes_.cbegin(); }
	node_const_iterator nodes_end() const { return nodes_.cend(); }
	
	ring_const_iterator rings_begin() const { return rings_.cbegin(); }
	ring_const_iterator rings_end() const { return rings_.cend(); }

	const QRect& bounding_box() const { return bounding_box_; }

	bool can_add_node(const QPoint& pt) {
		return world_limits.contains(pt);
	}

	bool add_node(const QPoint& pt) {
		if (!can_add_node(pt)) {
			return false;
		}
		point ptx(pt);
		if (std::find(nodes_.cbegin(), nodes_.cend(), ptx) == nodes_.cend()) {
			nodes_.push_back(point(pt));
			remove_treasure();
			clear_rings();
			calc_bounding_box();

			for (auto it = nodes_.begin(); it != nodes_.end(); ++it) {
				it->select(false);
			}

			return true;
		} else {
			return false;
		}
	}

	size_t select(const QRectF& selection_rect) {
		size_t selsz = 0u;
		for (auto it = nodes_.begin(); it != nodes_.end(); ++it) {
			auto selected = selection_rect.contains(it->coords());
			it->select(selected);
			selsz += selected ? 1u : 0;
		}
		return selsz;
	}

	bool remove_selected_nodes() {
		bool nodes_removed = false;
		std::vector<point> selected_nodes;
		for (auto it = nodes_.cbegin(); it != nodes_.cend(); ++it) {
			if (it->selected()) {
				selected_nodes.push_back(*it);
			}
		}
		for (auto it = selected_nodes.cbegin(); it != selected_nodes.cend(); ++it) {
			auto jt = std::find(nodes_.cbegin(), nodes_.cend(), *it);
			if (jt != nodes_.cend()) {
				nodes_.erase(jt);
				nodes_removed = true;
			}
		}
		if (nodes_removed) {
			remove_treasure();
			clear_rings();
			calc_bounding_box();
		}

		return nodes_removed;
	}

	void add_ring(const ring_type& ring) {
		rings_.push_back(ring);
	}

	void clear_rings() {
		rings_.clear();
	}

	const bool treasure_found() const { return treasure_found_; }
	const QPoint treasure() const { return treasure_; }

	void mark_treasure(const QPoint& pt) {
		treasure_ = pt;
		treasure_found_ = true;
	}

	void remove_treasure() {
		treasure_found_ = false;
	}

	map() : treasure_found_(false) {
		calc_bounding_box();
	}

private:
	std::vector<point> nodes_;
	std::vector<ring_type> rings_;

	QRect bounding_box_;

	QPoint treasure_;
	bool treasure_found_;

	void calc_bounding_box() {
		if (nodes_.empty()) {
			bounding_box_.setCoords(0, 0, 0, 0);
		} else {
			auto fit = nodes_begin();
			bounding_box_.setCoords(
				fit->coords().x(), fit->coords().y(),
				fit->coords().x(), fit->coords().y());
			for (auto it = nodes_.cbegin() + 1; it != nodes_.cend(); ++it) {
				auto x = it->coords().x();
				auto y = it->coords().y();
				bounding_box_ = bounding_box_.unite(QRect(x, y, 1, 1));
			}
		}
	}
};

#endif // MAP_H
